import SwiftUI
import UIKit
import UniformTypeIdentifiers

// MARK: - Pinned hero (Apple Music style)
// The artwork stays behind the page, drifts up slower than the content and blurs while the
// title scrolls to the top. A 1:1 animation stays square; only a tall animation makes it extend.

struct HeroMedia: View {
    let key: String
    let letter: String
    var extended: Bool

    @EnvironmentObject private var library: Library

    private var video: URL? {
        if extended { return library.assetURL(key, .tallanim) ?? library.assetURL(key, .anim) }
        return library.assetURL(key, .anim) ?? library.assetURL(key, .tallanim)
    }

    private var still: URL? {
        if extended { return library.assetURL(key, .tall) ?? library.assetURL(key, .cover) }
        return library.squareImageURL(key)
    }

    var body: some View {
        ZStack {
            CoverView(url: still, letter: letter, maxSide: 1400)
            if let video { LoopingVideoView(url: video) }
        }
    }
}

struct PinnedHeroScroll<Hero: View, Info: View>: View {
    let extended: Bool
    var overlap: CGFloat = 150
    @Binding var scrolled: CGFloat
    let hero: Hero
    let info: Info

    init(
        extended: Bool,
        overlap: CGFloat = 150,
        scrolled: Binding<CGFloat>,
        @ViewBuilder hero: () -> Hero,
        @ViewBuilder info: () -> Info
    ) {
        self.extended = extended
        self.overlap = overlap
        self._scrolled = scrolled
        self.hero = hero()
        self.info = info()
    }

    var body: some View {
        GeometryReader { geo in
            let width: CGFloat = geo.size.width
            let height: CGFloat = extended ? width * 4 / 3 : width
            let travel: CGFloat = max(height - overlap - 110, 1)
            let progress: CGFloat = min(max(scrolled / travel, 0), 1)
            let pull: CGFloat = max(-scrolled, 0)
            ZStack(alignment: .top) {
                hero
                    .frame(width: width, height: height)
                    .clipped()
                    .scaleEffect(1 + pull / height, anchor: .top)
                    .offset(y: -max(scrolled, 0) * 0.3)
                    .blur(radius: progress * 28, opaque: true)
                    .frame(maxHeight: .infinity, alignment: .top)

                ScrollView {
                    VStack(spacing: 0) {
                        Color.clear.frame(height: max(height - overlap, 0))
                        info
                    }
                }
                .onScrollGeometryChange(for: CGFloat.self, of: { g in
                    g.contentOffset.y + g.contentInsets.top
                }, action: { _, newValue in
                    scrolled = newValue
                })
            }
            .frame(width: width, height: geo.size.height)
        }
        .ignoresSafeArea(edges: .top)
    }
}

/// Soft wash from the artwork colour into the page background, behind the title block.
private struct InfoWash: View {
    let deep: Color
    let base: Color

    var body: some View {
        VStack(spacing: 0) {
            LinearGradient(colors: [deep.opacity(0), deep], startPoint: .top, endPoint: .bottom)
                .frame(height: 150)
            LinearGradient(colors: [deep, base], startPoint: .top, endPoint: UnitPoint(x: 0.5, y: 0.45))
        }
    }
}

private struct PlayCapsule: View {
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: "play.fill").font(.system(size: 12, weight: .bold))
                Text(title).font(.system(size: 15, weight: .semibold))
            }
            .foregroundStyle(Color.black)
            .padding(.horizontal, 18)
            .frame(height: 34)
            .background(Color.white, in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Album page

struct AlbumPage: View {
    let key: String

    var body: some View {
        AlbumContent(key: key).artTinted(key: key)
    }
}

private struct AlbumContent: View {
    let key: String

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme
    @Environment(\.art) private var art
    @Environment(\.dismiss) private var dismiss

    @State private var scrollY: CGFloat = 0
    @State private var rowTop: CGFloat = 10_000
    @State private var editing: Track?
    @State private var importing = ArtworkImportState()
    @State private var confirmRemove = false

    private var tracks: [Track] { library.tracks(forAlbum: key) }
    private var extended: Bool { library.isExtended(key) }
    private var deep: Color { art?.deep ?? theme.bg }
    private var accent: Color { art?.accent ?? theme.ac }
    private var pinned: Bool { rowTop < 120 }

    var body: some View {
        PinnedHeroScroll(extended: extended, scrolled: $scrollY) {
            HeroMedia(key: key, letter: tracks.first?.displayAlbum ?? "", extended: extended)
        } info: {
            if let first = tracks.first { info(first) }
        }
        .background(theme.bg.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(.hidden, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .principal) {
                if pinned {
                    PlayCapsule(title: "Play") { player.playAll(tracks, shuffled: false) }
                }
            }
            ToolbarItemGroup(placement: .topBarTrailing) {
                ShareLink(item: shareText)
                moreMenu
            }
        }
        .tint(accent)
        .onAppear { if let t = tracks.first { library.fetchOnline(for: t) } }
        .sheet(item: $editing) { t in
            TagEditorSheet(trackID: t.id, offerAlbum: true)
                .environmentObject(library)
                .environmentObject(theme)
        }
        .artworkImporters(key: key, state: $importing)
        .confirmationDialog("Remove this album from your library?", isPresented: $confirmRemove, titleVisibility: .visible) {
            Button("Remove album", role: .destructive) {
                library.removeAlbum(key: key)
                dismiss()
            }
        }
    }

    private var shareText: String {
        guard let first = tracks.first else { return "" }
        return first.displayAlbum + " — " + first.artistName
    }

    private var moreMenu: some View {
        Menu {
            ArtworkMenuItems(state: $importing)
            Button { library.removeArtwork(forKey: key) } label: {
                Label("Remove cover and animation", systemImage: "photo.badge.minus")
            }
            Button(role: .destructive) { confirmRemove = true } label: {
                Label("Remove album", systemImage: "trash")
            }
        } label: {
            Image(systemName: "ellipsis")
        }
    }

    private var allLiked: Bool {
        !tracks.isEmpty && tracks.allSatisfy { library.isLiked($0) }
    }

    private var likeAllButton: AnyView {
        let on: Bool = allLiked
        let list: [Track] = tracks
        return AnyView(
            Button { library.setLiked(list, !on) } label: {
                GlassIcon(symbol: on ? "checkmark" : "plus", size: 52)
            }
            .buttonStyle(.plain)
        )
    }

    private func info(_ first: Track) -> some View {
        let meta: String = [first.genre, first.year].filter { !$0.isEmpty }.joined(separator: " · ")
        let count: String = "\(tracks.count) song\(tracks.count == 1 ? "" : "s")"
        return VStack(spacing: 10) {
            Text(first.displayAlbum)
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(Color.white)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)

            if !first.artistName.isEmpty {
                NavigationLink(value: ArtistRoute(name: first.artistName)) {
                    Text(first.artistName)
                        .font(.system(size: 21))
                        .foregroundStyle(Color.white.opacity(0.92))
                }
            }

            if !meta.isEmpty {
                Text(meta)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Color.white.opacity(0.6))
            }

            ActionRow(
                play: { player.playAll(tracks, shuffled: false) },
                shuffle: { player.playAll(tracks, shuffled: true) },
                trailing: likeAllButton
            )
            .padding(.top, 8)
            .onGeometryChange(for: CGFloat.self, of: { proxy in
                proxy.frame(in: .global).minY
            }, action: { value in
                rowTop = value
            })

            Divider().overlay(theme.ln).padding(.top, 8)

            VStack(spacing: 0) {
                ForEach(tracks) { t in
                    TrackRow(track: t, showSubtitle: false, numbered: t.no, onEdit: { editing = t }) {
                        player.play(t, in: tracks)
                    }
                    Divider().overlay(theme.ln)
                }
            }

            Text(count)
                .font(.system(size: 14))
                .foregroundStyle(theme.mu)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 8)
                .padding(.bottom, 120)
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .background(alignment: .top) { InfoWash(deep: deep, base: theme.bg) }
    }
}

// MARK: - Artist page

struct ArtistPage: View {
    let name: String

    @EnvironmentObject private var library: Library

    private var artworkKey: String? {
        let own: String = ArtistKey.make(name)
        let hasOwn: Bool = library.assetURL(own, .cover) != nil || library.assetURL(own, .tall) != nil
            || library.assetURL(own, .anim) != nil || library.assetURL(own, .tallanim) != nil
        if hasOwn { return own }
        return library.albumGroups(of: library.tracks(forArtist: name)).first?.id
    }

    var body: some View {
        ArtistContent(name: name, artworkKey: artworkKey)
            .artTinted(key: artworkKey)
    }
}

private struct ArtistContent: View {
    let name: String
    let artworkKey: String?

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme
    @EnvironmentObject private var services: Services
    @Environment(\.art) private var art

    @State private var scrollY: CGFloat = 0
    @State private var rowTop: CGFloat = 10_000
    @State private var editing: Track?
    @State private var importing = ArtworkImportState()

    private var artistKey: String { ArtistKey.make(name) }
    private var tracks: [Track] { library.tracks(forArtist: name) }
    private var albums: [AlbumGroup] { library.albumGroups(of: tracks) }
    private var heroKey: String { artworkKey ?? artistKey }
    private var extended: Bool { library.isExtended(heroKey) || library.assetURL(heroKey, .tall) != nil }
    private var deep: Color { art?.deep ?? theme.bg }
    private var accent: Color { art?.accent ?? theme.ac }
    private var pinned: Bool { rowTop < 120 }

    private var latest: AlbumGroup? {
        albums.max { $0.first.year < $1.first.year }
    }

    private var allLiked: Bool {
        !tracks.isEmpty && tracks.allSatisfy { library.isLiked($0) }
    }

    var body: some View {
        PinnedHeroScroll(extended: extended, overlap: 190, scrolled: $scrollY) {
            HeroMedia(key: heroKey, letter: name, extended: extended)
        } info: {
            content
        }
        .background(theme.bg.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(.hidden, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .principal) {
                if pinned {
                    PlayCapsule(title: "Play") { player.playAll(tracks, shuffled: false) }
                }
            }
            ToolbarItemGroup(placement: .topBarTrailing) {
                ShareLink(item: name)
                artistMenu
            }
        }
        .tint(accent)
        .onAppear { library.fetchArtistPhoto(name: name, services: services) }
        .sheet(item: $editing) { t in
            TagEditorSheet(trackID: t.id, offerAlbum: false)
                .environmentObject(library)
                .environmentObject(theme)
        }
        .artworkImporters(key: artistKey, state: $importing)
    }

    private var artistMenu: some View {
        Menu {
            ArtworkMenuItems(state: $importing, allowLogo: true)
            if services.artistSourceReady {
                Button {
                    library.removeAssets(artistKey, kinds: [.cover, .tall])
                    library.fetchArtistPhoto(name: name, services: services)
                } label: {
                    Label("Fetch photo from \(services.artistSource.title)", systemImage: "arrow.down.circle")
                }
            }
            Button(role: .destructive) { library.removeArtwork(forKey: artistKey) } label: {
                Label("Remove artist artwork", systemImage: "photo.badge.minus")
            }
        } label: {
            Image(systemName: "ellipsis")
        }
    }

    @ViewBuilder
    private var titleView: some View {
        if let url = library.assetURL(artistKey, .logo), let image = UIImage(contentsOfFile: url.path) {
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 300, maxHeight: 120)
                .shadow(color: Color.black.opacity(0.35), radius: 10, y: 4)
        } else {
            Text(name)
                .font(.system(size: 38, weight: .bold))
                .foregroundStyle(Color.white)
                .multilineTextAlignment(.center)
                .minimumScaleFactor(0.6)
        }
    }

    private var actionRow: some View {
        HStack(spacing: 28) {
            Menu {
                ArtworkMenuItems(state: $importing, allowLogo: true)
            } label: {
                Image(systemName: "info")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(Color.white)
                    .frame(width: 60, height: 60)
                    .glassSurface(Circle(), tint: art?.glass, interactive: true)
            }

            Button { player.playAll(tracks, shuffled: false) } label: {
                Image(systemName: "play.fill")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(Color.black)
                    .frame(width: 76, height: 76)
                    .background(Color.white, in: Circle())
            }
            .buttonStyle(.plain)

            Button { library.setLiked(tracks, !allLiked) } label: {
                Image(systemName: allLiked ? "star.fill" : "star")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(Color.white)
                    .frame(width: 60, height: 60)
                    .glassSurface(Circle(), tint: art?.glass, interactive: true)
            }
            .buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity)
        .onGeometryChange(for: CGFloat.self, of: { proxy in
            proxy.frame(in: .global).minY
        }, action: { value in
            rowTop = value
        })
    }

    private var content: some View {
        VStack(alignment: .leading, spacing: 26) {
            titleView
                .frame(maxWidth: .infinity)
            actionRow

            if let latest { latestCard(latest) }

            VStack(alignment: .leading, spacing: 6) {
                Text("Popular songs")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(theme.fg)
                ForEach(library.topTracks(in: tracks, limit: 5)) { t in
                    TrackRow(track: t, showAlbumArtwork: true, onEdit: { editing = t }) {
                        player.play(t, in: tracks)
                    }
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                Text("Albums")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(theme.fg)
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 20) {
                    ForEach(albums) { album in
                        NavigationLink(value: AlbumRoute(key: album.id)) {
                            AlbumTile(album: album)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 120)
        .background(alignment: .top) { InfoWash(deep: deep, base: theme.bg) }
    }

    private func latestCard(_ album: AlbumGroup) -> some View {
        NavigationLink(value: AlbumRoute(key: album.id)) {
            HStack(spacing: 14) {
                CoverView(url: library.assetURL(album.id, .cover), letter: album.title, maxSide: 400)
                    .frame(width: 96, height: 96)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text(album.first.year.isEmpty ? "Latest release" : album.first.year)
                        .font(.system(size: 13))
                        .foregroundStyle(Color.white.opacity(0.65))
                    Text(album.title)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(Color.white)
                        .lineLimit(2)
                    Text("\(album.tracks.count) song\(album.tracks.count == 1 ? "" : "s")")
                        .font(.system(size: 13))
                        .foregroundStyle(Color.white.opacity(0.65))
                }
                Spacer(minLength: 0)
            }
            .padding(14)
            .glassSurface(RoundedRectangle(cornerRadius: 24, style: .continuous), tint: art?.glass.opacity(0.4))
        }
        .buttonStyle(.plain)
    }
}
