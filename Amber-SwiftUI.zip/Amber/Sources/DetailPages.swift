import SwiftUI
import UniformTypeIdentifiers

// MARK: - Hero (animated cover if the album has one, otherwise the tall image / cover)

struct HeroView: View {
    let key: String
    let letter: String
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var theme: Theme

    private var video: URL? { library.assetURL(key, .tallanim) ?? library.assetURL(key, .anim) }
    private var isTall: Bool { library.assetURL(key, .tallanim) != nil || library.assetURL(key, .tall) != nil }

    var body: some View {
        Color.clear
            .aspectRatio(isTall ? 0.8 : 1.0, contentMode: .fit)
            .overlay {
                ZStack {
                    CoverView(url: library.heroImageURL(key), letter: letter, maxSide: 1400)
                    if let video { LoopingVideoView(url: video) }
                }
            }
            .overlay(alignment: .bottom) {
                LinearGradient(
                    colors: [theme.bg.opacity(0), theme.bg],
                    startPoint: .init(x: 0.5, y: 0.45), endPoint: .bottom
                )
            }
            .clipped()
    }
}

// MARK: - Album page

struct AlbumPage: View {
    let key: String

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme
    @Environment(\.dismiss) private var dismiss

    @State private var editing: Track?
    @State private var showArtworkImporter = false
    @State private var confirmRemove = false

    private var tracks: [Track] { library.tracks(forAlbum: key) }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                if let first = tracks.first {
                    HeroView(key: key, letter: first.displayAlbum)
                    info(first)
                }
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(theme.bg.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(.hidden, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .onAppear { if let t = tracks.first { library.fetchOnline(for: t) } }
        .sheet(item: $editing) { t in
            TagEditorSheet(trackID: t.id, offerAlbum: true)
                .environmentObject(library)
                .environmentObject(theme)
        }
        .fileImporter(isPresented: $showArtworkImporter, allowedContentTypes: [.image, .movie], allowsMultipleSelection: false) { result in
            if case .success(let urls) = result, let url = urls.first {
                Task { await library.importArtwork(from: url, forKey: key) }
            }
        }
        .confirmationDialog("Remove this album from your library?", isPresented: $confirmRemove, titleVisibility: .visible) {
            Button("Remove album", role: .destructive) {
                library.removeAlbum(key: key)
                dismiss()
            }
        }
    }

    private func info(_ first: Track) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(first.displayAlbum)
                .font(theme.title())
                .foregroundStyle(theme.fg)
                .multilineTextAlignment(theme.centered ? .center : .leading)
                .frame(maxWidth: .infinity, alignment: theme.centered ? .center : .leading)

            if !first.artistName.isEmpty {
                NavigationLink(value: ArtistRoute(name: first.artistName)) {
                    Text(first.artistName)
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(theme.ac)
                }
                .frame(maxWidth: .infinity, alignment: theme.centered ? .center : .leading)
            }

            Text([first.year, "\(tracks.count) song\(tracks.count == 1 ? "" : "s")"].filter { !$0.isEmpty }.joined(separator: " · "))
                .font(.system(size: 14))
                .foregroundStyle(theme.mu)
                .frame(maxWidth: .infinity, alignment: theme.centered ? .center : .leading)

            HStack(spacing: 10) {
                PillButton(title: "Play", systemImage: "play.fill", filled: true) { player.playAll(tracks, shuffled: false) }
                PillButton(title: "Shuffle", systemImage: "shuffle") { player.playAll(tracks, shuffled: true) }
            }
            .frame(maxWidth: .infinity, alignment: theme.centered ? .center : .leading)

            HStack(spacing: 10) {
                PillButton(title: "Cover or animation", systemImage: "photo") { showArtworkImporter = true }
                PillButton(title: "Remove", systemImage: "trash") { confirmRemove = true }
            }
            .frame(maxWidth: .infinity, alignment: theme.centered ? .center : .leading)

            VStack(spacing: 0) {
                ForEach(tracks) { t in
                    TrackRow(track: t, numbered: t.no, onEdit: { editing = t }) {
                        player.play(t, in: tracks)
                    }
                    Divider().overlay(theme.ln)
                }
            }
            .padding(.top, 6)
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 30)
    }
}

// MARK: - Artist page

struct ArtistPage: View {
    let name: String

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    @State private var editing: Track?

    private var tracks: [Track] { library.tracks(forArtist: name) }
    private var albums: [AlbumGroup] { library.albumGroups(of: tracks) }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                if let firstAlbum = albums.first {
                    HeroView(key: firstAlbum.id, letter: name)
                }
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(name)
                            .font(theme.title())
                            .foregroundStyle(theme.fg)
                        Text("\(albums.count) album\(albums.count == 1 ? "" : "s") · \(tracks.count) song\(tracks.count == 1 ? "" : "s")")
                            .font(.system(size: 14))
                            .foregroundStyle(theme.mu)
                    }
                    .frame(maxWidth: .infinity, alignment: theme.centered ? .center : .leading)

                    HStack(spacing: 10) {
                        PillButton(title: "Smart shuffle", systemImage: "shuffle", filled: true) { player.playAll(tracks, shuffled: true) }
                        PillButton(title: "Play", systemImage: "play.fill") { player.playAll(tracks, shuffled: false) }
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        SectionTitle(text: "Top songs")
                        ForEach(library.topTracks(in: tracks, limit: 5)) { t in
                            TrackRow(track: t, showAlbumArtwork: true, onEdit: { editing = t }) {
                                player.play(t, in: tracks)
                            }
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Albums")
                        LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 20) {
                            ForEach(albums) { album in
                                NavigationLink(value: AlbumRoute(key: album.id)) {
                                    AlbumTile(album: album)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(theme.bg.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(.hidden, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .sheet(item: $editing) { t in
            TagEditorSheet(trackID: t.id, offerAlbum: false)
                .environmentObject(library)
                .environmentObject(theme)
        }
    }
}
