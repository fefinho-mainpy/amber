import SwiftUI
import UniformTypeIdentifiers

// MARK: - Hero
// Square by default (a 1:1 animation stays square); only a tall (3:4) animation makes it extend.

struct HeroView: View {
    let key: String
    let letter: String
    var fade: Color?

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var theme: Theme

    private var extended: Bool { library.isExtended(key) }
    private var video: URL? { library.assetURL(key, .tallanim) ?? library.assetURL(key, .anim) }
    private var edge: Color { fade ?? theme.bg }

    private var still: URL? {
        if extended { return library.assetURL(key, .tall) ?? library.assetURL(key, .cover) }
        return library.squareImageURL(key)
    }

    var body: some View {
        Color.clear
            .aspectRatio(extended ? 0.75 : 1.0, contentMode: .fit)
            .overlay {
                ZStack {
                    CoverView(url: still, letter: letter, maxSide: 1400)
                    if let video { LoopingVideoView(url: video) }
                }
            }
            .overlay(alignment: .bottom) {
                LinearGradient(
                    colors: [edge.opacity(0), edge],
                    startPoint: UnitPoint(x: 0.5, y: 0.55), endPoint: .bottom
                )
            }
            .clipped()
    }
}

// MARK: - Album page

struct AlbumPage: View {
    let key: String

    var body: some View {
        AlbumContent(key: key).artTinted(key: key)
    }
}

private struct AlbumContent: View {
    let key: String

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme
    @Environment(\.art) private var art
    @Environment(\.dismiss) private var dismiss

    @State private var editing: Track?
    @State private var showArtworkImporter = false
    @State private var confirmRemove = false

    private var tracks: [Track] { library.tracks(forAlbum: key) }
    private var deep: Color { art?.deep ?? theme.bg }
    private var accent: Color { art?.accent ?? theme.ac }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                if let first = tracks.first {
                    HeroView(key: key, letter: first.displayAlbum, fade: deep)
                    info(first)
                }
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(theme.bg.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(.hidden, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) { moreMenu }
        }
        .tint(accent)
        .onAppear { if let t = tracks.first { library.fetchOnline(for: t) } }
        .sheet(item: $editing) { t in
            TagEditorSheet(trackID: t.id, offerAlbum: true)
                .environmentObject(library)
                .environmentObject(theme)
        }
        .fileImporter(isPresented: $showArtworkImporter, allowedContentTypes: [.image, .movie], allowsMultipleSelection: false) { result in
            if case .success(let urls) = result, let url = urls.first {
                Task { await library.importArtwork(from: url, forKey: key) }
            }
        }
        .confirmationDialog("Remove this album from your library?", isPresented: $confirmRemove, titleVisibility: .visible) {
            Button("Remove album", role: .destructive) {
                library.removeAlbum(key: key)
                dismiss()
            }
        }
    }

    private var moreMenu: some View {
        Menu {
            Button { showArtworkImporter = true } label: {
                Label("Cover or animation", systemImage: "photo")
            }
            Button(role: .destructive) { confirmRemove = true } label: {
                Label("Remove album", systemImage: "trash")
            }
        } label: {
            Image(systemName: "ellipsis")
        }
    }

    private var allLiked: Bool {
        !tracks.isEmpty && tracks.allSatisfy { library.isLiked($0) }
    }

    private var likeAllButton: AnyView {
        let on: Bool = allLiked
        let list: [Track] = tracks
        return AnyView(
            Button { library.setLiked(list, !on) } label: {
                GlassIcon(symbol: on ? "checkmark" : "plus", size: 52)
            }
            .buttonStyle(.plain)
        )
    }

    private func info(_ first: Track) -> some View {
        let align: Alignment = theme.centered ? .center : .leading
        return VStack(alignment: .leading, spacing: 14) {
            Text(first.displayAlbum)
                .font(theme.title())
                .foregroundStyle(theme.fg)
                .multilineTextAlignment(theme.centered ? .center : .leading)
                .frame(maxWidth: .infinity, alignment: align)

            if !first.artistName.isEmpty {
                NavigationLink(value: ArtistRoute(name: first.artistName)) {
                    Text(first.artistName)
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(accent)
                }
                .frame(maxWidth: .infinity, alignment: align)
            }

            Text([first.year, "\(tracks.count) song\(tracks.count == 1 ? "" : "s")"].filter { !$0.isEmpty }.joined(separator: " · "))
                .font(.system(size: 14))
                .foregroundStyle(theme.mu)
                .frame(maxWidth: .infinity, alignment: align)

            ActionRow(
                play: { player.playAll(tracks, shuffled: false) },
                shuffle: { player.playAll(tracks, shuffled: true) },
                trailing: likeAllButton
            )
            .padding(.top, 4)

            VStack(spacing: 0) {
                ForEach(tracks) { t in
                    TrackRow(track: t, numbered: t.no, onEdit: { editing = t }) {
                        player.play(t, in: tracks)
                    }
                    Divider().overlay(theme.ln)
                }
            }
            .padding(.top, 6)
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 30)
        .background(alignment: .top) {
            LinearGradient(
                colors: [deep, theme.bg],
                startPoint: .top, endPoint: UnitPoint(x: 0.5, y: 0.55)
            )
        }
    }
}

// MARK: - Artist page

struct ArtistPage: View {
    let name: String

    @EnvironmentObject private var library: Library

    private var firstAlbumKey: String? {
        library.albumGroups(of: library.tracks(forArtist: name)).first?.id
    }

    var body: some View {
        ArtistContent(name: name).artTinted(key: firstAlbumKey)
    }
}

private struct ArtistContent: View {
    let name: String

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme
    @Environment(\.art) private var art

    @State private var editing: Track?

    private var tracks: [Track] { library.tracks(forArtist: name) }
    private var albums: [AlbumGroup] { library.albumGroups(of: tracks) }
    private var deep: Color { art?.deep ?? theme.bg }
    private var accent: Color { art?.accent ?? theme.ac }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                if let firstAlbum = albums.first {
                    HeroView(key: firstAlbum.id, letter: name, fade: deep)
                }
                content
            }
        }
        .ignoresSafeArea(edges: .top)
        .background(theme.bg.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(.hidden, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .tint(accent)
        .sheet(item: $editing) { t in
            TagEditorSheet(trackID: t.id, offerAlbum: false)
                .environmentObject(library)
                .environmentObject(theme)
        }
    }

    private var content: some View {
        let align: Alignment = theme.centered ? .center : .leading
        return VStack(alignment: .leading, spacing: 22) {
            VStack(alignment: .leading, spacing: 6) {
                Text(name)
                    .font(theme.title())
                    .foregroundStyle(theme.fg)
                Text("\(albums.count) album\(albums.count == 1 ? "" : "s") · \(tracks.count) song\(tracks.count == 1 ? "" : "s")")
                    .font(.system(size: 14))
                    .foregroundStyle(theme.mu)
            }
            .frame(maxWidth: .infinity, alignment: align)

            ActionRow(
                play: { player.playAll(tracks, shuffled: false) },
                shuffle: { player.playAll(tracks, shuffled: true) }
            )

            VStack(alignment: .leading, spacing: 8) {
                SectionTitle(text: "Top songs")
                ForEach(library.topTracks(in: tracks, limit: 5)) { t in
                    TrackRow(track: t, showAlbumArtwork: true, onEdit: { editing = t }) {
                        player.play(t, in: tracks)
                    }
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Albums")
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 20) {
                    ForEach(albums) { album in
                        NavigationLink(value: AlbumRoute(key: album.id)) {
                            AlbumTile(album: album)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 30)
        .background(alignment: .top) {
            LinearGradient(
                colors: [deep, theme.bg],
                startPoint: .top, endPoint: UnitPoint(x: 0.5, y: 0.35)
            )
        }
    }
}
