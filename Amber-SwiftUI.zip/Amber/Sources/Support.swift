import SwiftUI
import UIKit

// MARK: - Small helpers

func formatTime(_ t: TimeInterval) -> String {
    guard t.isFinite, t >= 0 else { return "0:00" }
    let s = Int(t.rounded())
    return String(format: "%d:%02d", s / 60, s % 60)
}

/// Stable (non-randomised) hash for cache file names, placeholder colours and taste keys.
func stableHash(_ s: String) -> UInt64 {
    var h: UInt64 = 0xcbf29ce484222325
    for b in s.utf8 {
        h ^= UInt64(b)
        h = h &* 0x100000001b3
    }
    return h
}

extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }
}

/// CSS-style hsl(h, s%, l%).
func hslColor(_ h: Double, _ s: Double, _ l: Double) -> Color {
    let hh = (h.truncatingRemainder(dividingBy: 360) + 360).truncatingRemainder(dividingBy: 360)
    let ss = s / 100
    let ll = l / 100
    let a = ss * min(ll, 1 - ll)
    func channel(_ n: Double) -> Double {
        let k = (n + hh / 30).truncatingRemainder(dividingBy: 12)
        let lo: Double = min(k - 3, 9 - k)
        let clamped: Double = max(-1, min(lo, 1))
        return ll - a * clamped
    }
    return Color(.sRGB, red: channel(0), green: channel(8), blue: channel(4), opacity: 1)
}

// MARK: - Image helpers

enum ArtworkFactory {
    /// Colourful generated cover (used only where an image is required, e.g. the lock screen).
    static func placeholder(title: String, side: CGFloat) -> UIImage {
        let hue = CGFloat(stableHash(title) % 360) / 360.0
        let hue2 = (hue + 0.12).truncatingRemainder(dividingBy: 1)
        let top = UIColor(hue: hue, saturation: 0.65, brightness: 0.95, alpha: 1)
        let bottom = UIColor(hue: hue2, saturation: 0.80, brightness: 0.50, alpha: 1)

        let format = UIGraphicsImageRendererFormat.preferred()
        format.scale = 1
        let size = CGSize(width: side, height: side)

        return UIGraphicsImageRenderer(size: size, format: format).image { context in
            let cg = context.cgContext
            let colors = [top.cgColor, bottom.cgColor] as CFArray
            if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
                cg.drawLinearGradient(gradient, start: .zero, end: CGPoint(x: side, y: side), options: [])
            }
            let config = UIImage.SymbolConfiguration(pointSize: side * 0.42, weight: .semibold)
            if let note = UIImage(systemName: "music.note", withConfiguration: config)?
                .withTintColor(UIColor.white.withAlphaComponent(0.92), renderingMode: .alwaysOriginal) {
                let rect = CGRect(
                    x: (side - note.size.width) / 2,
                    y: (side - note.size.height) / 2,
                    width: note.size.width,
                    height: note.size.height
                )
                note.draw(in: rect)
            }
        }
    }

    /// Scales an image down so its longest side is at most `maxSide` pixels (never scales up).
    static func downscaled(_ image: UIImage, maxSide: CGFloat) -> UIImage {
        let longest = max(image.size.width, image.size.height)
        guard longest > maxSide else { return image }
        let k = maxSide / longest
        let newSize = CGSize(width: (image.size.width * k).rounded(), height: (image.size.height * k).rounded())
        let format = UIGraphicsImageRendererFormat.preferred()
        format.scale = 1
        return UIGraphicsImageRenderer(size: newSize, format: format).image { _ in
            image.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }
}

/// Loads (and caches) downscaled images from disk off the main thread.
enum ImageLoader {
    private static let cache = NSCache<NSString, UIImage>()

    static func load(_ url: URL, maxSide: CGFloat) async -> UIImage? {
        let key = "\(url.path)|\(Int(maxSide))" as NSString
        if let hit = cache.object(forKey: key) { return hit }
        let image = await Task.detached(priority: .utility) { () -> UIImage? in
            guard let raw = UIImage(contentsOfFile: url.path) else { return nil }
            return ArtworkFactory.downscaled(raw, maxSide: maxSide)
        }.value
        if let image { cache.setObject(image, forKey: key) }
        return image
    }
}

// MARK: - Cover colours (port of the web app's quad())

struct CoverColors {
    /// Saturation-boosted average colour of the four quadrants: TL, TR, BL, BR.
    let quadrants: [Color]
    /// Dark backdrop colour (the web app's `ab`).
    let backdrop: Color
    /// 3x3 blend of the quadrants, row by row, for an animated mesh gradient.
    let mesh: [Color]

    static func make(from image: UIImage?, hasCover: Bool) -> CoverColors? {
        guard let cg = image?.cgImage else { return nil }
        let n = 16
        var pixels = [UInt8](repeating: 0, count: n * n * 4)
        let drawn: Bool = pixels.withUnsafeMutableBytes { buffer in
            guard let ctx = CGContext(
                data: buffer.baseAddress, width: n, height: n, bitsPerComponent: 8,
                bytesPerRow: n * 4, space: CGColorSpaceCreateDeviceRGB(),
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
            ) else { return false }
            ctx.interpolationQuality = .medium
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: n, height: n))
            return true
        }
        guard drawn else { return nil }

        var sums = [[Double]](repeating: [0, 0, 0], count: 4)
        for i in 0..<(n * n) {
            let x = i % n
            let y = i / n
            let q = (x >= n / 2 ? 1 : 0) + (y >= n / 2 ? 2 : 0)
            for c in 0..<3 { sums[q][c] += Double(pixels[i * 4 + c]) }
        }
        let count = Double(n * n / 4) * 255
        var rgb: [[Double]] = sums.map { s in
            let r = s[0] / count, g = s[1] / count, b = s[2] / count
            let l: Double = 0.3 * r + 0.59 * g + 0.11 * b
            func boost(_ v: Double) -> Double { max(0, min(1, l + (v - l) * 1.4)) }
            return [boost(r), boost(g), boost(b)]
        }
        // backdrop: mean of the two lower quadrants, darkened when a real cover exists
        let k = hasCover ? 0.5 : 1.0
        let back: [Double] = (0..<3).map { (c: Int) -> Double in
            let sum: Double = rgb[2][c] + rgb[3][c]
            return sum / 2 * k
        }
        for i in 0..<4 { rgb[i] = rgb[i].map { max(0, min(1, $0)) } }

        func mix(_ a: [Double], _ b: [Double]) -> [Double] {
            (0..<3).map { (c: Int) -> Double in
                let sum: Double = a[c] + b[c]
                return sum / 2
            }
        }
        let center: [Double] = (0..<3).map { (c: Int) -> Double in
            let sum: Double = rgb[0][c] + rgb[1][c] + rgb[2][c] + rgb[3][c]
            return sum / 4
        }
        let grid: [[Double]] = [
            rgb[0], mix(rgb[0], rgb[1]), rgb[1],
            mix(rgb[0], rgb[2]), center, mix(rgb[1], rgb[3]),
            rgb[2], mix(rgb[2], rgb[3]), rgb[3],
        ]
        func color(_ c: [Double]) -> Color { Color(.sRGB, red: c[0], green: c[1], blue: c[2], opacity: 1) }
        return CoverColors(
            quadrants: rgb.map { color($0) },
            backdrop: Color(.sRGB, red: back[0], green: back[1], blue: back[2], opacity: 1),
            mesh: grid.map { color($0) }
        )
    }
}
