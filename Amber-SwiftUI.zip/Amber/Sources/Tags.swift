import Foundation

struct RawTags {
    var title = ""
    var artist = ""
    var album = ""
    var albumArtist = ""
    var genre = ""
    var year = ""
    var track = 0
    var disc = 0
    var lyrics: String?     // plain or LRC text
    var art: Data?          // embedded cover bytes
}

enum TagReader {
    static func lrcStamp(_ t: Double) -> String {
        let m = Int(t / 60)
        let s = t - Double(m * 60)
        return String(format: "[%02d:%05.2f]", m, s)
    }

    static func read(_ url: URL) -> RawTags {
        guard let fh = try? FileHandle(forReadingFrom: url) else { return RawTags() }
        defer { try? fh.close() }
        let head = [UInt8]((try? fh.read(upToCount: 12)) ?? Data())
        if head.count >= 8, fourcc(head, 4) == "ftyp" { return readMP4(fh) }
        if head.count >= 10, head[0] == 0x49, head[1] == 0x44, head[2] == 0x33, head[3] >= 3 {
            return readID3(fh, header: head)
        }
        return RawTags()
    }

    // MARK: - Byte helpers

    private static func be32(_ b: [UInt8], _ o: Int) -> Int {
        guard o >= 0, o + 3 < b.count else { return 0 }
        let a = Int(b[o]) << 24
        let c = Int(b[o + 1]) << 16
        let d = Int(b[o + 2]) << 8
        let e = Int(b[o + 3])
        return a | c | d | e
    }

    private static func syncsafe(_ b: [UInt8], _ o: Int) -> Int {
        guard o >= 0, o + 3 < b.count else { return 0 }
        let a = Int(b[o]) << 21
        let c = Int(b[o + 1]) << 14
        let d = Int(b[o + 2]) << 7
        let e = Int(b[o + 3])
        return a | c | d | e
    }

    private static func fourcc(_ b: [UInt8], _ o: Int) -> String {
        guard o >= 0, o + 3 < b.count else { return "" }
        return String(bytes: b[o..<(o + 4)], encoding: .isoLatin1) ?? ""
    }

    private static func leadingInt(_ s: String) -> Int {
        Int(s.prefix(while: { $0.isNumber })) ?? 0
    }

    // MARK: - ID3 text decoding

    private static func decode(_ enc: UInt8, _ bytes: ArraySlice<UInt8>) -> String {
        var slice = bytes
        var string: String?
        switch enc {
        case 1, 2:
            var bigEndian = enc == 2
            if slice.count >= 2 {
                let first = slice[slice.startIndex]
                let second = slice[slice.startIndex + 1]
                if first == 0xFE, second == 0xFF { bigEndian = true; slice = slice.dropFirst(2) }
                else if first == 0xFF, second == 0xFE { bigEndian = false; slice = slice.dropFirst(2) }
            }
            string = String(data: Data(slice), encoding: bigEndian ? .utf16BigEndian : .utf16LittleEndian)
        case 3:
            string = String(data: Data(slice), encoding: .utf8)
        default:
            string = String(data: Data(slice), encoding: .windowsCP1252)
                ?? String(data: Data(slice), encoding: .isoLatin1)
        }
        var out = string ?? ""
        while out.hasSuffix("\u{0}") { out.removeLast() }
        return out
    }

    private static func text(_ d: [UInt8]) -> String {
        guard let enc = d.first, d.count > 1 else { return "" }
        return decode(enc, d[1...])
            .replacingOccurrences(of: "\u{0}", with: " / ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// Skips a (possibly UTF-16) terminated string starting at `start`; returns the index after it.
    private static func skipString(_ d: [UInt8], _ start: Int, _ enc: UInt8) -> Int {
        var i = start
        if enc == 1 || enc == 2 {
            while i + 1 < d.count && (d[i] != 0 || d[i + 1] != 0) { i += 2 }
            return i + 2
        }
        while i < d.count && d[i] != 0 { i += 1 }
        return i + 1
    }

    private static func pictureData(_ d: [UInt8]) -> Data? {
        guard d.count > 4 else { return nil }
        var i = 1
        while i < d.count && d[i] != 0 { i += 1 }   // MIME type
        i += 2                                       // NUL + picture type
        if d[0] == 1 || d[0] == 2 {
            while i + 1 < d.count && (d[i] != 0 || d[i + 1] != 0) { i += 2 }
            i += 2
        } else {
            while i < d.count && d[i] != 0 { i += 1 }
            i += 1
        }
        guard i < d.count, d.count - i > 100 else { return nil }
        return Data(d[i...])
    }

    private static func parseSYLT(_ d: [UInt8]) -> [(Double, String)] {
        let enc = d[0]
        let wide = enc == 1 || enc == 2
        var out: [(Double, String)] = []
        var i = skipString(d, 6, enc)
        while i < d.count - 4 {
            var j = i
            if wide {
                while j + 1 < d.count && (d[j] != 0 || d[j + 1] != 0) { j += 2 }
            } else {
                while j < d.count && d[j] != 0 { j += 1 }
            }
            var s = decode(enc, d[i..<min(j, d.count)])
            if s.hasPrefix("\n") { s.removeFirst() }
            i = j + (wide ? 2 : 1)
            if i + 4 > d.count { break }
            out.append((Double(be32(d, i)) / 1000, s))
            i += 4
        }
        return out.filter { !$0.1.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }

    // MARK: - ID3v2

    private static func readID3(_ fh: FileHandle, header h: [UInt8]) -> RawTags {
        var tags = RawTags()
        let version = h[3]
        let size = syncsafe(h, 6)
        guard size > 0 else { return tags }
        try? fh.seek(toOffset: 10)
        guard let body = try? fh.read(upToCount: size) else { return tags }
        let b = [UInt8](body)

        var p = 0
        if h[5] & 0x40 != 0 { p = version == 4 ? syncsafe(b, 0) : be32(b, 0) + 4 }   // extended header
        var uslt: String?
        var sylt: [(Double, String)] = []

        while p + 10 <= b.count, b[p] != 0 {
            let id = fourcc(b, p)
            let n = version == 4 ? syncsafe(b, p + 4) : be32(b, p + 4)
            let start = p + 10
            let end = min(start + n, b.count)
            p += 10 + n
            guard start <= end else { break }
            let d = Array(b[start..<end])

            switch id {
            case "TIT2": tags.title = text(d)
            case "TPE1": tags.artist = text(d)
            case "TALB": tags.album = text(d)
            case "TRCK": tags.track = leadingInt(text(d))
            case "TPOS": tags.disc = leadingInt(text(d))
            case "TDRC", "TYER": tags.year = String(text(d).prefix(4))
            case "TPE2": tags.albumArtist = text(d)
            case "TCON":
                tags.genre = text(d).replacingOccurrences(of: "^\\(\\d+\\)", with: "", options: .regularExpression)
            case "USLT":
                if uslt == nil, d.count > 4 {
                    let s = skipString(d, 4, d[0])
                    if s <= d.count { uslt = decode(d[0], d[s...]) }
                }
            case "SYLT":
                if sylt.isEmpty, d.count > 6, d[4] == 2 { sylt = parseSYLT(d) }
            case "APIC":
                if tags.art == nil { tags.art = pictureData(d) }
            default:
                break
            }
        }
        // synced lyrics win over plain lyrics (same order as the web app)
        if !sylt.isEmpty {
            tags.lyrics = sylt.map { lrcStamp($0.0) + $0.1 }.joined(separator: "\n")
        } else {
            tags.lyrics = uslt
        }
        return tags
    }

    // MARK: - MP4 / M4A

    private struct Box {
        let type: String
        let start: Int
        let end: Int
        let data: Int
    }

    private static func boxes(_ b: [UInt8], _ from: Int, _ to: Int) -> [Box] {
        var out: [Box] = []
        var s = from
        while s + 8 <= to {
            var n = be32(b, s)
            var headerSize = 8
            if n == 1 { n = be32(b, s + 12); headerSize = 16 }
            else if n == 0 { n = to - s }
            if n < headerSize { break }
            out.append(Box(type: fourcc(b, s + 4), start: s, end: min(s + n, to), data: s + headerSize))
            s += n
        }
        return out
    }

    private static func child(_ b: [UInt8], _ parent: Box, _ type: String) -> Box? {
        boxes(b, parent.data + (parent.type == "meta" ? 4 : 0), parent.end).first { $0.type == type }
    }

    private static func locateMoov(_ fh: FileHandle) -> (start: UInt64, size: Int)? {
        let total = (try? fh.seekToEnd()) ?? 0
        var pos: UInt64 = 0
        while pos + 8 <= total {
            guard (try? fh.seek(toOffset: pos)) != nil,
                  let chunk = try? fh.read(upToCount: 16), chunk.count >= 8 else { return nil }
            let b = [UInt8](chunk)
            var n = UInt64(be32(b, 0))
            if n == 1, b.count >= 16 { n = (UInt64(be32(b, 8)) << 32) | UInt64(be32(b, 12)) }
            else if n == 0 { n = total - pos }
            if fourcc(b, 4) == "moov" { return (pos, Int(n)) }
            if n < 8 { return nil }
            pos += n
        }
        return nil
    }

    private static func readMP4(_ fh: FileHandle) -> RawTags {
        var tags = RawTags()
        guard let loc = locateMoov(fh), loc.size > 8, loc.size < 64_000_000 else { return tags }
        try? fh.seek(toOffset: loc.start)
        guard let data = try? fh.read(upToCount: loc.size) else { return tags }
        let b = [UInt8](data)
        guard let moov = boxes(b, 0, b.count).first,
              let udta = child(b, moov, "udta"),
              let meta = child(b, udta, "meta"),
              let ilst = child(b, meta, "ilst") else { return tags }

        for item in boxes(b, ilst.data, ilst.end) {
            guard let box = boxes(b, item.data, item.end).first(where: { $0.type == "data" }),
                  box.data + 8 <= box.end else { continue }
            let v = Array(b[(box.data + 8)..<box.end])
            let str = (String(data: Data(v), encoding: .utf8) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            switch item.type {
            case "\u{A9}nam": tags.title = str
            case "\u{A9}ART": tags.artist = str
            case "\u{A9}alb": tags.album = str
            case "aART": tags.albumArtist = str
            case "\u{A9}gen": tags.genre = str
            case "\u{A9}day": tags.year = String(str.prefix(4))
            case "\u{A9}lyr": if !str.isEmpty { tags.lyrics = str }
            case "trkn": if v.count >= 4 { tags.track = Int(v[2]) << 8 | Int(v[3]) }
            case "disk": if v.count >= 4 { tags.disc = Int(v[2]) << 8 | Int(v[3]) }
            case "covr": if tags.art == nil, v.count > 100 { tags.art = Data(v) }
            default: break
            }
        }
        return tags
    }
}
