import MediaPlayer
import SwiftUI
import UIKit

struct NowPlayingView: View {
    let close: () -> Void
    let openAlbum: (String) -> Void
    let openArtist: (String) -> Void

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    @State private var showLyrics = false
    @State private var scrub: Double?
    @State private var editing: Track?

    private var art: ArtColors? { player.colors?.art }
    private var accent: Color { art?.accent ?? theme.ac }
    private var deep: Color { art?.deep ?? Color.black }
    private var key: String { player.current?.key ?? "" }
    /// Square by default; only a tall (3:4) animation stretches the artwork to full height.
    private var extended: Bool { library.isExtended(key) }
    private var alignment: HorizontalAlignment { theme.centered ? .center : .leading }
    private var frameAlignment: Alignment { theme.centered ? .center : .leading }

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()
            background.ignoresSafeArea()
            if extended && !showLyrics { tallHero }

            VStack(spacing: 0) {
                topBar
                if showLyrics {
                    LyricsView(lyrics: player.lyrics, credit: player.lyricsCredit)
                } else if extended {
                    Color.clear
                } else {
                    squareArt
                }
                panel
            }
        }
        .environment(\.art, art)
        .preferredColorScheme(.dark)
        .animation(.easeInOut(duration: 0.3), value: showLyrics)
        .sheet(item: $editing) { t in
            TagEditorSheet(trackID: t.id, offerAlbum: true)
                .environmentObject(library)
                .environmentObject(theme)
        }
    }

    // MARK: Backgrounds & artwork

    /// Apple Music's flowing colour mesh (from the cover) over OLED black. It runs under the status
    /// bar and the home indicator.
    @ViewBuilder
    private var background: some View {
        if showLyrics, theme.s.lyricsBackground == "blur", let key = player.current?.key {
            CoverView(url: library.assetURL(key, .cover), letter: "", maxSide: 400)
                .blur(radius: 60)
                .scaleEffect(1.5)
                .overlay(Color.black.opacity(0.55))
        } else {
            FlowBackground(colors: player.colors?.mesh ?? theme.fallbackMesh)
                .overlay(Color.black.opacity(0.34))
        }
    }

    private var squareVideo: URL? { library.assetURL(key, .anim) }

    private var squareArt: some View {
        ZStack {
            Color.clear
                .aspectRatio(1, contentMode: .fit)
                .overlay {
                    ZStack {
                        CoverView(
                            url: library.squareImageURL(key),
                            letter: player.current?.displayAlbum ?? "",
                            maxSide: 1400
                        )
                        if let squareVideo { LoopingVideoView(url: squareVideo, playing: player.isPlaying) }
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
                .shadow(color: Color.black.opacity(0.55), radius: 30, y: 16)
                .scaleEffect(player.isPlaying ? 1.0 : 0.9)
                .animation(.spring(response: 0.45, dampingFraction: 0.8), value: player.isPlaying)
                .gesture(swipe)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.horizontal, 28)
        .padding(.vertical, 8)
    }

    private var tallHero: some View {
        let video: URL? = library.assetURL(key, .tallanim)
        return Color.clear
            .aspectRatio(0.75, contentMode: .fit)
            .overlay {
                ZStack {
                    CoverView(
                        url: library.assetURL(key, .tall) ?? library.assetURL(key, .cover),
                        letter: player.current?.displayAlbum ?? "",
                        maxSide: 1400
                    )
                    if let video { LoopingVideoView(url: video, playing: player.isPlaying) }
                }
            }
            .mask(
                LinearGradient(
                    stops: [
                        .init(color: Color.black, location: 0),
                        .init(color: Color.black, location: 0.55),
                        .init(color: Color.clear, location: 1),
                    ],
                    startPoint: .top, endPoint: .bottom
                )
            )
            .clipped()
            .ignoresSafeArea(edges: .top)
            .gesture(swipe)
    }

    private var swipe: some Gesture {
        DragGesture(minimumDistance: 24).onEnded { v in
            let dx = v.translation.width
            let dy = v.translation.height
            if abs(dx) > 70, abs(dx) > abs(dy) {
                player.step(dx < 0 ? 1 : -1)
            } else if dy > 100 {
                close()
            }
        }
    }

    // MARK: Top bar

    private var topBar: some View {
        HStack(spacing: 12) {
            Button(action: close) { GlassIcon(symbol: "chevron.down", size: 44) }
                .buttonStyle(.plain)

            if showLyrics, let t = player.current {
                CoverView(url: library.assetURL(t.key, .cover), letter: t.displayAlbum, maxSide: 200)
                    .frame(width: 42, height: 42)
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                VStack(alignment: .leading, spacing: 1) {
                    Text(t.title).font(theme.serif(18)).foregroundStyle(Color.white).lineLimit(1)
                    Text(t.artist).font(.system(size: 13)).foregroundStyle(Color.white.opacity(0.7)).lineLimit(1)
                }
                Spacer(minLength: 0)
            } else {
                Spacer(minLength: 0)
                Text(player.current?.displayAlbum ?? "")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(Color.white.opacity(0.85))
                    .lineLimit(1)
                Spacer(minLength: 0)
            }

            moreMenu
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .frame(height: 60)
        .contentShape(Rectangle())
        .gesture(swipe)
    }

    private var moreMenu: some View {
        Menu {
            if let t = player.current {
                Button { openAlbum(t.key) } label: {
                    Label("Go to album", systemImage: "square.stack")
                }
                if !t.artistName.isEmpty {
                    Button { openArtist(t.artistName) } label: {
                        Label("Go to artist", systemImage: "person.crop.circle")
                    }
                }
                Button { editing = t } label: {
                    Label("Edit tags", systemImage: "pencil")
                }
            }
        } label: {
            GlassIcon(symbol: "ellipsis", size: 44)
        }
    }

    // MARK: Bottom panel

    private var panel: some View {
        VStack(alignment: alignment, spacing: 16) {
            if !showLyrics, let t = player.current { titleRow(t) }
            seekBar
            transport
            volume
            bottomRow
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 14)
        .padding(.top, 6)
    }

    private func titleRow(_ t: Track) -> some View {
        HStack(alignment: .center, spacing: 12) {
            titleBlock(t)
            likeButton(t)
        }
    }

    private func titleBlock(_ t: Track) -> some View {
        VStack(alignment: alignment, spacing: 6) {
            Text(t.title)
                .font(theme.title())
                .foregroundStyle(Color.white)
                .lineLimit(2)
                .minimumScaleFactor(0.6)
                .multilineTextAlignment(theme.centered ? .center : .leading)
                .frame(maxWidth: .infinity, alignment: frameAlignment)
            HStack(spacing: 6) {
                if !t.artistName.isEmpty {
                    Button { openArtist(t.artistName) } label: {
                        Text(t.artist.isEmpty ? t.artistName : t.artist)
                            .font(.system(size: 17, weight: .medium))
                            .foregroundStyle(accent)
                    }
                }
                if !t.album.isEmpty {
                    Text("·").foregroundStyle(Color.white.opacity(0.5))
                    Button { openAlbum(t.key) } label: {
                        Text(t.album)
                            .font(.system(size: 17))
                            .foregroundStyle(Color.white.opacity(0.75))
                            .lineLimit(1)
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: frameAlignment)
        }
        .contentShape(Rectangle())
        .gesture(swipe)
    }

    private func likeButton(_ t: Track) -> some View {
        let liked: Bool = library.isLiked(t)
        return Button { library.toggleLike(t) } label: {
            if liked {
                Image(systemName: "checkmark.circle.fill")
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(Color.white, accent)
                    .font(.system(size: 32))
            } else {
                Image(systemName: "plus.circle")
                    .foregroundStyle(Color.white.opacity(0.85))
                    .font(.system(size: 32))
            }
        }
        .buttonStyle(.plain)
    }

    private var seekBar: some View {
        let total = max(player.duration, 1)
        return VStack(spacing: 4) {
            Slider(
                value: Binding(
                    get: { scrub ?? min(player.position, total) },
                    set: { scrub = $0 }
                ),
                in: 0...total,
                onEditingChanged: { editing in
                    if !editing, let s = scrub {
                        player.seek(to: s)
                        scrub = nil
                    }
                }
            )
            .tint(accent)
            HStack {
                Text(formatTime(scrub ?? player.position))
                Spacer()
                Text("-" + formatTime(max(0, total - (scrub ?? player.position))))
            }
            .font(.system(size: 12).monospacedDigit())
            .foregroundStyle(Color.white.opacity(0.65))
        }
    }

    private var transport: some View {
        HStack(spacing: 46) {
            Button { player.step(-1) } label: {
                Image(systemName: "backward.fill").font(.system(size: 28))
            }
            Button { player.togglePlay() } label: {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(Color.white)
                    .frame(width: 76, height: 76)
                    .glassSurface(Circle(), tint: art?.glass, interactive: true)
            }
            Button { player.skip() } label: {
                Image(systemName: "forward.fill").font(.system(size: 28))
            }
        }
        .foregroundStyle(Color.white)
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity)
    }

    /// Device volume (the lock screen has its own system slider).
    private var volume: some View {
        HStack(spacing: 10) {
            Image(systemName: "speaker.fill")
                .font(.system(size: 13))
                .foregroundStyle(Color.white.opacity(0.6))
            SystemVolumeSlider(tint: UIColor(accent))
                .frame(height: 30)
            Image(systemName: "speaker.wave.3.fill")
                .font(.system(size: 13))
                .foregroundStyle(Color.white.opacity(0.6))
        }
    }

    private var bottomRow: some View {
        HStack {
            toggleButton("quote.bubble", on: showLyrics) { showLyrics.toggle() }
            Spacer()
            toggleButton("shuffle", on: player.shuffle) { player.shuffle.toggle() }
            Spacer()
            toggleButton(player.repeatMode == 2 ? "repeat.1" : "repeat", on: player.repeatMode != 0) {
                player.repeatMode = (player.repeatMode + 1) % 3
            }
            Spacer()
            toggleButton("pencil", on: false) { editing = player.current }
        }
        .padding(.horizontal, 10)
    }

    private func toggleButton(_ symbol: String, on: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(on ? accent : Color.white.opacity(0.65))
                .frame(width: 44, height: 44)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Lyrics

struct LyricsView: View {
    let lyrics: Lyrics?
    var credit: LyricsCredit?

    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    @State private var now: Double = 0
    private let tick = Timer.publish(every: 0.06, on: .main, in: .common).autoconnect()

    private var active: Int? { lyrics?.activeIndex(at: now) }
    private var dim: Color { Color.white.opacity(0.4) }

    var body: some View {
        if let lyrics, !lyrics.lines.isEmpty {
            ScrollViewReader { proxy in
                ScrollView(showsIndicators: false) {
                    LazyVStack(alignment: theme.centered ? .center : .leading, spacing: 18) {
                        ForEach(lyrics.lines) { line in
                            lineView(line, synced: lyrics.synced)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 120)
                }
                .safeAreaInset(edge: .bottom, spacing: 0) {
                    if let credit { attribution(credit) }
                }
                .onReceive(tick) { _ in now = player.currentTime }
                .onChange(of: active) { _, newValue in
                    guard let i = newValue else { return }
                    withAnimation(.easeInOut(duration: 0.55)) {
                        proxy.scrollTo(i, anchor: UnitPoint(x: 0.5, y: 0.3))
                    }
                }
                .onAppear { now = player.currentTime }
            }
        } else {
            VStack {
                Spacer()
                Text("No lyrics for this song")
                    .font(theme.serif(20))
                    .foregroundStyle(Color.white.opacity(0.6))
                Spacer()
            }
            .frame(maxWidth: .infinity)
        }
    }

    @ViewBuilder
    private func lineView(_ line: LyricLine, synced: Bool) -> some View {
        let isActive = synced && active == line.id
        Group {
            if isActive && !line.words.isEmpty {
                wordsText(line)
            } else {
                Text(line.text.isEmpty ? " " : line.text)
            }
        }
        .font(.system(size: 28, weight: .bold))
        .foregroundStyle(synced ? (isActive ? Color.white : dim) : Color.white.opacity(0.9))
        .multilineTextAlignment(theme.centered ? .center : .leading)
        .frame(maxWidth: .infinity, alignment: theme.centered ? .center : .leading)
        .id(line.id)
        .onTapGesture {
            if let t = line.time { player.seek(to: t) }
        }
    }

    private func wordsText(_ line: LyricLine) -> Text {
        var result = Text("")
        for w in line.words {
            let reached = now >= w.time - 0.05
            let piece = Text(w.text + (w.spaceAfter ? " " : ""))
                .foregroundStyle(reached ? Color.white : dim)
            result = result + piece
        }
        return result
    }
}


// MARK: - Lyrics attribution (required by the Spicy Lyrics API terms: provider, plus uploader/maker for community syncs)

extension LyricsView {
    func attribution(_ credit: LyricsCredit) -> some View {
        var text = AttributedString("Lyrics: " + credit.provider)
        for person in credit.people {
            var part = AttributedString(" · " + person.role + " ")
            var name = AttributedString(person.name)
            if let url = person.url { name.link = url }
            part.append(name)
            text.append(part)
        }
        return Text(text)
            .font(.system(size: 11))
            .foregroundStyle(Color.white.opacity(0.55))
            .tint(Color.white.opacity(0.8))
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 24)
            .padding(.vertical, 6)
    }
}
