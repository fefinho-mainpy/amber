import SwiftUI

struct NowPlayingView: View {
    let close: () -> Void
    let openAlbum: (String) -> Void
    let openArtist: (String) -> Void

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    @State private var showLyrics = false
    @State private var scrub: Double?
    @State private var editing: Track?

    private var backdrop: Color { player.colors?.backdrop ?? theme.bg }
    private var alignment: HorizontalAlignment { theme.centered ? .center : .leading }
    private var frameAlignment: Alignment { theme.centered ? .center : .leading }

    var body: some View {
        ZStack(alignment: .top) {
            backdrop.ignoresSafeArea()

            if showLyrics {
                lyricsBackground
            } else {
                hero
            }

            VStack(spacing: 0) {
                topBar
                if showLyrics {
                    LyricsView(lyrics: player.lyrics)
                } else {
                    Color.clear
                }
                panel
            }
        }
        .preferredColorScheme(.dark)
        .animation(.easeInOut(duration: 0.3), value: showLyrics)
        .sheet(item: $editing) { t in
            TagEditorSheet(trackID: t.id, offerAlbum: true)
                .environmentObject(library)
                .environmentObject(theme)
        }
    }

    // MARK: Backgrounds

    private var hero: some View {
        let key = player.current?.key ?? ""
        let tallVideo = library.assetURL(key, .tallanim)
        let video = tallVideo ?? library.assetURL(key, .anim)
        let isTall = tallVideo != nil || library.assetURL(key, .tall) != nil
        let dark = backdrop
        return Color.clear
            .aspectRatio(isTall ? 0.8 : 1.0, contentMode: .fit)
            .overlay {
                ZStack {
                    CoverView(url: library.heroImageURL(key), letter: player.current?.displayAlbum ?? "", maxSide: 1400)
                    if let video { LoopingVideoView(url: video, playing: player.isPlaying) }
                }
            }
            .overlay(alignment: .bottom) {
                LinearGradient(
                    colors: [dark.opacity(0), dark],
                    startPoint: .init(x: 0.5, y: 0.5), endPoint: .bottom
                )
            }
            .clipped()
            .ignoresSafeArea(edges: .top)
            .gesture(swipe)
    }

    @ViewBuilder
    private var lyricsBackground: some View {
        if theme.s.lyricsBackground == "blur", let key = player.current?.key {
            CoverView(url: library.assetURL(key, .cover), letter: "", maxSide: 400)
                .blur(radius: 60)
                .scaleEffect(1.5)
                .overlay(Color.black.opacity(0.35))
                .ignoresSafeArea()
        } else {
            FlowBackground(colors: player.colors?.mesh ?? theme.fallbackMesh)
                .overlay(Color.black.opacity(0.25))
                .ignoresSafeArea()
        }
    }

    private var swipe: some Gesture {
        DragGesture(minimumDistance: 24).onEnded { v in
            let dx = v.translation.width
            let dy = v.translation.height
            if abs(dx) > 70, abs(dx) > abs(dy) {
                player.step(dx < 0 ? 1 : -1)
            } else if dy > 100 {
                close()
            }
        }
    }

    // MARK: Top bar

    private var topBar: some View {
        HStack(spacing: 12) {
            Button(action: close) {
                Image(systemName: "chevron.down")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 40, height: 40)
                    .background(.black.opacity(0.28), in: Circle())
            }
            .buttonStyle(.plain)

            if showLyrics, let t = player.current {
                CoverView(url: library.assetURL(t.key, .cover), letter: t.displayAlbum, maxSide: 200)
                    .frame(width: 42, height: 42)
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                VStack(alignment: .leading, spacing: 1) {
                    Text(t.title).font(theme.serif(18)).foregroundStyle(.white).lineLimit(1)
                    Text(t.artist).font(.system(size: 13)).foregroundStyle(.white.opacity(0.7)).lineLimit(1)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .frame(height: 56)
        .contentShape(Rectangle())
        .gesture(swipe)
    }

    // MARK: Bottom panel

    private var panel: some View {
        VStack(alignment: alignment, spacing: 18) {
            if !showLyrics, let t = player.current { titleBlock(t) }
            seekBar
            transport
            bottomRow
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 18)
        .padding(.top, 6)
    }

    private func titleBlock(_ t: Track) -> some View {
        VStack(alignment: alignment, spacing: 6) {
            Text(t.title)
                .font(theme.title())
                .foregroundStyle(.white)
                .lineLimit(2)
                .minimumScaleFactor(0.6)
                .multilineTextAlignment(theme.centered ? .center : .leading)
                .frame(maxWidth: .infinity, alignment: frameAlignment)
            HStack(spacing: 6) {
                if !t.artistName.isEmpty {
                    Button { openArtist(t.artistName) } label: {
                        Text(t.artist.isEmpty ? t.artistName : t.artist)
                            .font(.system(size: 17, weight: .medium))
                            .foregroundStyle(theme.ac)
                    }
                }
                if !t.album.isEmpty {
                    Text("·").foregroundStyle(.white.opacity(0.5))
                    Button { openAlbum(t.key) } label: {
                        Text(t.album)
                            .font(.system(size: 17))
                            .foregroundStyle(.white.opacity(0.75))
                            .lineLimit(1)
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: frameAlignment)
        }
        .contentShape(Rectangle())
        .gesture(swipe)
    }

    private var seekBar: some View {
        let total = max(player.duration, 1)
        return VStack(spacing: 4) {
            Slider(
                value: Binding(
                    get: { scrub ?? min(player.position, total) },
                    set: { scrub = $0 }
                ),
                in: 0...total,
                onEditingChanged: { editing in
                    if !editing, let s = scrub {
                        player.seek(to: s)
                        scrub = nil
                    }
                }
            )
            .tint(theme.ac)
            HStack {
                Text(formatTime(scrub ?? player.position))
                Spacer()
                Text("-" + formatTime(max(0, total - (scrub ?? player.position))))
            }
            .font(.system(size: 12).monospacedDigit())
            .foregroundStyle(.white.opacity(0.65))
        }
    }

    private var transport: some View {
        HStack(spacing: 46) {
            Button { player.step(-1) } label: {
                Image(systemName: "backward.fill").font(.system(size: 28))
            }
            Button { player.togglePlay() } label: {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(theme.onAccent)
                    .frame(width: 74, height: 74)
                    .background(theme.ac, in: Circle())
            }
            Button { player.skip() } label: {
                Image(systemName: "forward.fill").font(.system(size: 28))
            }
        }
        .foregroundStyle(.white)
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity)
    }

    private var bottomRow: some View {
        HStack {
            toggleButton("quote.bubble", on: showLyrics) { showLyrics.toggle() }
            Spacer()
            toggleButton("shuffle", on: player.shuffle) { player.shuffle.toggle() }
            Spacer()
            toggleButton(player.repeatMode == 2 ? "repeat.1" : "repeat", on: player.repeatMode != 0) {
                player.repeatMode = (player.repeatMode + 1) % 3
            }
            Spacer()
            toggleButton("pencil", on: false) { editing = player.current }
        }
        .padding(.horizontal, 10)
    }

    private func toggleButton(_ symbol: String, on: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(on ? theme.ac : Color.white.opacity(0.65))
                .frame(width: 44, height: 44)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Lyrics

struct LyricsView: View {
    let lyrics: Lyrics?

    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    @State private var now: Double = 0
    private let tick = Timer.publish(every: 0.06, on: .main, in: .common).autoconnect()

    private var active: Int? { lyrics?.activeIndex(at: now) }
    private var dim: Color { Color.white.opacity(0.4) }

    var body: some View {
        if let lyrics, !lyrics.lines.isEmpty {
            ScrollViewReader { proxy in
                ScrollView(showsIndicators: false) {
                    LazyVStack(alignment: theme.centered ? .center : .leading, spacing: 18) {
                        ForEach(lyrics.lines) { line in
                            lineView(line, synced: lyrics.synced)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 120)
                }
                .onReceive(tick) { _ in now = player.currentTime }
                .onChange(of: active) { _, newValue in
                    guard let i = newValue else { return }
                    withAnimation(.easeInOut(duration: 0.55)) {
                        proxy.scrollTo(i, anchor: UnitPoint(x: 0.5, y: 0.3))
                    }
                }
                .onAppear { now = player.currentTime }
            }
        } else {
            VStack {
                Spacer()
                Text("No lyrics for this song")
                    .font(theme.serif(20))
                    .foregroundStyle(Color.white.opacity(0.6))
                Spacer()
            }
            .frame(maxWidth: .infinity)
        }
    }

    @ViewBuilder
    private func lineView(_ line: LyricLine, synced: Bool) -> some View {
        let isActive = synced && active == line.id
        Group {
            if isActive && !line.words.isEmpty {
                wordsText(line)
            } else {
                Text(line.text.isEmpty ? " " : line.text)
            }
        }
        .font(.system(size: 28, weight: .bold))
        .foregroundStyle(synced ? (isActive ? Color.white : dim) : Color.white.opacity(0.9))
        .multilineTextAlignment(theme.centered ? .center : .leading)
        .frame(maxWidth: .infinity, alignment: theme.centered ? .center : .leading)
        .id(line.id)
        .onTapGesture {
            if let t = line.time { player.seek(to: t) }
        }
    }

    private func wordsText(_ line: LyricLine) -> Text {
        var result = Text("")
        for w in line.words {
            let reached = now >= w.time - 0.05
            let piece = Text(w.text + (w.spaceAfter ? " " : ""))
                .foregroundStyle(reached ? Color.white : dim)
            result = result + piece
        }
        return result
    }
}
