import AVFoundation
import Combine
import MediaPlayer
import UIKit

final class Player: NSObject, ObservableObject, AVAudioPlayerDelegate {
    let library: Library

    @Published private(set) var current: Track?
    @Published private(set) var isPlaying = false
    @Published private(set) var position: TimeInterval = 0
    @Published private(set) var duration: TimeInterval = 0
    @Published private(set) var cover: UIImage?          // full-size cover of the current album
    @Published private(set) var colors: CoverColors?
    @Published private(set) var lyrics: Lyrics?
    @Published var shuffle = false
    @Published var repeatMode = 0                        // 0 off, 1 all, 2 one
    @Published private(set) var animatedLockScreen: Bool =
        UserDefaults.standard.object(forKey: "amber.animatedLock") as? Bool ?? true

    /// Live playback time (read by the lyrics view at display rate).
    var currentTime: TimeInterval { audio?.currentTime ?? 0 }

    private var queue: [Track]?                          // album/artist context; nil = whole library
    private var history: [Int] = []
    private var counted = false
    private var audio: AVAudioPlayer?
    private var timer: Timer?
    private var animatedCache: (key: String, version: Int, entries: [String: Any])?
    private var bag = Set<AnyCancellable>()

    init(library: Library) {
        self.library = library
        super.init()
        configureSession()
        configureRemoteCommands()
        library.onAssetsChanged = { [weak self] key in
            DispatchQueue.main.async { self?.assetsChanged(key) }
        }
        library.$tracks
            .dropFirst()
            .sink { [weak self] list in self?.libraryChanged(list) }
            .store(in: &bag)
        if let last = library.mostRecentlyPlayed() { load(last, autoplay: false) }
    }

    // MARK: - Loading & transport

    func play(_ t: Track, in context: [Track]?) {
        queue = context
        load(t, autoplay: true)
    }

    func playAll(_ list: [Track], shuffled: Bool) {
        guard !list.isEmpty else { return }
        queue = list
        if shuffled {
            shuffle = true
            load(library.pick(from: list, avoiding: [], current: nil) ?? list[0], autoplay: true)
        } else {
            load(list[0], autoplay: true)
        }
    }

    func load(_ t: Track, autoplay: Bool) {
        let newPlayer: AVAudioPlayer
        do {
            newPlayer = try AVAudioPlayer(contentsOf: library.fileURL(for: t))
        } catch {
            library.status = "Couldn’t play “\(t.title)”"
            return
        }
        newPlayer.delegate = self
        newPlayer.prepareToPlay()
        audio?.stop()
        audio = newPlayer

        current = t
        counted = false
        history.append(t.id)
        if history.count > 6 { history.removeFirst(history.count - 6) }
        duration = newPlayer.duration
        position = 0
        lyrics = library.lyrics(for: t)
        cover = nil
        colors = nil
        library.setCurrent(t.id)
        library.fetchOnline(for: t)

        if autoplay {
            newPlayer.play()
            isPlaying = true
            startTimer()
        } else {
            isPlaying = false
            stopTimer()
        }
        updateNowPlaying()
        refreshArtwork(for: t)
    }

    func togglePlay() {
        guard audio != nil else {
            if let first = library.tracks.first { queue = nil; load(first, autoplay: true) }
            return
        }
        setPlaying(!isPlaying)
    }

    func setPlaying(_ on: Bool) {
        guard let a = audio else { return }
        if on { a.play(); startTimer() } else { a.pause(); stopTimer() }
        isPlaying = on
        position = a.currentTime
        updateNowPlaying()
    }

    func seek(to time: TimeInterval) {
        guard let a = audio else { return }
        a.currentTime = max(0, min(time, a.duration))
        position = a.currentTime
        updateNowPlaying()
    }

    private func activeQueue() -> [Track] {
        if let q = queue, let c = current, q.contains(where: { $0.id == c.id }) { return q }
        return library.tracks
    }

    func step(_ d: Int) {
        let q = activeQueue()
        guard !q.isEmpty else { return }
        if d < 0, currentTime > 3 { seek(to: 0); return }
        let idx = q.firstIndex(where: { $0.id == current?.id }) ?? 0
        let next: Track
        if shuffle {
            next = library.pick(from: q, avoiding: history, current: current) ?? q[idx]
        } else {
            next = q[((idx + d) % q.count + q.count) % q.count]
        }
        load(next, autoplay: true)
    }

    /// "Next" pressed by the user: skipping early counts against the song's score.
    func skip() {
        if let c = current, !counted, currentTime < 20 {
            library.bump(c, play: false)
            counted = true
        }
        step(1)
    }

    func stop() {
        stopTimer()
        audio?.stop()
        audio = nil
        current = nil
        isPlaying = false
        position = 0
        duration = 0
        cover = nil
        colors = nil
        lyrics = nil
        animatedCache = nil
        library.setCurrent(nil)
        updateNowPlaying()
    }

    func setAnimatedLockScreen(_ on: Bool) {
        animatedLockScreen = on
        UserDefaults.standard.set(on, forKey: "amber.animatedLock")
        animatedCache = nil
        updateNowPlaying()
    }

    // MARK: - End of track

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.audio === player else { return }
            self.trackEnded()
        }
    }

    private func trackEnded() {
        if !counted, let c = current {
            library.bump(c, play: true)
            counted = true
        }
        if repeatMode == 2, let c = current { load(c, autoplay: true); return }
        let q = activeQueue()
        if repeatMode == 0, !shuffle, let c = current, q.last?.id == c.id {
            isPlaying = false
            stopTimer()
            audio?.currentTime = 0
            position = 0
            updateNowPlaying()
            return
        }
        step(1)
    }

    // MARK: - Timer

    private func startTimer() {
        timer?.invalidate()
        let t = Timer(timeInterval: 0.25, repeats: true) { [weak self] _ in
            guard let self, let a = self.audio else { return }
            self.position = a.currentTime
            if !self.counted, let c = self.current, a.currentTime > min(30, (self.duration > 0 ? self.duration : 60) * 0.5) {
                self.counted = true
                self.library.bump(c, play: true)
            }
        }
        RunLoop.main.add(t, forMode: .common)
        timer = t
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    // MARK: - Library callbacks

    private func libraryChanged(_ list: [Track]) {
        guard let cur = current else { return }
        if let fresh = list.first(where: { $0.id == cur.id }) {
            if fresh != cur {
                current = fresh
                lyrics = library.lyrics(for: fresh)
                updateNowPlaying()
            }
        } else {
            stop()
        }
    }

    private func assetsChanged(_ key: String) {
        guard let c = current, key.isEmpty || c.key == key else { return }
        animatedCache = nil
        refreshArtwork(for: c)
    }

    private func refreshArtwork(for t: Track) {
        let coverURL = library.assetURL(t.key, .cover)
        let hasCover = coverURL != nil
        Task { [weak self] in
            var image: UIImage?
            if let u = coverURL { image = await ImageLoader.load(u, maxSide: 1600) }
            let finalCover = image ?? ArtworkFactory.placeholder(title: t.displayAlbum, side: 1024)
            let palette = CoverColors.make(from: image, hasCover: hasCover)
            await MainActor.run {
                guard let self, self.current?.id == t.id else { return }
                self.cover = finalCover
                self.colors = palette
                self.updateNowPlaying()
            }
        }
    }

    // MARK: - Lock screen / Control Center

    func updateNowPlaying() {
        let center = MPNowPlayingInfoCenter.default()
        guard let t = current else {
            center.nowPlayingInfo = nil
            center.playbackState = .stopped
            return
        }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: t.title,
            MPMediaItemPropertyArtist: t.artist,
            MPMediaItemPropertyAlbumTitle: t.album,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: audio?.currentTime ?? 0,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0,
            MPNowPlayingInfoPropertyDefaultPlaybackRate: 1.0,
            MPNowPlayingInfoPropertyMediaType: MPNowPlayingInfoMediaType.audio.rawValue,
        ]
        if let cover {
            info[MPMediaItemPropertyArtwork] = StaticArtwork.make(from: cover)

            if animatedLockScreen, #available(iOS 26.0, *) {
                let version = library.assetVersion
                if animatedCache?.key != t.key || animatedCache?.version != version {
                    var tallStill: UIImage?
                    if let u = library.assetURL(t.key, .tall) { tallStill = UIImage(contentsOfFile: u.path) }
                    let source = LockScreenSource(
                        squareVideo: library.assetURL(t.key, .anim),
                        tallVideo: library.assetURL(t.key, .tallanim),
                        cover: cover,
                        tallStill: tallStill
                    )
                    let entries = AnimatedArtworkProvider.nowPlayingEntries(trackKey: t.key, source: source)
                    animatedCache = (t.key, version, entries)
                }
                for (k, v) in animatedCache?.entries ?? [:] { info[k] = v }
            }
        }
        center.nowPlayingInfo = info
        center.playbackState = isPlaying ? .playing : .paused
    }

    private func configureSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .default)
        try? session.setActive(true)
        NotificationCenter.default.addObserver(
            forName: AVAudioSession.interruptionNotification, object: nil, queue: .main
        ) { [weak self] note in
            guard let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
            if type == .began { self?.setPlaying(false) }
        }
    }

    private func bind(_ command: MPRemoteCommand, _ action: @escaping () -> Void) {
        command.isEnabled = true
        _ = command.addTarget { _ -> MPRemoteCommandHandlerStatus in
            DispatchQueue.main.async { action() }
            return .success
        }
    }

    private func configureRemoteCommands() {
        let cc = MPRemoteCommandCenter.shared()
        bind(cc.playCommand) { [weak self] in self?.setPlaying(true) }
        bind(cc.pauseCommand) { [weak self] in self?.setPlaying(false) }
        bind(cc.togglePlayPauseCommand) { [weak self] in self?.togglePlay() }
        bind(cc.nextTrackCommand) { [weak self] in self?.skip() }
        bind(cc.previousTrackCommand) { [weak self] in self?.step(-1) }
        cc.changePlaybackPositionCommand.isEnabled = true
        _ = cc.changePlaybackPositionCommand.addTarget { [weak self] event -> MPRemoteCommandHandlerStatus in
            if let e = event as? MPChangePlaybackPositionCommandEvent {
                let t = e.positionTime
                DispatchQueue.main.async { self?.seek(to: t) }
            }
            return .success
        }
    }
}
