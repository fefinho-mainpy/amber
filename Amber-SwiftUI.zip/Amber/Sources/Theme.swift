import SwiftUI

struct PaletteDef {
    let bg: UInt32      // page background
    let sf: UInt32      // surface
    let fg: UInt32      // text
    let mu: UInt32      // muted text
    let ln: UInt32      // lines
    let hue: Double     // default accent hue
    let light: Double   // accent lightness %
    let isLight: Bool
}

struct Settings: Codable, Equatable {
    var palette = "ember"
    var hue: Double?
    var font = "serif"            // serif | ital | sans
    var size = 46.0               // title size
    var align = "l"               // l | c
    var lyricsBackground = "flow" // flow | blur
    var onlineArtwork = true
}

final class Theme: ObservableObject {
    static let order = ["ember", "clay", "honey", "sand"]
    static let defs: [String: PaletteDef] = [
        "ember": PaletteDef(bg: 0x1a110c, sf: 0x261a13, fg: 0xf6e9dc, mu: 0xa58b78, ln: 0x3a291f, hue: 22, light: 62, isLight: false),
        "clay":  PaletteDef(bg: 0x241311, sf: 0x331c18, fg: 0xf8e5da, mu: 0xb78f80, ln: 0x47281f, hue: 10, light: 64, isLight: false),
        "honey": PaletteDef(bg: 0x1c1608, sf: 0x292010, fg: 0xf8ecce, mu: 0xad9a6c, ln: 0x3d3019, hue: 41, light: 60, isLight: false),
        "sand":  PaletteDef(bg: 0xf4eadb, sf: 0xeadbc5, fg: 0x2b1c10, mu: 0x86694e, ln: 0xd9c6a9, hue: 18, light: 42, isLight: true),
    ]
    private static let storageKey = "amber.settings"

    @Published private(set) var s: Settings

    init() {
        if let data = UserDefaults.standard.data(forKey: Self.storageKey),
           let saved = try? JSONDecoder().decode(Settings.self, from: data) {
            s = saved
        } else {
            s = Settings()
        }
    }

    func update(_ change: (inout Settings) -> Void) {
        var next = s
        change(&next)
        s = next
        if let data = try? JSONEncoder().encode(next) {
            UserDefaults.standard.set(data, forKey: Self.storageKey)
        }
    }

    // MARK: Derived values

    var def: PaletteDef { Self.defs[s.palette] ?? Self.defs["ember"]! }
    var bg: Color { Color(hex: def.bg) }
    var sf: Color { Color(hex: def.sf) }
    var fg: Color { Color(hex: def.fg) }
    var mu: Color { Color(hex: def.mu) }
    var ln: Color { Color(hex: def.ln) }
    var accentHue: Double { s.hue ?? def.hue }
    var ac: Color { hslColor(accentHue, 88, def.light) }
    /// Text colour on top of the accent colour.
    var onAccent: Color { def.isLight ? Color(hex: 0xfff6ec) : Color(hex: def.bg) }
    var scheme: ColorScheme { def.isLight ? .light : .dark }
    var centered: Bool { s.align == "c" }

    /// Mesh colours used when an album has no cover.
    var fallbackMesh: [Color] {
        let h = accentHue
        return (0..<9).map { i in
            hslColor(h + Double(i % 3) * 18 - Double(i / 3) * 12, 55, 16 + Double((i * 5) % 14))
        }
    }

    func paletteSwatch(_ id: String) -> Color {
        guard let d = Self.defs[id] else { return .gray }
        return d.isLight ? Color(hex: 0xc4561b) : hslColor(d.hue, 88, d.light)
    }

    func title(_ size: CGFloat? = nil) -> Font {
        let pt = size ?? CGFloat(s.size)
        switch s.font {
        case "sans": return .system(size: pt, weight: .semibold, design: .default)
        case "ital": return Font.system(size: pt, weight: .regular, design: .serif).italic()
        default: return .system(size: pt, weight: .regular, design: .serif)
        }
    }

    /// Small headings / labels use the serif face like the web app.
    func serif(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .serif)
    }
}
