import MediaPlayer
import SwiftUI
import UIKit

// MARK: - Colours taken from the artwork

/// Three shades derived from the cover / animation of the album on screen.
struct ArtColors: Equatable {
    let accent: Color   // bright: icons, progress, check marks
    let glass: Color    // mid: tint for glass buttons
    let deep: Color     // dark: page background wash
}

private struct ArtColorsKey: EnvironmentKey {
    static let defaultValue: ArtColors? = nil
}

extension EnvironmentValues {
    var art: ArtColors? {
        get { self[ArtColorsKey.self] }
        set { self[ArtColorsKey.self] = newValue }
    }
}

final class PaletteCache {
    static let shared = PaletteCache()
    private var store: [String: CoverColors] = [:]
    private let lock = NSLock()

    func get(_ key: String) -> CoverColors? {
        lock.lock()
        defer { lock.unlock() }
        return store[key]
    }

    func set(_ key: String, _ value: CoverColors) {
        lock.lock()
        store[key] = value
        lock.unlock()
    }
}

enum ArtPalette {
    /// Colours of an album's artwork (cover first, then the first frame of its animation).
    static func colors(for key: String, library: Library) async -> CoverColors? {
        let cacheKey: String = key + "|" + String(library.assetVersion)
        if let hit = PaletteCache.shared.get(cacheKey) { return hit }

        var image: UIImage?
        if let url = library.assetURL(key, .cover) ?? library.assetURL(key, .tall) {
            image = await ImageLoader.load(url, maxSide: 160)
        }
        if image == nil, let video = library.assetURL(key, .anim) ?? library.assetURL(key, .tallanim) {
            image = await ArtworkRenderer.firstFrame(of: video)
        }
        guard let image, let colors = CoverColors.make(from: image, hasCover: true) else { return nil }
        PaletteCache.shared.set(cacheKey, colors)
        return colors
    }
}

/// Publishes the album's artwork colours to everything inside (`@Environment(\.art)`).
struct ArtTinted: ViewModifier {
    let key: String?

    @EnvironmentObject private var library: Library
    @State private var colors: CoverColors?

    func body(content: Content) -> some View {
        content
            .environment(\.art, colors?.art)
            .task(id: taskID) {
                guard let key else { colors = nil; return }
                colors = await ArtPalette.colors(for: key, library: library)
            }
    }

    private var taskID: String {
        (key ?? "") + "|" + String(library.assetVersion)
    }
}

extension View {
    func artTinted(key: String?) -> some View { modifier(ArtTinted(key: key)) }
}

// MARK: - Liquid glass

/// iOS 26 liquid glass, with a material fallback for older systems.
struct GlassSurface<S: Shape>: ViewModifier {
    let shape: S
    var tint: Color?
    var interactive: Bool

    func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(Self.makeGlass(tint: tint, interactive: interactive), in: shape)
        } else {
            content
                .background(shape.fill(Material.ultraThinMaterial))
                .background(shape.fill(fallbackFill))
                .overlay(shape.stroke(Color.white.opacity(0.14), lineWidth: 0.6))
        }
    }

    private var fallbackFill: Color {
        if let tint { return tint.opacity(0.35) }
        return Color.white.opacity(0.06)
    }

    @available(iOS 26.0, *)
    private static func makeGlass(tint: Color?, interactive: Bool) -> Glass {
        var glass: Glass = .regular
        if let tint { glass = glass.tint(tint) }
        if interactive { glass = glass.interactive() }
        return glass
    }
}

extension View {
    func glassSurface<S: Shape>(_ shape: S, tint: Color? = nil, interactive: Bool = false) -> some View {
        modifier(GlassSurface(shape: shape, tint: tint, interactive: interactive))
    }
}

/// Round glass icon, tinted with the artwork colour. Use as a Button / Menu label.
struct GlassIcon: View {
    let symbol: String
    var size: CGFloat = 48
    var tint: Color?

    @Environment(\.art) private var art

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.38, weight: .semibold))
            .foregroundStyle(Color.white)
            .frame(width: size, height: size)
            .glassSurface(Circle(), tint: tint ?? art?.glass, interactive: true)
            .contentShape(Circle())
    }
}

/// [shuffle]  [ Play ]  [more]  — the action row used on album / artist pages.
struct ActionRow: View {
    let play: () -> Void
    let shuffle: () -> Void
    var trailing: AnyView?

    var body: some View {
        HStack(spacing: 16) {
            Button(action: shuffle) { GlassIcon(symbol: "shuffle", size: 52) }
                .buttonStyle(.plain)

            Button(action: play) {
                HStack(spacing: 8) {
                    Image(systemName: "play.fill").font(.system(size: 16, weight: .bold))
                    Text("Play").font(.system(size: 18, weight: .semibold))
                }
                .foregroundStyle(Color.black)
                .frame(maxWidth: .infinity)
                .frame(height: 52)
                .background(Color.white, in: Capsule())
            }
            .buttonStyle(.plain)

            if let trailing {
                trailing
            } else {
                Color.clear.frame(width: 52, height: 52)
            }
        }
        .padding(.horizontal, 6)
    }
}

// MARK: - System volume

/// The real device volume slider (the lock screen draws its own, iOS owns that one).
struct SystemVolumeSlider: UIViewRepresentable {
    var tint: UIColor

    func makeUIView(context: Context) -> MPVolumeView {
        let view = MPVolumeView(frame: .zero)
        view.tintColor = tint
        return view
    }

    func updateUIView(_ uiView: MPVolumeView, context: Context) {
        uiView.tintColor = tint
    }
}

// MARK: - Artwork lookups

extension Library {
    /// Still used for square areas (cover first).
    func squareImageURL(_ key: String) -> URL? {
        assetURL(key, .cover) ?? assetURL(key, .tall)
    }

    /// Albums are square unless they carry a tall (3:4) animation.
    func isExtended(_ key: String) -> Bool {
        assetURL(key, .tallanim) != nil
    }
}
