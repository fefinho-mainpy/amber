import Foundation

struct LyricWord {
    let text: String
    let time: Double
    var spaceAfter: Bool
}

struct LyricLine: Identifiable {
    let id: Int
    let time: Double?
    let text: String
    let words: [LyricWord]
}

struct Lyrics {
    let synced: Bool
    let lines: [LyricLine]

    /// Index of the line that is current at time `t` (lead time like the web app), or nil before the first line.
    func activeIndex(at t: Double) -> Int? {
        guard synced else { return nil }
        var found: Int?
        for line in lines {
            guard let lt = line.time else { continue }
            if lt <= t + 0.12 { found = line.id } else { break }
        }
        return found
    }
}

enum LyricsParser {
    static func parse(_ raw: String) -> Lyrics? {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return nil }
        if text.contains("<tt"), let ttml = parseTTML(text) { return ttml }
        return parseLRC(text)
    }

    // MARK: LRC / plain

    private static let stampRegex = try! NSRegularExpression(pattern: "\\[(\\d+):(\\d+(?:\\.\\d+)?)\\]")
    private static let stripRegex = try! NSRegularExpression(pattern: "\\[[^\\]]*\\]|<[^>]*>")

    static func parseLRC(_ text: String) -> Lyrics {
        var timed: [(Double, String)] = []
        var plain: [String] = []
        for rawLine in text.components(separatedBy: .newlines) {
            let ns = rawLine as NSString
            let range = NSRange(location: 0, length: ns.length)
            let stamps = stampRegex.matches(in: rawLine, range: range)
            let cleaned = stripRegex
                .stringByReplacingMatches(in: rawLine, range: range, withTemplate: "")
                .trimmingCharacters(in: .whitespaces)
            plain.append(rawLine.trimmingCharacters(in: .whitespaces))
            if stamps.isEmpty || cleaned.isEmpty { continue }
            for m in stamps {
                let minutes = Double(ns.substring(with: m.range(at: 1))) ?? 0
                let seconds = Double(ns.substring(with: m.range(at: 2))) ?? 0
                timed.append((minutes * 60 + seconds, cleaned))
            }
        }
        if !timed.isEmpty {
            let sorted = timed.sorted { $0.0 < $1.0 }
            let lines = sorted.enumerated().map { i, l in
                LyricLine(id: i, time: l.0, text: l.1, words: [])
            }
            return Lyrics(synced: true, lines: lines)
        }
        // plain text: trim blank lines at both ends, keep blank lines between stanzas
        while plain.first?.isEmpty == true { plain.removeFirst() }
        while plain.last?.isEmpty == true { plain.removeLast() }
        let lines = plain.enumerated().map { i, s in LyricLine(id: i, time: nil, text: s, words: []) }
        return Lyrics(synced: false, lines: lines)
    }

    // MARK: TTML (Apple-style, with optional per-word timing)

    static func ttmlTime(_ raw: String) -> Double {
        let x = raw.trimmingCharacters(in: .whitespaces)
        if x.isEmpty { return 0 }
        if x.hasSuffix("ms") { return (Double(x.dropLast(2)) ?? 0) / 1000 }
        if x.hasSuffix("s") { return Double(x.dropLast()) ?? 0 }
        return x.split(separator: ":").reduce(0.0) { $0 * 60 + (Double($1) ?? 0) }
    }

    static func parseTTML(_ xml: String) -> Lyrics? {
        guard let data = xml.data(using: .utf8) else { return nil }
        let delegate = TTMLDelegate()
        let parser = XMLParser(data: data)
        parser.delegate = delegate
        guard parser.parse(), !delegate.lines.isEmpty else { return nil }
        let lines = delegate.lines.enumerated().map { i, l in
            LyricLine(id: i, time: l.time, text: l.text, words: l.words)
        }
        let synced = lines.contains { $0.time != nil }
        return Lyrics(synced: synced, lines: lines)
    }
}

private final class TTMLDelegate: NSObject, XMLParserDelegate {
    struct Line { let time: Double?; let text: String; let words: [LyricWord] }
    var lines: [Line] = []

    private var inParagraph = false
    private var depth = 0
    private var paragraphBegin: String?
    private var text = ""
    private var words: [LyricWord] = []
    private var spanBegin: String?
    private var spanText = ""
    private var spanSkip = false

    private func local(_ name: String) -> String {
        String(name.split(separator: ":").last ?? Substring(name))
    }

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?,
                qualifiedName qName: String?, attributes attributeDict: [String: String]) {
        let name = local(elementName)
        if name == "p" && !inParagraph {
            inParagraph = true
            depth = 0
            paragraphBegin = attributeDict["begin"]
            text = ""
            words = []
            return
        }
        guard inParagraph else { return }
        depth += 1
        if depth == 1 {
            spanBegin = attributeDict["begin"]
            spanText = ""
            spanSkip = attributeDict.values.contains { v in
                v.range(of: "x-(translation|roman)", options: .regularExpression) != nil
            }
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        guard inParagraph else { return }
        if depth == 0 {
            text += string
            if !words.isEmpty, string.rangeOfCharacter(from: .whitespacesAndNewlines) != nil {
                words[words.count - 1].spaceAfter = true
            }
        } else if depth >= 1, !spanSkip {
            spanText += string
        }
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?,
                qualifiedName qName: String?) {
        guard inParagraph else { return }
        let name = local(elementName)
        if depth == 0 {
            if name == "p" {
                inParagraph = false
                let collapsed = text
                    .components(separatedBy: .whitespacesAndNewlines)
                    .filter { !$0.isEmpty }
                    .joined(separator: " ")
                if !collapsed.isEmpty {
                    let time = paragraphBegin.map { LyricsParser.ttmlTime($0) } ?? words.first?.time
                    lines.append(Line(time: time, text: collapsed, words: words))
                }
            }
            return
        }
        depth -= 1
        if depth == 0, !spanSkip {
            text += spanText
            if let begin = spanBegin {
                words.append(LyricWord(text: spanText, time: LyricsParser.ttmlTime(begin), spaceAfter: false))
            }
        }
    }
}
