import SwiftUI
import UniformTypeIdentifiers

// MARK: - Customize

struct CustomizeSheet: View {
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme
    @EnvironmentObject private var services: Services
    @Environment(\.dismiss) private var dismiss

    @State private var bytes: Int64 = 0
    @State private var confirmClear = false

    private func binding<T>(_ get: @escaping () -> T, _ set: @escaping (T) -> Void) -> Binding<T> {
        Binding(get: get, set: set)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Palette") {
                    HStack(spacing: 18) {
                        ForEach(Theme.order, id: \.self) { id in
                            Button {
                                theme.update { $0.palette = id; $0.hue = nil }
                            } label: {
                                VStack(spacing: 6) {
                                    Circle()
                                        .fill(theme.paletteSwatch(id))
                                        .frame(width: 34, height: 34)
                                        .overlay(Circle().stroke(theme.fg, lineWidth: theme.s.palette == id ? 2.5 : 0).padding(-4))
                                    Text(id == "oled" ? "OLED" : id.capitalized)
                                        .font(.system(size: 12))
                                        .foregroundStyle(theme.s.palette == id ? theme.fg : theme.mu)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)

                    VStack(alignment: .leading) {
                        Text("Accent hue").font(.system(size: 13)).foregroundStyle(theme.mu)
                        Slider(
                            value: binding({ theme.accentHue }, { v in theme.update { $0.hue = v } }),
                            in: 0...360
                        )
                    }
                }
                .listRowBackground(theme.sf)

                Section("Now Playing") {
                    Picker("Title font", selection: binding({ theme.s.font }, { v in theme.update { $0.font = v } })) {
                        Text("Serif").tag("serif")
                        Text("Italic").tag("ital")
                        Text("Sans").tag("sans")
                    }
                    .pickerStyle(.segmented)

                    VStack(alignment: .leading) {
                        Text("Title size").font(.system(size: 13)).foregroundStyle(theme.mu)
                        Slider(
                            value: binding({ theme.s.size }, { v in theme.update { $0.size = v } }),
                            in: 28...72, step: 1
                        )
                    }

                    Picker("Alignment", selection: binding({ theme.s.align }, { v in theme.update { $0.align = v } })) {
                        Text("Left").tag("l")
                        Text("Center").tag("c")
                    }
                    .pickerStyle(.segmented)

                    Picker("Lyrics background", selection: binding({ theme.s.lyricsBackground }, { v in theme.update { $0.lyricsBackground = v } })) {
                        Text("Flowing").tag("flow")
                        Text("Blurred").tag("blur")
                    }
                    .pickerStyle(.segmented)
                }
                .listRowBackground(theme.sf)

                Section {
                    Toggle(
                        "Animated lock-screen artwork",
                        isOn: binding({ player.animatedLockScreen }, { player.setAnimatedLockScreen($0) })
                    )
                    Toggle(
                        "Look up animated artwork online",
                        isOn: binding({ theme.s.onlineArtwork }, { v in theme.update { $0.onlineArtwork = v } })
                    )
                } header: {
                    Text("Lock screen")
                } footer: {
                    Text(lockScreenStatus)
                }
                .listRowBackground(theme.sf)

                Section {
                    Picker("Photo source", selection: $services.artistSource) {
                        ForEach(ArtistSource.allCases) { source in
                            Text(source.title).tag(source)
                        }
                    }
                    if services.artistSource == .apple {
                        SecureField("Developer token (JWT)", text: $services.appleToken)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        TextField("Storefront (us, br, jp…)", text: $services.appleStorefront)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                } header: {
                    Text("Artist artwork")
                } footer: {
                    Text("Apple Music's and Spotify's public APIs only return the artist photo. Banners, logos and animated backgrounds are added on the artist page from Photos or Files.")
                }
                .listRowBackground(theme.sf)

                Section {
                    TextField("Client ID", text: $services.spotifyID)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    SecureField("Client secret", text: $services.spotifySecret)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } header: {
                    Text("Spotify API")
                } footer: {
                    Text("Create an app at developer.spotify.com. Used for artist photos and to find the Spotify track id the lyrics API needs.")
                }
                .listRowBackground(theme.sf)

                Section {
                    SecureField("Spicy Lyrics key (sl_sk_…)", text: $services.spicyKey)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Toggle("Prefer Spicy Lyrics over local lyrics", isOn: $services.preferSpicy)
                } header: {
                    Text("Lyrics")
                } footer: {
                    Text(services.hasSpicy
                        ? "Used when a song has no lyrics of its own. Needs your own key from developers.spicylyrics.org; the source is credited under the lyrics."
                        : "Needs a Spicy Lyrics key from developers.spicylyrics.org and the Spotify API fields above.")
                }
                .listRowBackground(theme.sf)

                Section {
                    Button("Sync from Apple Music") {
                        Task { await AppleMusicSync.run(into: library) }
                        dismiss()
                    }
                } header: {
                    Text("Apple Music library")
                } footer: {
                    Text("Copies the downloaded, DRM-free songs of the Music app as AAC. Streaming and protected songs can't be exported by iOS. Songs already synced are skipped.")
                }
                .listRowBackground(theme.sf)

                Section("Storage") {
                    HStack {
                        Text("Library on this device")
                        Spacer()
                        Text(ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file))
                            .foregroundStyle(theme.mu)
                    }
                    Button("Clear library", role: .destructive) { confirmClear = true }
                }
                .listRowBackground(theme.sf)
            }
            .scrollContentBackground(.hidden)
            .background(theme.bg)
            .foregroundStyle(theme.fg)
            .navigationTitle("Customize")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .task {
                let lib = library
                bytes = await Task.detached { lib.storageBytes() }.value
            }
            .confirmationDialog("Remove every song, cover and setting from this device?", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("Clear library", role: .destructive) {
                    player.stop()
                    library.clearAll()
                    bytes = 0
                }
            }
        }
        .preferredColorScheme(theme.scheme)
    }

    private var lockScreenStatus: String {
        if #available(iOS 26.0, *) {
            return AnimatedArtworkProvider.statusText + ". Needs iOS 26. Album animations are used when you have them; otherwise a loop is generated from the cover."
        }
        return "Animated lock-screen artwork needs iOS 26 or later."
    }
}

// MARK: - Tag editor

struct TagEditorSheet: View {
    let trackID: Int
    let offerAlbum: Bool

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var theme: Theme
    @Environment(\.dismiss) private var dismiss

    @State private var edit = TrackEdit()
    @State private var loaded = false
    @State private var showArtworkImporter = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Title", text: $edit.title)
                    TextField("Artist", text: $edit.artist)
                    TextField("Album artist", text: $edit.albumArtist)
                    TextField("Album", text: $edit.album)
                    TextField("Genre", text: $edit.genre)
                }
                .listRowBackground(theme.sf)

                Section {
                    TextField("Year", text: $edit.year).keyboardType(.numberPad)
                    TextField("Track", value: $edit.no, format: .number).keyboardType(.numberPad)
                    TextField("Disc", value: $edit.disc, format: .number).keyboardType(.numberPad)
                }
                .listRowBackground(theme.sf)

                if offerAlbum {
                    Section {
                        Toggle("Apply album, genre and year to the whole album", isOn: $edit.applyToAlbum)
                        Button("Choose cover or animation…") { showArtworkImporter = true }
                    }
                    .listRowBackground(theme.sf)
                }

                Section("Lyrics (plain, LRC or TTML)") {
                    TextEditor(text: $edit.lyrics)
                        .frame(minHeight: 180)
                        .font(.system(size: 14, design: .monospaced))
                        .scrollContentBackground(.hidden)
                }
                .listRowBackground(theme.sf)
            }
            .scrollContentBackground(.hidden)
            .background(theme.bg)
            .foregroundStyle(theme.fg)
            .navigationTitle("Edit tags")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        library.apply(edit, to: trackID)
                        dismiss()
                    }
                    .fontWeight(.semibold)
                }
            }
            .onAppear(perform: load)
            .fileImporter(isPresented: $showArtworkImporter, allowedContentTypes: [.image, .movie], allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first, let t = library.track(id: trackID) {
                    Task { await library.importArtwork(from: url, forKey: t.key) }
                }
            }
        }
        .preferredColorScheme(theme.scheme)
    }

    private func load() {
        guard !loaded, let t = library.track(id: trackID) else { return }
        loaded = true
        edit = TrackEdit(
            title: t.title, artist: t.artist, albumArtist: t.albumArtist, album: t.album,
            genre: t.genre, year: t.year, no: t.no, disc: t.disc,
            lyrics: library.rawLyrics(of: t), applyToAlbum: false
        )
    }
}
