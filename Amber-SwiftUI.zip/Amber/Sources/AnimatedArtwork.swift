import AVFoundation
import CoreVideo
import MediaPlayer
import UIKit

// MARK: - Rendering a seamless looping clip from a cover image

enum RenderError: Error {
    case badImage
    case writerFailed
}

enum ArtworkRenderer {
    static let fps = 30
    static let seconds = 6
    static let size1x1 = CGSize(width: 720, height: 720)   // 1:1 variant
    static let size3x4 = CGSize(width: 720, height: 960)   // 3:4 variant
    /// Bump when the drawing code changes so previously cached clips are not reused.
    static let renderVersion = "v1"

    private static let bitmapInfo: UInt32 =
        CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue

    static func artworkID(trackID: String, variant: String) -> String {
        "\(trackID)|\(variant)|\(renderVersion)"
    }

    // MARK: Cache location

    static var cacheDirectory: URL {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("AnimatedArtwork", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func cacheURL(for id: String) -> URL {
        cacheDirectory.appendingPathComponent(String(stableHash(id), radix: 16) + ".mp4")
    }

    /// Keeps the cache small by deleting the oldest clips.
    static func pruneCache(maxFiles: Int = 24) {
        let fm = FileManager.default
        guard let files = try? fm.contentsOfDirectory(
            at: cacheDirectory,
            includingPropertiesForKeys: [.contentModificationDateKey]
        ), files.count > maxFiles else { return }

        func modified(_ url: URL) -> Date {
            (try? url.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
        }
        let oldestFirst = files.sorted { modified($0) < modified($1) }
        for file in oldestFirst.prefix(files.count - maxFiles) {
            try? fm.removeItem(at: file)
        }
    }

    // MARK: Drawing

    /// Converts any UIImage to an upright, size-limited CGImage.
    static func normalizedCGImage(_ image: UIImage, maxSide: CGFloat = 1600) -> CGImage? {
        let longest = max(image.size.width, image.size.height)
        guard longest > 0 else { return nil }
        let k = min(1, maxSide / longest)
        let target = CGSize(width: (image.size.width * k).rounded(), height: (image.size.height * k).rounded())
        let format = UIGraphicsImageRendererFormat.preferred()
        format.scale = 1
        format.opaque = true
        let rendered = UIGraphicsImageRenderer(size: target, format: format).image { _ in
            image.draw(in: CGRect(origin: .zero, size: target))
        }
        return rendered.cgImage
    }

    /// Draws one frame. `phase` runs 0..<1 and every motion is periodic in it,
    /// so the last frame flows straight back into the first (seamless loop).
    static func drawFrame(_ ctx: CGContext, size: CGSize, art: CGImage, phase: Double) {
        let w = size.width
        let h = size.height
        let angle = phase * 2.0 * Double.pi

        ctx.setFillColor(CGColor(gray: 0, alpha: 1))
        ctx.fill(CGRect(origin: .zero, size: size))

        // Cover-fill the frame with a slow "breathing" zoom and a gentle drift.
        let iw = CGFloat(art.width)
        let ih = CGFloat(art.height)
        let coverScale = max(w / iw, h / ih)
        let zoom = CGFloat(1.14 + 0.05 * sin(angle))
        let dw = iw * coverScale * zoom
        let dh = ih * coverScale * zoom
        let dx = (w - dw) / 2 + CGFloat(cos(angle)) * w * 0.025
        let dy = (h - dh) / 2 + CGFloat(sin(angle)) * h * 0.020
        ctx.interpolationQuality = .high
        ctx.draw(art, in: CGRect(x: dx, y: dy, width: dw, height: dh))

        let space = CGColorSpaceCreateDeviceRGB()

        // A soft highlight that glides around the artwork.
        let glow = [
            CGColor(red: 1, green: 1, blue: 1, alpha: 0.24),
            CGColor(red: 1, green: 1, blue: 1, alpha: 0.0),
        ] as CFArray
        if let gradient = CGGradient(colorsSpace: space, colors: glow, locations: [0, 1]) {
            let cx = w * (0.5 + 0.35 * CGFloat(cos(angle)))
            let cy = h * (0.5 + 0.30 * CGFloat(sin(angle * 2)))
            let c = CGPoint(x: cx, y: cy)
            ctx.drawRadialGradient(
                gradient, startCenter: c, startRadius: 0,
                endCenter: c, endRadius: max(w, h) * 0.6, options: []
            )
        }

        // Vignette so lock-screen controls stay readable.
        let dark = [
            CGColor(gray: 0, alpha: 0.0),
            CGColor(gray: 0, alpha: 0.45),
        ] as CFArray
        if let gradient = CGGradient(colorsSpace: space, colors: dark, locations: [0, 1]) {
            let c = CGPoint(x: w / 2, y: h / 2)
            ctx.drawRadialGradient(
                gradient, startCenter: c, startRadius: min(w, h) * 0.35,
                endCenter: c, endRadius: max(w, h) * 0.75, options: [.drawsAfterEndLocation]
            )
        }
    }

    /// The still shown while the video loads (and when Reduce Motion / Low Power Mode is on).
    /// It is exactly frame 0 of the clip, as Apple recommends.
    static func previewImage(source: UIImage, size: CGSize) -> UIImage? {
        guard let art = normalizedCGImage(source),
              let ctx = CGContext(
                data: nil,
                width: Int(size.width),
                height: Int(size.height),
                bitsPerComponent: 8,
                bytesPerRow: 0,
                space: CGColorSpaceCreateDeviceRGB(),
                bitmapInfo: bitmapInfo
              )
        else { return nil }
        drawFrame(ctx, size: size, art: art, phase: 0)
        guard let image = ctx.makeImage() else { return nil }
        return UIImage(cgImage: image)
    }

    // MARK: Video writing

    static func renderLoop(source: UIImage, size: CGSize, to url: URL) async throws {
        guard let art = normalizedCGImage(source) else { throw RenderError.badImage }
        let width = Int(size.width)
        let height = Int(size.height)

        // Write to a temporary file first so a half-written clip is never mistaken for a cached one.
        let partial = url.deletingLastPathComponent()
            .appendingPathComponent("partial-" + url.lastPathComponent)
        try? FileManager.default.removeItem(at: partial)

        let writer = try AVAssetWriter(outputURL: partial, fileType: .mp4)

        let compression: [String: Any] = [
            AVVideoAverageBitRateKey: 4_000_000,
            AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
        ]
        let settings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: compression,
        ]
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        input.expectsMediaDataInRealTime = false

        let attributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA),
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height,
        ]
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: input,
            sourcePixelBufferAttributes: attributes
        )

        guard writer.canAdd(input) else { throw RenderError.writerFailed }
        writer.add(input)
        guard writer.startWriting() else { throw writer.error ?? RenderError.writerFailed }
        writer.startSession(atSourceTime: .zero)

        let space = CGColorSpaceCreateDeviceRGB()
        let total = fps * seconds

        for i in 0..<total {
            while !input.isReadyForMoreMediaData {
                try await Task.sleep(nanoseconds: 2_000_000)
            }
            guard let pool = adaptor.pixelBufferPool else { throw RenderError.writerFailed }

            var created: CVPixelBuffer?
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &created)
            guard let buffer = created else { throw RenderError.writerFailed }

            CVPixelBufferLockBaseAddress(buffer, [])
            if let base = CVPixelBufferGetBaseAddress(buffer),
               let ctx = CGContext(
                data: base,
                width: width,
                height: height,
                bitsPerComponent: 8,
                bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
                space: space,
                bitmapInfo: bitmapInfo
               ) {
                drawFrame(ctx, size: size, art: art, phase: Double(i) / Double(total))
            }
            CVPixelBufferUnlockBaseAddress(buffer, [])

            let time = CMTime(value: CMTimeValue(i), timescale: CMTimeScale(fps))
            if !adaptor.append(buffer, withPresentationTime: time) {
                throw writer.error ?? RenderError.writerFailed
            }
        }

        input.markAsFinished()
        await writer.finishWriting()
        guard writer.status == .completed else { throw writer.error ?? RenderError.writerFailed }

        try? FileManager.default.removeItem(at: url)
        try FileManager.default.moveItem(at: partial, to: url)
        pruneCache()
    }
}

// MARK: - On-demand cache (renders a clip the first time the system asks for it)

actor VideoCache {
    static let shared = VideoCache()
    private var inFlight: [String: Task<URL?, Never>] = [:]

    func video(id: String, source: UIImage, size: CGSize) async -> URL? {
        let url = ArtworkRenderer.cacheURL(for: id)
        if FileManager.default.fileExists(atPath: url.path) { return url }
        if let running = inFlight[id] { return await running.value }

        let task = Task.detached(priority: .userInitiated) { () -> URL? in
            do {
                try await ArtworkRenderer.renderLoop(source: source, size: size, to: url)
                return url
            } catch {
                try? FileManager.default.removeItem(at: url)
                return nil
            }
        }
        inFlight[id] = task
        let result = await task.value
        inFlight[id] = nil
        return result
    }
}

// MARK: - Lock-screen animated artwork (iOS 26+)

enum StaticArtwork {
    /// Regular (still) artwork for Now Playing; also the fallback if animation is unavailable.
    static func make(from image: UIImage) -> MPMediaItemArtwork {
        MPMediaItemArtwork(boundsSize: image.size) { _ in image }
    }
}
