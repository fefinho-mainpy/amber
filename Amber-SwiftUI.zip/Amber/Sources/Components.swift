import AVFoundation
import SwiftUI
import UIKit

// MARK: - Cover

/// Square-ish cover that fills whatever frame it is given.
struct CoverView: View {
    let url: URL?
    let letter: String
    var maxSide: CGFloat = 700

    @EnvironmentObject private var theme: Theme
    @State private var image: UIImage?

    var body: some View {
        Color.clear
            .overlay {
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                } else {
                    ZStack {
                        theme.sf
                        Text(String(letter.prefix(1)).uppercased())
                            .font(theme.serif(30))
                            .foregroundStyle(theme.mu)
                    }
                }
            }
            .clipped()
            .task(id: url) {
                guard let url else { image = nil; return }
                image = await ImageLoader.load(url, maxSide: maxSide)
            }
    }
}

// MARK: - Looping muted video (animated covers)

final class LoopingPlayerView: UIView {
    private let queuePlayer = AVQueuePlayer()
    private var looper: AVPlayerLooper?
    private var currentURL: URL?

    override class var layerClass: AnyClass { AVPlayerLayer.self }
    private var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }

    override init(frame: CGRect) {
        super.init(frame: frame)
        playerLayer.player = queuePlayer
        playerLayer.videoGravity = .resizeAspectFill
        queuePlayer.isMuted = true
        queuePlayer.allowsExternalPlayback = false
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    func setURL(_ url: URL, playing: Bool) {
        if url != currentURL {
            currentURL = url
            looper = nil
            queuePlayer.removeAllItems()
            looper = AVPlayerLooper(player: queuePlayer, templateItem: AVPlayerItem(url: url))
        }
        if playing { queuePlayer.play() } else { queuePlayer.pause() }
    }
}

struct LoopingVideoView: UIViewRepresentable {
    let url: URL
    var playing = true

    func makeUIView(context: Context) -> LoopingPlayerView { LoopingPlayerView() }

    func updateUIView(_ uiView: LoopingPlayerView, context: Context) {
        uiView.setURL(url, playing: playing)
    }
}

// MARK: - Flowing background (the web app's WebGPU shader, as an animated mesh gradient)

struct FlowBackground: View {
    let colors: [Color]     // 9 colours, row by row

    var body: some View {
        if #available(iOS 18.0, *) {
            FlowMesh(colors: colors)
        } else {
            LinearGradient(
                colors: [colors[0], colors[4], colors[8]],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
        }
    }
}

@available(iOS 18.0, *)
private struct FlowMesh: View {
    let colors: [Color]

    private func points(_ t: Double) -> [SIMD2<Float>] {
        func wobble(_ speed: Double, _ phase: Double) -> Float {
            let value: Double = 0.5 + 0.18 * sin(t * speed + phase)
            return Float(value)
        }
        return [
            SIMD2<Float>(0, 0), SIMD2<Float>(0.5, 0), SIMD2<Float>(1, 0),
            SIMD2<Float>(0, wobble(1.1, 0)), SIMD2<Float>(wobble(0.9, 1), wobble(1.3, 2)), SIMD2<Float>(1, wobble(0.7, 3)),
            SIMD2<Float>(0, 1), SIMD2<Float>(0.5, 1), SIMD2<Float>(1, 1),
        ]
    }

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { context in
            let t = context.date.timeIntervalSinceReferenceDate * 0.3
            MeshGradient(width: 3, height: 3, points: points(t), colors: colors)
        }
    }
}

// MARK: - Buttons & chrome

struct PillButton: View {
    let title: String
    var systemImage: String?
    var filled = false
    let action: () -> Void

    @EnvironmentObject private var theme: Theme

    var body: some View {
        Button(action: action) {
            HStack(spacing: 7) {
                if let systemImage { Image(systemName: systemImage).font(.system(size: 13, weight: .semibold)) }
                Text(title).font(.system(size: 15, weight: .semibold))
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 11)
            .foregroundStyle(filled ? theme.onAccent : theme.fg)
            .background(filled ? theme.ac : theme.sf, in: Capsule())
            .overlay(Capsule().stroke(filled ? Color.clear : theme.ln, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

struct SectionTitle: View {
    let text: String
    @EnvironmentObject private var theme: Theme

    var body: some View {
        Text(text)
            .font(theme.serif(24))
            .foregroundStyle(theme.fg)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct Toast: View {
    let text: String
    @EnvironmentObject private var theme: Theme

    var body: some View {
        Text(text)
            .font(.system(size: 14, weight: .medium))
            .foregroundStyle(theme.fg)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(theme.sf, in: Capsule())
            .overlay(Capsule().stroke(theme.ln, lineWidth: 1))
            .shadow(color: .black.opacity(0.25), radius: 12, y: 4)
    }
}
