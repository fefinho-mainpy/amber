import AVFoundation
import MediaPlayer
import UIKit

extension ArtworkRenderer {
    /// First frame of a video, used as the still preview that iOS shows while the video loads.
    static func firstFrame(of url: URL) async -> UIImage? {
        let asset = AVURLAsset(url: url)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 1080, height: 1440)
        do {
            let result = try await generator.image(at: .zero)
            return UIImage(cgImage: result.image)
        } catch {
            return nil
        }
    }
}

/// Everything the lock screen could show for the current album.
struct LockScreenSource {
    var squareVideo: URL?       // album's animated cover (1:1)
    var tallVideo: URL?         // album's tall animated cover (3:4)
    var cover: UIImage          // full-size cover
    var tallStill: UIImage?     // tall still, if the album has one
}

@available(iOS 26.0, *)
enum AnimatedArtworkProvider {
    /// Builds the `nowPlayingInfo` entries for the shapes the device supports.
    /// Real animated covers are used when the album has them; otherwise a seamless loop is
    /// generated from the cover so the lock screen always animates.
    static func nowPlayingEntries(trackKey: String, source: LockScreenSource) -> [String: Any] {
        let supported = MPNowPlayingInfoCenter.supportedAnimatedArtworkKeys
        let hasAnyVideo = source.squareVideo != nil || source.tallVideo != nil

        struct Variant {
            let key: String
            let name: String
            let size: CGSize
            let video: URL?
            let still: UIImage
        }
        var variants: [Variant] = []
        if source.squareVideo != nil || !hasAnyVideo {
            variants.append(Variant(
                key: MPNowPlayingInfoProperty1x1AnimatedArtwork, name: "1x1",
                size: ArtworkRenderer.size1x1, video: source.squareVideo, still: source.cover
            ))
        }
        if source.tallVideo != nil || !hasAnyVideo {
            variants.append(Variant(
                key: MPNowPlayingInfoProperty3x4AnimatedArtwork, name: "3x4",
                size: ArtworkRenderer.size3x4, video: source.tallVideo, still: source.tallStill ?? source.cover
            ))
        }

        var entries: [String: Any] = [:]
        for v in variants where supported.contains(v.key) {
            let size = v.size
            let still = v.still

            if let video = v.video {
                // A real animated cover that already lives on disk.
                let id = ArtworkRenderer.artworkID(trackID: trackKey, variant: v.name + "-file-" + video.lastPathComponent)
                entries[v.key] = MPMediaItemAnimatedArtwork(
                    artworkID: id,
                    previewImageRequestHandler: { _ in
                        await ArtworkRenderer.firstFrame(of: video)
                    },
                    videoAssetFileURLRequestHandler: { _ in
                        video
                    }
                )
            } else {
                // Generated loop: preview = frame 0 of the clip, video rendered on first request.
                let id = ArtworkRenderer.artworkID(trackID: trackKey, variant: v.name + "-gen")
                let preview = ArtworkRenderer.previewImage(source: still, size: size)
                entries[v.key] = MPMediaItemAnimatedArtwork(
                    artworkID: id,
                    previewImageRequestHandler: { _ in
                        preview
                    },
                    videoAssetFileURLRequestHandler: { _ in
                        await VideoCache.shared.video(id: id, source: still, size: size)
                    }
                )
            }
        }
        return entries
    }

    static var statusText: String {
        let keys = MPNowPlayingInfoCenter.supportedAnimatedArtworkKeys
        var shapes: [String] = []
        if keys.contains(MPNowPlayingInfoProperty1x1AnimatedArtwork) { shapes.append("1:1") }
        if keys.contains(MPNowPlayingInfoProperty3x4AnimatedArtwork) { shapes.append("3:4") }
        if shapes.isEmpty { return "This device doesn’t report animated artwork support." }
        return "Lock screen shapes: " + shapes.joined(separator: ", ")
    }
}
