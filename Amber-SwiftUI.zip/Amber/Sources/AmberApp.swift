import SwiftUI

@main
struct AmberApp: App {
    @StateObject private var library: Library
    @StateObject private var player: Player
    @StateObject private var theme: Theme

    init() {
        let theme = Theme()
        let library = Library()
        library.onlineEnabled = { theme.s.onlineArtwork }
        _theme = StateObject(wrappedValue: theme)
        _library = StateObject(wrappedValue: library)
        _player = StateObject(wrappedValue: Player(library: library))
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(library)
                .environmentObject(player)
                .environmentObject(theme)
        }
    }
}
