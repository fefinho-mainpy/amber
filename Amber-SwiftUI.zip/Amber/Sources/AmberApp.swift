import SwiftUI

@main
struct AmberApp: App {
    @StateObject private var library: Library
    @StateObject private var player: Player
    @StateObject private var theme: Theme
    @StateObject private var services: Services

    init() {
        let theme = Theme()
        let library = Library()
        let services = Services()
        library.onlineEnabled = { theme.s.onlineArtwork }
        let player = Player(library: library)
        player.services = services
        _theme = StateObject(wrappedValue: theme)
        _library = StateObject(wrappedValue: library)
        _player = StateObject(wrappedValue: player)
        _services = StateObject(wrappedValue: services)
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(library)
                .environmentObject(player)
                .environmentObject(theme)
                .environmentObject(services)
        }
    }
}
