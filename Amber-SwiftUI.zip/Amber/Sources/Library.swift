import AVFoundation
import Combine
import Foundation
import UIKit

// MARK: - Model

struct Track: Identifiable, Codable, Equatable {
    var id: Int
    var path: String            // relative path inside the library folder
    var title: String
    var artist: String
    var album: String
    var albumArtist: String
    var genre: String
    var year: String
    var no: Int
    var disc: Int
    var lyricsText: String?     // embedded / edited lyrics (plain, LRC or TTML)
    var lyricsFile: String?     // relative path of a sidecar .lrc / .ttml

    var dir: String { (path as NSString).deletingLastPathComponent }
    /// Album identity: same album name in the same folder.
    var key: String { album.isEmpty ? "t|\(id)" : "a|\(album)|\(dir)" }
    var tasteKey: String { String(stableHash([artist, album, title].joined(separator: "|").lowercased()), radix: 36) }
    var displayAlbum: String { album.isEmpty ? title : album }
    var artistName: String { albumArtist.isEmpty ? artist : albumArtist }
}

enum AssetKind: String, CaseIterable {
    case cover, tall, anim, tallanim
}

struct Stat: Codable {
    var plays = 0
    var skips = 0
    var last: Double = 0        // ms since 1970
}

struct AlbumGroup: Identifiable {
    let id: String
    let tracks: [Track]
    var first: Track { tracks[0] }
    var title: String { first.displayAlbum }
}

struct ArtistGroup: Identifiable {
    let id: String
    let name: String
    let tracks: [Track]
}

struct TrackEdit {
    var title = ""
    var artist = ""
    var albumArtist = ""
    var album = ""
    var genre = ""
    var year = ""
    var no = 0
    var disc = 0
    var lyrics = ""
    var applyToAlbum = false
}

private struct SavedLibrary: Codable {
    var tracks: [Track]
    var stats: [String: Stat]
    var nextID: Int
    var onlineDone: [String]
    var liked: [String]?
}

// MARK: - Library

final class Library: ObservableObject {
    @Published private(set) var tracks: [Track] = []
    @Published private(set) var albums: [AlbumGroup] = []
    @Published private(set) var artists: [ArtistGroup] = []
    @Published private(set) var forYou: [Track] = []
    @Published private(set) var assetVersion = 0
    @Published private(set) var liked: Set<String> = []
    @Published var status: String?

    var onlineEnabled: () -> Bool = { true }
    var onAssetsChanged: (String) -> Void = { _ in }

    private var stats: [String: Stat] = [:]
    private var nextID = 1
    private var onlineDone = Set<String>()
    private var onlineTried = Set<String>()
    private var currentID: Int?
    private var assetIndex: [String: URL] = [:]
    private let lock = NSLock()
    private var saveWork: DispatchWorkItem?

    let libraryDir: URL
    let artDir: URL
    private let stateURL: URL

    private static let audioExt: Set<String> = ["mp3", "m4a", "aac", "flac", "wav", "aif", "aiff", "caf"]
    private static let imageExt: Set<String> = ["jpg", "jpeg", "png", "webp", "gif", "heic"]
    private static let videoExt: Set<String> = ["mp4", "mov", "m4v"]
    private static let lyricExt: Set<String> = ["ttml", "lrc", "xml"]

    init() {
        let fm = FileManager.default
        let base = (try? fm.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true))
            ?? fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let root = base.appendingPathComponent("Amber", isDirectory: true)
        libraryDir = root.appendingPathComponent("Library", isDirectory: true)
        artDir = root.appendingPathComponent("Art", isDirectory: true)
        stateURL = root.appendingPathComponent("library.json")
        try? fm.createDirectory(at: libraryDir, withIntermediateDirectories: true)
        try? fm.createDirectory(at: artDir, withIntermediateDirectories: true)
        indexAssets()

        if let data = try? Data(contentsOf: stateURL),
           let saved = try? JSONDecoder().decode(SavedLibrary.self, from: data) {
            stats = saved.stats
            nextID = saved.nextID
            onlineDone = Set(saved.onlineDone)
            liked = Set(saved.liked ?? [])
            let root = libraryDir
            tracks = saved.tracks.filter { fm.fileExists(atPath: root.appendingPathComponent($0.path).path) }
        }
        rebuild()
    }

    // MARK: Lookups

    func fileURL(for t: Track) -> URL { libraryDir.appendingPathComponent(t.path) }
    func tracks(forAlbum key: String) -> [Track] { tracks.filter { $0.key == key } }
    func tracks(forArtist name: String) -> [Track] {
        tracks.filter { $0.artistName.lowercased() == name.lowercased() }
    }
    func albumGroups(of list: [Track]) -> [AlbumGroup] { makeAlbums(list) }
    /// Most-played songs first (falls back to album order for unplayed ones).
    func topTracks(in list: [Track], limit: Int = 5) -> [Track] {
        let ranked = list.sorted { (stats[$0.tasteKey]?.plays ?? 0) > (stats[$1.tasteKey]?.plays ?? 0) }
        return Array(ranked.prefix(limit))
    }
    func track(id: Int) -> Track? { tracks.first { $0.id == id } }
    func mostRecentlyPlayed() -> Track? {
        var best: Track?
        var bestTime = 0.0
        for t in tracks {
            let last = stats[t.tasteKey]?.last ?? 0
            if last > bestTime { bestTime = last; best = t }
        }
        return best
    }

    func lyrics(for t: Track) -> Lyrics? {
        var raw = ""
        if let lf = t.lyricsFile,
           let s = try? String(contentsOf: libraryDir.appendingPathComponent(lf), encoding: .utf8) {
            raw = s
        } else if let l = t.lyricsText {
            raw = l
        }
        return LyricsParser.parse(raw)
    }

    func rawLyrics(of t: Track) -> String {
        if let lf = t.lyricsFile,
           let s = try? String(contentsOf: libraryDir.appendingPathComponent(lf), encoding: .utf8) { return s }
        return t.lyricsText ?? ""
    }

    // MARK: Grouping / sorting

    private func sortedTracks(_ list: [Track]) -> [Track] {
        list.sorted { a, b in
            let aa = a.album.isEmpty ? "\u{FFFF}" : a.album
            let ba = b.album.isEmpty ? "\u{FFFF}" : b.album
            var r = aa.localizedStandardCompare(ba)
            if r == .orderedSame { r = a.dir.localizedStandardCompare(b.dir) }
            if r != .orderedSame { return r == .orderedAscending }
            if a.disc != b.disc { return a.disc < b.disc }
            if a.no != b.no { return a.no < b.no }
            return a.title.localizedStandardCompare(b.title) == .orderedAscending
        }
    }

    private func makeAlbums(_ list: [Track]) -> [AlbumGroup] {
        var order: [String] = []
        var map: [String: [Track]] = [:]
        for t in list {
            if map[t.key] == nil { order.append(t.key); map[t.key] = [] }
            map[t.key]?.append(t)
        }
        let groups = order.compactMap { k in map[k].map { AlbumGroup(id: k, tracks: $0) } }
        return groups.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
    }

    private func makeArtists(_ list: [Track]) -> [ArtistGroup] {
        var order: [String] = []
        var names: [String: String] = [:]
        var map: [String: [Track]] = [:]
        for t in list {
            let name = t.artistName
            if name.isEmpty { continue }
            let k = name.lowercased()
            if map[k] == nil { order.append(k); map[k] = []; names[k] = name }
            map[k]?.append(t)
        }
        let groups = order.compactMap { k in map[k].map { ArtistGroup(id: k, name: names[k] ?? k, tracks: $0) } }
        return groups.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    private func rebuild() {
        tracks = sortedTracks(tracks)
        albums = makeAlbums(tracks)
        artists = makeArtists(tracks)
        refreshForYou()
    }

    // MARK: Taste ("For you" and smart shuffle)

    func setCurrent(_ id: Int?) {
        currentID = id
        refreshForYou()
    }

    func isLiked(_ t: Track) -> Bool { liked.contains(t.tasteKey) }

    func setLiked(_ list: [Track], _ on: Bool) {
        for t in list {
            if on { liked.insert(t.tasteKey) } else { liked.remove(t.tasteKey) }
        }
        scheduleSave()
    }

    func toggleLike(_ t: Track) {
        let k: String = t.tasteKey
        if liked.contains(k) { liked.remove(k) } else { liked.insert(k) }
        scheduleSave()
    }

    func bump(_ t: Track, play: Bool) {
        var x = stats[t.tasteKey] ?? Stat()
        if play { x.plays += 1 } else { x.skips += 1 }
        x.last = Date().timeIntervalSince1970 * 1000
        stats[t.tasteKey] = x
        scheduleSave()
        refreshForYou()
    }

    private func scorer() -> (Track) -> Double {
        let snapshot = stats
        var affinity: [String: Int] = [:]
        for t in tracks where !t.artist.isEmpty {
            affinity[t.artist.lowercased(), default: 0] += snapshot[t.tasteKey]?.plays ?? 0
        }
        let now = Date().timeIntervalSince1970 * 1000
        return { t in
            let x = snapshot[t.tasteKey] ?? Stat()
            let days = x.last > 0 ? (now - x.last) / 86_400_000 : 30
            let aff = Double(affinity[t.artist.lowercased()] ?? 0)
            var score = log1p(Double(x.plays)) * 1.2
            score -= Double(x.skips) * 0.9
            score += log1p(aff) * 0.7
            score += min(days, 14) / 14 * 0.8
            score += x.plays > 0 ? 0 : 0.5
            score += Double.random(in: 0..<0.4)
            return score
        }
    }

    func pick(from queue: [Track], avoiding recent: [Int], current: Track?) -> Track? {
        guard !queue.isEmpty else { return nil }
        let f = scorer()
        let weights: [Double] = queue.map { t in
            (recent.contains(t.id) || t.id == current?.id) ? 0 : exp(f(t) * 0.7)
        }
        let total = weights.reduce(0, +)
        guard total > 0 else { return queue.randomElement() }
        var r = Double.random(in: 0..<total)
        for (i, w) in weights.enumerated() {
            r -= w
            if r <= 0 { return queue[i] }
        }
        return queue[0]
    }

    private func refreshForYou() {
        guard !stats.isEmpty else { forYou = []; return }
        let f = scorer()
        let ranked = tracks
            .filter { $0.id != currentID }
            .map { ($0, f($0)) }
            .sorted { $0.1 > $1.1 }
        forYou = ranked.prefix(5).map { $0.0 }
    }

    // MARK: Persistence

    private func scheduleSave() {
        saveWork?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.saveNow() }
        saveWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: work)
    }

    func saveNow() {
        let saved = SavedLibrary(tracks: tracks, stats: stats, nextID: nextID, onlineDone: Array(onlineDone), liked: Array(liked))
        if let data = try? JSONEncoder().encode(saved) {
            try? data.write(to: stateURL, options: .atomic)
        }
    }

    // MARK: Assets (covers, tall art, animated covers)

    private func indexKey(_ key: String, _ kind: AssetKind) -> String {
        String(stableHash(key), radix: 16) + "." + kind.rawValue
    }

    private func indexAssets() {
        let files = (try? FileManager.default.contentsOfDirectory(at: artDir, includingPropertiesForKeys: nil)) ?? []
        var index: [String: URL] = [:]
        for f in files {
            let parts = f.lastPathComponent.split(separator: ".")
            if parts.count >= 4 { index[String(parts[0]) + "." + String(parts[1])] = f }
        }
        lock.lock()
        assetIndex = index
        lock.unlock()
    }

    func assetURL(_ key: String, _ kind: AssetKind) -> URL? {
        lock.lock()
        defer { lock.unlock() }
        return assetIndex[indexKey(key, kind)]
    }

    /// Best still image for a hero area: the tall image if there is one, otherwise the cover.
    func heroImageURL(_ key: String) -> URL? { assetURL(key, .tall) ?? assetURL(key, .cover) }

    private func newAssetURL(_ key: String, _ kind: AssetKind, ext: String) -> URL {
        let token = String(UInt32.random(in: 0...UInt32.max), radix: 36)
        let name: String = "\(indexKey(key, kind)).\(token).\(ext)"
        return artDir.appendingPathComponent(name)
    }

    private func commit(_ key: String, _ kind: AssetKind, _ dest: URL) {
        lock.lock()
        let old = assetIndex[indexKey(key, kind)]
        assetIndex[indexKey(key, kind)] = dest
        lock.unlock()
        if let old { try? FileManager.default.removeItem(at: old) }
    }

    @discardableResult
    func setAsset(_ key: String, _ kind: AssetKind, copying source: URL) -> Bool {
        let ext = source.pathExtension.lowercased()
        let dest = newAssetURL(key, kind, ext: ext.isEmpty ? "dat" : ext)
        do { try FileManager.default.copyItem(at: source, to: dest) } catch { return false }
        commit(key, kind, dest)
        return true
    }

    @discardableResult
    func setAsset(_ key: String, _ kind: AssetKind, image: UIImage) -> Bool {
        guard let data = ArtworkFactory.downscaled(image, maxSide: 2000).jpegData(compressionQuality: 0.9) else { return false }
        let dest = newAssetURL(key, kind, ext: "jpg")
        do { try data.write(to: dest) } catch { return false }
        commit(key, kind, dest)
        return true
    }

    @discardableResult
    func setAsset(_ key: String, _ kind: AssetKind, data: Data) -> Bool {
        guard let image = UIImage(data: data) else { return false }
        return setAsset(key, kind, image: image)
    }

    func removeAssets(_ key: String, kinds: [AssetKind] = AssetKind.allCases) {
        for kind in kinds {
            lock.lock()
            let old = assetIndex.removeValue(forKey: indexKey(key, kind))
            lock.unlock()
            if let old { try? FileManager.default.removeItem(at: old) }
        }
    }

    func assetsChanged(_ key: String) {
        assetVersion += 1
        onAssetsChanged(key)
    }

    /// User picked a cover image or animation for an album.
    func importArtwork(from url: URL, forKey key: String) async {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let ext = url.pathExtension.lowercased()
        if Self.videoExt.contains(ext) {
            // decide square vs tall from the video's shape
            let asset = AVURLAsset(url: url)
            var tall = false
            if let track = try? await asset.loadTracks(withMediaType: .video).first,
               let size = try? await track.load(.naturalSize) {
                tall = size.height > size.width * 1.15
            }
            let kind: AssetKind = tall ? .tallanim : .anim
            guard setAsset(key, kind, copying: url), let local = assetURL(key, kind) else { return }
            if let frame = await ArtworkRenderer.firstFrame(of: local) {
                setAsset(key, tall ? .tall : .cover, image: frame)
            }
        } else if let image = UIImage(contentsOfFile: url.path) {
            let tall = image.size.height > image.size.width * 1.15
            if tall { setAsset(key, .tall, image: image) } else { setAsset(key, .cover, image: image); removeAssets(key, kinds: [.anim]) }
        }
        await MainActor.run { self.assetsChanged(key); self.scheduleSave() }
    }

    func removeArtwork(forKey key: String) {
        removeAssets(key)
        onlineTried.insert(key)   // don't immediately fetch it again this session
        assetsChanged(key)
        scheduleSave()
    }

    // MARK: Online animated artwork

    func fetchOnline(for t: Track) {
        guard onlineEnabled(), !t.artist.isEmpty, !t.album.isEmpty else { return }
        let key = t.key
        guard !onlineDone.contains(key), !onlineTried.contains(key) else { return }
        onlineTried.insert(key)
        let needSquare = assetURL(key, .anim) == nil
        let needTall = assetURL(key, .tallanim) == nil
        let needImage = assetURL(key, .cover) == nil
        guard needSquare || needTall || needImage else { return }
        let artist = t.artist, album = t.album, title = t.title

        Task.detached(priority: .utility) { [weak self] in
            let r = await OnlineArtwork.fetch(
                artist: artist, album: album, title: title,
                needSquare: needSquare, needTall: needTall, needImage: needImage
            )
            guard let self else { return }
            var changed = false
            if let f = r.squareFile, self.setAsset(key, .anim, copying: f) { changed = true }
            if let f = r.tallFile, self.setAsset(key, .tallanim, copying: f) { changed = true }
            if let f = r.imageFile, self.setAsset(key, .cover, copying: f) { changed = true }
            for f in [r.squareFile, r.tallFile, r.imageFile].compactMap({ $0 }) {
                try? FileManager.default.removeItem(at: f)
            }
            if changed {
                await MainActor.run {
                    self.onlineDone.insert(key)
                    self.assetsChanged(key)
                    self.scheduleSave()
                }
            }
        }
    }

    // MARK: Importing

    func importItems(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        Task.detached(priority: .userInitiated) { [weak self] in await self?.runImport(urls) }
    }

    private struct SourceItem {
        let src: URL
        let rel: String
    }

    private static func listFiles(in dir: URL, prefix: String) -> [(URL, String)] {
        var out: [(URL, String)] = []
        let fm = FileManager.default
        guard let entries = try? fm.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]
        ) else { return out }
        for u in entries {
            let isDir = (try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            if isDir == true {
                out += listFiles(in: u, prefix: prefix + u.lastPathComponent + "/")
            } else {
                out.append((u, prefix + u.lastPathComponent))
            }
        }
        return out
    }

    private func post(_ text: String?, clearAfter: Double? = nil) async {
        await MainActor.run {
            self.status = text
            if let delay = clearAfter {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                    if self?.status == text { self?.status = nil }
                }
            }
        }
    }

    private func appendNew(_ list: [Track]) -> [Track] {
        var out = list
        for i in out.indices {
            out[i].id = nextID
            nextID += 1
        }
        tracks.append(contentsOf: out)
        rebuild()
        scheduleSave()
        return out
    }

    private func runImport(_ urls: [URL]) async {
        await post("Reading files…")
        var scoped: [URL] = []
        for u in urls where u.startAccessingSecurityScopedResource() { scoped.append(u) }
        defer { for u in scoped { u.stopAccessingSecurityScopedResource() } }

        let fm = FileManager.default
        var items: [SourceItem] = []
        for u in urls {
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: u.path, isDirectory: &isDir), isDir.boolValue {
                for (file, rel) in Self.listFiles(in: u, prefix: u.lastPathComponent + "/") {
                    items.append(SourceItem(src: file, rel: rel))
                }
            } else {
                items.append(SourceItem(src: u, rel: u.lastPathComponent))
            }
        }

        func parent(_ rel: String) -> String { (rel as NSString).deletingLastPathComponent }
        func base(_ item: SourceItem) -> String { item.src.deletingPathExtension().lastPathComponent.lowercased() }
        func matches(_ s: String, _ pattern: String) -> Bool { s.range(of: pattern, options: .regularExpression) != nil }

        // Classify sidecar files (covers, tall art, animations, lyrics) by folder.
        var coverImg: [String: SourceItem] = [:]
        var tallImg: [String: SourceItem] = [:]
        var squareVid: [String: SourceItem] = [:]
        var tallVid: [String: SourceItem] = [:]
        var lyricByDir: [String: String] = [:]
        var lyricByName: [String: String] = [:]

        for item in items {
            let ext = item.src.pathExtension.lowercased()
            let dir = parent(item.rel)
            let name = base(item)
            let isTall = matches(name, "tall|vertical|portrait")
            if Self.imageExt.contains(ext) {
                if isTall { if tallImg[dir] == nil { tallImg[dir] = item } }
                else if coverImg[dir] == nil || matches(name, "cover|folder|front|album") { coverImg[dir] = item }
            } else if Self.videoExt.contains(ext), matches(name, "cover|folder|front|album|artwork|animated|tall|vertical|portrait") {
                if isTall { if tallVid[dir] == nil { tallVid[dir] = item } }
                else if squareVid[dir] == nil { squareVid[dir] = item }
            } else if Self.lyricExt.contains(ext) {
                let dest = libraryDir.appendingPathComponent(item.rel)
                try? fm.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
                if !fm.fileExists(atPath: dest.path) { try? fm.copyItem(at: item.src, to: dest) }
                lyricByDir[dir + "/" + name] = item.rel
                lyricByName[name] = item.rel
            }
        }

        // Audio files: copy into the library and read their tags.
        let existing = await MainActor.run { Set(self.tracks.map { $0.path }) }
        let audio = items.filter { Self.audioExt.contains($0.src.pathExtension.lowercased()) }
        var fresh: [Track] = []
        var arts: [Int: Data] = [:]
        var done = 0
        for item in audio {
            done += 1
            if done % 6 == 0 { await post("Reading \(done) / \(audio.count)…") }
            if existing.contains(item.rel) { continue }
            let dest = libraryDir.appendingPathComponent(item.rel)
            try? fm.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
            if !fm.fileExists(atPath: dest.path) {
                do { try fm.copyItem(at: item.src, to: dest) } catch { continue }
            }
            let tags = TagReader.read(dest)
            let fallback = dest.deletingPathExtension().lastPathComponent.replacingOccurrences(of: "_", with: " ")
            let name = base(item)
            let dir = parent(item.rel)
            let track = Track(
                id: 0, path: item.rel,
                title: tags.title.isEmpty ? fallback : tags.title,
                artist: tags.artist, album: tags.album, albumArtist: tags.albumArtist,
                genre: tags.genre, year: tags.year, no: tags.track, disc: tags.disc,
                lyricsText: tags.lyrics,
                lyricsFile: lyricByDir[dir + "/" + name] ?? lyricByName[name]
            )
            if let art = tags.art { arts[fresh.count] = art }
            fresh.append(track)
        }

        guard !fresh.isEmpty else {
            await post("No new audio files found", clearAfter: 2.4)
            return
        }

        let batch = fresh
        let appended = await MainActor.run { self.appendNew(batch) }

        // Covers & animations: embedded art first, then folder images / videos.
        for (i, t) in appended.enumerated() {
            let key = t.key
            let dir = t.dir
            if assetURL(key, .cover) == nil, let art = arts[i] { setAsset(key, .cover, data: art) }

            if assetURL(key, .tall) == nil, assetURL(key, .tallanim) == nil {
                let ti = tallImg[dir]
                if let ti { setAsset(key, .tall, copying: ti.src) }
                if let tv = tallVid[dir], setAsset(key, .tallanim, copying: tv.src) {
                    if ti == nil, let local = assetURL(key, .tallanim),
                       let frame = await ArtworkRenderer.firstFrame(of: local) {
                        setAsset(key, .tall, image: frame)
                    }
                }
            }
            if assetURL(key, .cover) == nil, let d = coverImg[dir] { setAsset(key, .cover, copying: d.src) }
            if assetURL(key, .anim) == nil, let v = squareVid[dir], setAsset(key, .anim, copying: v.src) {
                if assetURL(key, .cover) == nil, let local = assetURL(key, .anim),
                   let frame = await ArtworkRenderer.firstFrame(of: local) {
                    setAsset(key, .cover, image: frame)
                }
            }
        }

        await MainActor.run { self.assetsChanged("") }
        await post("Added \(appended.count) song\(appended.count == 1 ? "" : "s")", clearAfter: 2.2)
    }

    // MARK: Editing / removing

    func apply(_ e: TrackEdit, to id: Int) {
        guard let idx = tracks.firstIndex(where: { $0.id == id }) else { return }
        let t = tracks[idx]
        let oldKey = t.key
        let targets: [Int] = e.applyToAlbum ? tracks.indices.filter { tracks[$0].key == oldKey } : [idx]
        var oldTaste: [Int: String] = [:]
        for i in targets { oldTaste[tracks[i].id] = tracks[i].tasteKey }
        let oldLyrics = rawLyrics(of: t).trimmingCharacters(in: .whitespacesAndNewlines)

        for i in targets {
            tracks[i].album = e.album
            tracks[i].albumArtist = e.albumArtist
            tracks[i].genre = e.genre
            tracks[i].year = String(e.year.prefix(4))
        }
        tracks[idx].title = e.title.isEmpty ? t.title : e.title
        tracks[idx].artist = e.artist
        tracks[idx].no = e.no
        tracks[idx].disc = e.disc
        if e.lyrics.trimmingCharacters(in: .whitespacesAndNewlines) != oldLyrics {
            tracks[idx].lyricsText = e.lyrics
            tracks[idx].lyricsFile = nil
        }
        for i in targets {
            let old = oldTaste[tracks[i].id] ?? ""
            let new = tracks[i].tasteKey
            if old != new, let s = stats[old] { stats[new] = s; stats[old] = nil }
            if old != new, liked.contains(old) { liked.remove(old); liked.insert(new) }
        }
        let newKey = tracks[idx].key
        if newKey != oldKey {
            for kind in AssetKind.allCases {
                if let src = assetURL(oldKey, kind), assetURL(newKey, kind) == nil {
                    setAsset(newKey, kind, copying: src)
                }
            }
            if e.applyToAlbum { removeAssets(oldKey) }
            onlineDone.remove(oldKey)
        }
        rebuild()
        assetVersion += 1
        scheduleSave()
    }

    func removeAlbum(key: String) {
        let fm = FileManager.default
        for t in tracks where t.key == key {
            try? fm.removeItem(at: fileURL(for: t))
        }
        tracks.removeAll { $0.key == key }
        removeAssets(key)
        onlineDone.remove(key)
        rebuild()
        assetVersion += 1
        scheduleSave()
    }

    func clearAll() {
        let fm = FileManager.default
        try? fm.removeItem(at: libraryDir)
        try? fm.removeItem(at: artDir)
        try? fm.createDirectory(at: libraryDir, withIntermediateDirectories: true)
        try? fm.createDirectory(at: artDir, withIntermediateDirectories: true)
        lock.lock()
        assetIndex = [:]
        lock.unlock()
        tracks = []
        stats = [:]
        liked = []
        onlineDone = []
        onlineTried = []
        rebuild()
        assetVersion += 1
        saveNow()
    }

    func storageBytes() -> Int64 {
        var total: Int64 = 0
        let fm = FileManager.default
        for dir in [libraryDir, artDir] {
            guard let e = fm.enumerator(at: dir, includingPropertiesForKeys: [.fileSizeKey]) else { continue }
            while let next = e.nextObject() as? URL {
                total += Int64((try? next.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
            }
        }
        return total
    }
}
