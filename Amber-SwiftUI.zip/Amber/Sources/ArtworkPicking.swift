import PhotosUI
import SwiftUI
import UIKit
import UniformTypeIdentifiers

/// Video picked from the photo library, copied to a temp file we own.
struct PickedMovie: Transferable {
    let url: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { movie in
            SentTransferredFile(movie.url)
        } importing: { received in
            let ext: String = received.file.pathExtension.isEmpty ? "mov" : received.file.pathExtension
            let dest = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString + "." + ext)
            try FileManager.default.copyItem(at: received.file, to: dest)
            return PickedMovie(url: dest)
        }
    }
}

struct ArtworkImportState: Equatable {
    var photos = false
    var files = false
    var asLogo = false
}

/// Photos picker + file picker for one asset key (an album, or an artist via `ArtistKey.make`).
struct ArtworkImporters: ViewModifier {
    let key: String
    @Binding var state: ArtworkImportState

    @EnvironmentObject private var library: Library
    @State private var photoItem: PhotosPickerItem?

    func body(content: Content) -> some View {
        content
            .photosPicker(
                isPresented: $state.photos,
                selection: $photoItem,
                matching: state.asLogo ? PHPickerFilter.images : PHPickerFilter.any(of: [.images, .videos])
            )
            .fileImporter(
                isPresented: $state.files,
                allowedContentTypes: state.asLogo ? [UTType.image] : [UTType.image, UTType.movie],
                allowsMultipleSelection: false
            ) { result in
                guard case .success(let urls) = result, let url = urls.first else { return }
                let logo: Bool = state.asLogo
                Task { await library.importArtwork(from: url, forKey: key, asLogo: logo) }
            }
            .onChange(of: photoItem) { _, item in
                guard let item else { return }
                let logo: Bool = state.asLogo
                Task {
                    await load(item, asLogo: logo)
                    photoItem = nil
                }
            }
    }

    private func load(_ item: PhotosPickerItem, asLogo: Bool) async {
        let isMovie: Bool = item.supportedContentTypes.contains { $0.conforms(to: .movie) }
        if isMovie, !asLogo {
            if let movie = try? await item.loadTransferable(type: PickedMovie.self) {
                await library.importArtwork(from: movie.url, forKey: key)
                try? FileManager.default.removeItem(at: movie.url)
            }
            return
        }
        guard let data = try? await item.loadTransferable(type: Data.self),
              let image = UIImage(data: data) else { return }
        let bytes: Data? = asLogo ? image.pngData() : image.jpegData(compressionQuality: 0.95)
        guard let bytes else { return }
        let ext: String = asLogo ? "png" : "jpg"
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "." + ext)
        guard (try? bytes.write(to: tmp)) != nil else { return }
        await library.importArtwork(from: tmp, forKey: key, asLogo: asLogo)
        try? FileManager.default.removeItem(at: tmp)
    }
}

extension View {
    func artworkImporters(key: String, state: Binding<ArtworkImportState>) -> some View {
        modifier(ArtworkImporters(key: key, state: state))
    }
}

/// Menu entries that open the pickers above.
struct ArtworkMenuItems: View {
    @Binding var state: ArtworkImportState
    var allowLogo = false

    var body: some View {
        Button {
            state.asLogo = false
            state.photos = true
        } label: {
            Label("Cover or animation · Photos", systemImage: "photo.on.rectangle")
        }
        Button {
            state.asLogo = false
            state.files = true
        } label: {
            Label("Cover or animation · Files", systemImage: "folder")
        }
        if allowLogo {
            Button {
                state.asLogo = true
                state.photos = true
            } label: {
                Label("Logo · Photos", systemImage: "textformat")
            }
            Button {
                state.asLogo = true
                state.files = true
            } label: {
                Label("Logo · Files", systemImage: "folder.badge.plus")
            }
        }
    }
}

// MARK: - Artist artwork lookups

extension Library {
    /// Still (profile photo / banner) for an artist.
    func artistStillURL(_ name: String) -> URL? {
        let key: String = ArtistKey.make(name)
        return assetURL(key, .tall) ?? assetURL(key, .cover)
    }

    /// Pulls the artist photo from the chosen source (Apple Music / Spotify). Banner, logo and
    /// animations are not exposed by those public APIs, so they stay local.
    func fetchArtistPhoto(name: String, services: Services) {
        let key: String = ArtistKey.make(name)
        guard services.artistSourceReady, assetURL(key, .cover) == nil, assetURL(key, .tall) == nil else { return }
        let source: ArtistSource = services.artistSource
        let appleToken: String = services.appleToken
        let storefront: String = services.appleStorefront
        let spotifyID: String = services.spotifyID.trimmingCharacters(in: .whitespaces)
        let spotifySecret: String = services.spotifySecret.trimmingCharacters(in: .whitespaces)
        Task.detached(priority: .utility) { [weak self] in
            var remote: URL?
            if source == .apple {
                remote = await AppleMusicAPI.artistImage(name: name, token: appleToken, storefront: storefront)
            } else if source == .spotify {
                remote = await SpotifyClient.shared.artistImage(name: name, id: spotifyID, secret: spotifySecret)
            }
            guard let remote, let (tmp, _) = try? await URLSession.shared.download(from: remote),
                  let image = UIImage(contentsOfFile: tmp.path), let library = self else { return }
            library.setAsset(key, .cover, image: image)
            try? FileManager.default.removeItem(at: tmp)
            await MainActor.run {
                library.assetsChanged(key)
                library.persist()
            }
        }
    }

    func persist() { saveNow() }
}
