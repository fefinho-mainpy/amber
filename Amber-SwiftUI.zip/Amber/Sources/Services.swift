import Foundation
import SwiftUI

// MARK: - User-configurable sources (settings are stored in UserDefaults on this device)

enum ArtistSource: String, CaseIterable, Identifiable {
    case local, apple, spotify

    var id: String { rawValue }

    var title: String {
        switch self {
        case .local: return "Local only"
        case .apple: return "Apple Music"
        case .spotify: return "Spotify"
        }
    }
}

final class Services: ObservableObject {
    private let defaults = UserDefaults.standard

    @Published var artistSource: ArtistSource {
        didSet { defaults.set(artistSource.rawValue, forKey: "amber.artistSource") }
    }
    @Published var appleToken: String {
        didSet { defaults.set(appleToken, forKey: "amber.appleToken") }
    }
    @Published var appleStorefront: String {
        didSet { defaults.set(appleStorefront, forKey: "amber.appleStorefront") }
    }
    @Published var spotifyID: String {
        didSet { defaults.set(spotifyID, forKey: "amber.spotifyID") }
    }
    @Published var spotifySecret: String {
        didSet { defaults.set(spotifySecret, forKey: "amber.spotifySecret") }
    }
    @Published var spicyKey: String {
        didSet { defaults.set(spicyKey, forKey: "amber.spicyKey") }
    }
    @Published var preferSpicy: Bool {
        didSet { defaults.set(preferSpicy, forKey: "amber.preferSpicy") }
    }

    init() {
        let d = UserDefaults.standard
        artistSource = ArtistSource(rawValue: d.string(forKey: "amber.artistSource") ?? "") ?? .local
        appleToken = d.string(forKey: "amber.appleToken") ?? ""
        appleStorefront = d.string(forKey: "amber.appleStorefront") ?? "us"
        spotifyID = d.string(forKey: "amber.spotifyID") ?? ""
        spotifySecret = d.string(forKey: "amber.spotifySecret") ?? ""
        spicyKey = d.string(forKey: "amber.spicyKey") ?? ""
        preferSpicy = d.bool(forKey: "amber.preferSpicy")
    }

    var hasSpotify: Bool {
        !spotifyID.trimmingCharacters(in: .whitespaces).isEmpty
            && !spotifySecret.trimmingCharacters(in: .whitespaces).isEmpty
    }

    /// Spicy Lyrics needs a Spotify track id, so it also needs the Spotify credentials (used for the lookup).
    var hasSpicy: Bool {
        !spicyKey.trimmingCharacters(in: .whitespaces).isEmpty && hasSpotify
    }

    var hasApple: Bool {
        !appleToken.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var artistSourceReady: Bool {
        switch artistSource {
        case .local: return false
        case .apple: return hasApple
        case .spotify: return hasSpotify
        }
    }
}

enum ArtistKey {
    /// Asset-store key for an artist (kept separate from album keys).
    static func make(_ name: String) -> String {
        "artist:" + name.lowercased().trimmingCharacters(in: .whitespaces)
    }
}

// MARK: - Spotify Web API (client-credentials: public catalogue only)

actor SpotifyClient {
    static let shared = SpotifyClient()

    private var token: String?
    private var expiry = Date.distantPast

    private func accessToken(id: String, secret: String) async -> String? {
        if let token, expiry > Date() { return token }
        guard let url = URL(string: "https://accounts.spotify.com/api/token") else { return nil }
        var request = URLRequest(url: url, timeoutInterval: 20)
        request.httpMethod = "POST"
        let basic: String = Data((id + ":" + secret).utf8).base64EncodedString()
        request.setValue("Basic " + basic, forHTTPHeaderField: "Authorization")
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpBody = Data("grant_type=client_credentials".utf8)
        guard let (data, response) = try? await URLSession.shared.data(for: request),
              (response as? HTTPURLResponse)?.statusCode == 200,
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let value = json["access_token"] as? String else { return nil }
        let life: Double = (json["expires_in"] as? Double) ?? 3000
        token = value
        expiry = Date().addingTimeInterval(life - 60)
        return value
    }

    private func get(_ path: String, query: [URLQueryItem], id: String, secret: String) async -> [String: Any]? {
        guard let bearer = await accessToken(id: id, secret: secret),
              var comps = URLComponents(string: "https://api.spotify.com/v1/" + path) else { return nil }
        comps.queryItems = query
        guard let url = comps.url else { return nil }
        var request = URLRequest(url: url, timeoutInterval: 20)
        request.setValue("Bearer " + bearer, forHTTPHeaderField: "Authorization")
        guard let (data, response) = try? await URLSession.shared.data(for: request),
              (response as? HTTPURLResponse)?.statusCode == 200 else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }

    /// Spotify track id for a local song (needed by the Spicy Lyrics API).
    func trackID(title: String, artist: String, id: String, secret: String) async -> String? {
        let cacheKey: String = "amber.spotifyTrack." + (artist + "|" + title).lowercased()
        if let cached = UserDefaults.standard.string(forKey: cacheKey) { return cached.isEmpty ? nil : cached }
        var q: String = "track:" + title
        if !artist.isEmpty { q += " artist:" + artist }
        let query: [URLQueryItem] = [
            URLQueryItem(name: "q", value: q),
            URLQueryItem(name: "type", value: "track"),
            URLQueryItem(name: "limit", value: "1"),
        ]
        guard let json = await get("search", query: query, id: id, secret: secret) else { return nil }
        let tracks = json["tracks"] as? [String: Any]
        let items = tracks?["items"] as? [[String: Any]]
        let found = items?.first?["id"] as? String
        UserDefaults.standard.set(found ?? "", forKey: cacheKey)
        return found
    }

    func artistImage(name: String, id: String, secret: String) async -> URL? {
        let query: [URLQueryItem] = [
            URLQueryItem(name: "q", value: "artist:" + name),
            URLQueryItem(name: "type", value: "artist"),
            URLQueryItem(name: "limit", value: "3"),
        ]
        guard let json = await get("search", query: query, id: id, secret: secret) else { return nil }
        let artists = json["artists"] as? [String: Any]
        let items: [[String: Any]] = (artists?["items"] as? [[String: Any]]) ?? []
        let wanted: String = name.lowercased()
        let exact = items.first { ($0["name"] as? String)?.lowercased() == wanted }
        guard let pick = exact ?? items.first else { return nil }
        let images = pick["images"] as? [[String: Any]]
        guard let first = images?.first?["url"] as? String else { return nil }
        return URL(string: first)
    }
}

// MARK: - Apple Music API (official catalogue API: artist photo only)

enum AppleMusicAPI {
    static func artistImage(name: String, token: String, storefront: String) async -> URL? {
        let store: String = storefront.trimmingCharacters(in: .whitespaces).lowercased()
        guard var comps = URLComponents(string: "https://api.music.apple.com/v1/catalog/" + (store.isEmpty ? "us" : store) + "/search") else { return nil }
        comps.queryItems = [
            URLQueryItem(name: "term", value: name),
            URLQueryItem(name: "types", value: "artists"),
            URLQueryItem(name: "limit", value: "3"),
        ]
        guard let url = comps.url else { return nil }
        var request = URLRequest(url: url, timeoutInterval: 20)
        request.setValue("Bearer " + token.trimmingCharacters(in: .whitespaces), forHTTPHeaderField: "Authorization")
        guard let (data, response) = try? await URLSession.shared.data(for: request),
              (response as? HTTPURLResponse)?.statusCode == 200,
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        let results = json["results"] as? [String: Any]
        let artists = results?["artists"] as? [String: Any]
        let list: [[String: Any]] = (artists?["data"] as? [[String: Any]]) ?? []
        let wanted: String = name.lowercased()
        let exact = list.first { (($0["attributes"] as? [String: Any])?["name"] as? String)?.lowercased() == wanted }
        guard let pick = exact ?? list.first,
              let attributes = pick["attributes"] as? [String: Any],
              let artwork = attributes["artwork"] as? [String: Any],
              let template = artwork["url"] as? String else { return nil }
        let width: Int = min((artwork["width"] as? Int) ?? 2000, 2400)
        let resolved: String = template
            .replacingOccurrences(of: "{w}", with: String(width))
            .replacingOccurrences(of: "{h}", with: String(width))
            .replacingOccurrences(of: "{c}", with: "bb")
            .replacingOccurrences(of: "{f}", with: "jpg")
        return URL(string: resolved)
    }
}

// MARK: - Spicy Lyrics Developer API

struct LyricsCredit: Equatable {
    struct Person: Equatable {
        let role: String
        let name: String
        let url: URL?
    }

    var provider: String
    var people: [Person]
}

struct RemoteLyrics {
    let lyrics: Lyrics
    let credit: LyricsCredit
}

enum SpicyLyricsAPI {
    private static let base = "https://api.spicylyrics.org/v1/lyrics/"
    /// The terms require anything stored to be refetched or dropped within 30 days; stay well under.
    private static let cacheDays: Double = 14

    private static var cacheDir: URL {
        let root = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let dir = root.appendingPathComponent("spicy-lyrics", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    /// Looks the song up on Spotify (for the track id), then asks the Spicy Lyrics API.
    static func lyrics(title: String, artist: String, services: Services) async -> RemoteLyrics? {
        guard services.hasSpicy else { return nil }
        guard let trackID = await SpotifyClient.shared.trackID(
            title: title, artist: artist,
            id: services.spotifyID.trimmingCharacters(in: .whitespaces),
            secret: services.spotifySecret.trimmingCharacters(in: .whitespaces)
        ) else { return nil }
        guard let body = await body(for: trackID, key: services.spicyKey.trimmingCharacters(in: .whitespaces)) else { return nil }
        return parse(body)
    }

    private static func body(for trackID: String, key: String) async -> [String: Any]? {
        let file = cacheDir.appendingPathComponent(trackID + ".json")
        if let data = try? Data(contentsOf: file),
           let wrapper = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
           let fetched = wrapper["fetched"] as? Double {
            let age: Double = Date().timeIntervalSince1970 - fetched
            if age < cacheDays * 86400 {
                if wrapper["none"] as? Bool == true { return nil }
                if let cached = wrapper["body"] as? [String: Any] { return cached }
            } else {
                try? FileManager.default.removeItem(at: file)   // expired: refetch or discard
            }
        }

        guard let url = URL(string: base + trackID) else { return nil }
        var request = URLRequest(url: url, timeoutInterval: 20)
        request.setValue("Bearer " + key, forHTTPHeaderField: "Authorization")
        guard let (data, response) = try? await URLSession.shared.data(for: request),
              let http = response as? HTTPURLResponse else { return nil }

        let now: Double = Date().timeIntervalSince1970
        if http.statusCode == 404 {
            let marker: [String: Any] = ["fetched": now, "none": true]
            if let out = try? JSONSerialization.data(withJSONObject: marker) { try? out.write(to: file) }
            return nil
        }
        guard http.statusCode == 200,
              let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let body = json["Body"] as? [String: Any] else { return nil }
        let wrapper: [String: Any] = ["fetched": now, "body": body]
        if let out = try? JSONSerialization.data(withJSONObject: wrapper) { try? out.write(to: file) }
        return body
    }

    private static func number(_ value: Any?) -> Double {
        (value as? NSNumber)?.doubleValue ?? 0
    }

    private static func providerName(_ source: String?) -> String {
        switch source {
        case "spicy_lyrics": return "Spicy Lyrics"
        case "apple_music": return "Apple Music"
        case "spotify": return "Spotify"
        default: return "Unknown source"
        }
    }

    private static func person(_ role: String, _ value: Any?) -> LyricsCredit.Person? {
        guard let dict = value as? [String: Any], let name = dict["username"] as? String else { return nil }
        var link: URL?
        if let s = dict["url"] as? String { link = URL(string: s) }
        return LyricsCredit.Person(role: role, name: name, url: link)
    }

    static func parse(_ body: [String: Any]) -> RemoteLyrics? {
        let type: String = (body["Type"] as? String) ?? "Line"
        let source = body["source"] as? String
        var lines: [LyricLine] = []

        if let content = body["Content"] as? [[String: Any]] {
            for item in content {
                if type == "Syllable" {
                    guard let lead = item["Lead"] as? [String: Any],
                          let syllables = lead["Syllables"] as? [[String: Any]] else { continue }
                    var words: [LyricWord] = []
                    var text = ""
                    for syllable in syllables {
                        let piece: String = (syllable["Text"] as? String) ?? ""
                        let part: Bool = (syllable["IsPartOfWord"] as? Bool) ?? false
                        words.append(LyricWord(text: piece, time: number(syllable["StartTime"]), spaceAfter: !part))
                        text += piece
                        if !part { text += " " }
                    }
                    let clean: String = text.trimmingCharacters(in: .whitespaces)
                    if clean.isEmpty { continue }
                    let start: Double = lead["StartTime"] != nil ? number(lead["StartTime"]) : (words.first?.time ?? 0)
                    lines.append(LyricLine(id: lines.count, time: start, text: clean, words: words))
                } else {
                    let lead = item["Lead"] as? [String: Any]
                    let raw: String = (item["Text"] as? String) ?? (lead?["Text"] as? String) ?? ""
                    let clean: String = raw.trimmingCharacters(in: .whitespacesAndNewlines)
                    if clean.isEmpty { continue }
                    let hasTime: Bool = item["StartTime"] != nil && type != "Static"
                    lines.append(LyricLine(id: lines.count, time: hasTime ? number(item["StartTime"]) : nil, text: clean, words: []))
                }
            }
        }
        guard !lines.isEmpty else { return nil }

        var people: [LyricsCredit.Person] = []
        if source == "spicy_lyrics", let attribution = body["UploadAttribution"] as? [String: Any] {
            if let p = person("Uploader", attribution["Uploader"]) { people.append(p) }
            if let p = person("Maker", attribution["Maker"]) { people.append(p) }
        }
        let credit = LyricsCredit(provider: providerName(source), people: people)
        return RemoteLyrics(lyrics: Lyrics(synced: type != "Static", lines: lines), credit: credit)
    }
}
