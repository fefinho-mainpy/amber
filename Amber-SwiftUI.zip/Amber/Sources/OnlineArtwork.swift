import Foundation

/// Port of the web app's `online()` lookup. The lock-screen animated-artwork API only accepts
/// *local* video files, so streams (HLS) are downloaded and stitched into a local .mp4 first.
enum OnlineArtwork {
    struct Result {
        var squareFile: URL?
        var tallFile: URL?
        var imageFile: URL?
    }

    private static let api = "https://artwork.m8tec.top/api/v1/artwork/search"

    private static func has(_ s: String, _ pattern: String) -> Bool {
        s.range(of: pattern, options: [.regularExpression, .caseInsensitive]) != nil
    }

    private static func walk(_ o: Any, path: String, into out: inout [(path: String, url: String)]) {
        if let s = o as? String {
            if s.hasPrefix("http://") || s.hasPrefix("https://") { out.append((path, s)) }
        } else if let d = o as? [String: Any] {
            for (k, v) in d { walk(v, path: path + "." + k.lowercased(), into: &out) }
        } else if let a = o as? [Any] {
            for (i, v) in a.enumerated() { walk(v, path: path + "." + String(i), into: &out) }
        }
    }

    static func fetch(
        artist: String, album: String, title: String,
        needSquare: Bool, needTall: Bool, needImage: Bool
    ) async -> Result {
        var result = Result()
        guard var comps = URLComponents(string: api) else { return result }
        comps.queryItems = [
            URLQueryItem(name: "artist", value: artist),
            URLQueryItem(name: "album", value: album),
            URLQueryItem(name: "title", value: title),
        ]
        guard let url = comps.url else { return result }
        guard let (data, _) = try? await URLSession.shared.data(for: URLRequest(url: url, timeoutInterval: 20)),
              let json = try? JSONSerialization.jsonObject(with: data) else { return result }

        var found: [(path: String, url: String)] = []
        walk(json, path: "", into: &found)
        found.sort { $0.path < $1.path }   // dictionaries are unordered: keep the choice deterministic

        let videos = found.filter { has($0.url, "\\.(m3u8|mp4)(\\?|$)") }
        let square = videos.first { has($0.path + $0.url, "square|1x1") }
            ?? videos.first { !has($0.path + $0.url, "tall") }
        let tall = videos.first { has($0.path + $0.url, "tall") }
        let image = found.first {
            has($0.url, "\\.(jpe?g|png|webp)(\\?|$)|mzstatic") && !has($0.url, "m3u8|mp4")
        }

        if needSquare, let square, let u = URL(string: square.url) {
            result.squareFile = try? await downloadVideo(u)
        }
        if needTall, let tall, let u = URL(string: tall.url) {
            result.tallFile = try? await downloadVideo(u)
        }
        if needImage, let image {
            let resolved = image.url
                .replacingOccurrences(of: "{w}", with: "1200")
                .replacingOccurrences(of: "{h}", with: "1200")
                .replacingOccurrences(of: "{c}", with: "bb")
                .replacingOccurrences(of: "{f}", with: "jpg")
            if let u = URL(string: resolved), let (tmp, _) = try? await URLSession.shared.download(from: u) {
                let dest = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".jpg")
                if (try? FileManager.default.moveItem(at: tmp, to: dest)) != nil { result.imageFile = dest }
            }
        }
        return result
    }

    private static func downloadVideo(_ url: URL) async throws -> URL {
        let dest = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mp4")
        if url.absoluteString.lowercased().contains(".m3u8") {
            try await HLS.download(url, to: dest)
        } else {
            let (tmp, _) = try await URLSession.shared.download(from: url)
            try FileManager.default.moveItem(at: tmp, to: dest)
        }
        return dest
    }
}

/// Minimal HLS -> single fragmented-MP4 converter (works for CMAF/fMP4 playlists such as Apple's
/// animated artwork; MPEG-TS playlists are rejected).
enum HLS {
    struct Failure: Error {}

    private static func string(from url: URL) async throws -> String {
        let (data, _) = try await URLSession.shared.data(from: url)
        return String(decoding: data, as: UTF8.self)
    }

    private static func attribute(_ name: String, in line: String) -> String? {
        let pattern = "(?:^|[:,])" + name + "=\"?([^\",]*)\"?"
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return nil }
        let ns = line as NSString
        guard let m = regex.firstMatch(in: line, range: NSRange(location: 0, length: ns.length)),
              m.numberOfRanges > 1 else { return nil }
        return ns.substring(with: m.range(at: 1))
    }

    private static func pickVariant(_ master: String, base: URL) -> URL? {
        var best: (area: Int, url: URL)?
        var pendingArea: Int?
        for raw in master.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.hasPrefix("#EXT-X-STREAM-INF") {
                var area = 0
                if let res = attribute("RESOLUTION", in: line) {
                    let p = res.split(separator: "x").compactMap { Int($0) }
                    if p.count == 2 { area = p[0] * p[1] }
                }
                pendingArea = area
            } else if !line.hasPrefix("#"), !line.isEmpty, let area = pendingArea {
                pendingArea = nil
                guard let u = URL(string: line, relativeTo: base)?.absoluteURL else { continue }
                let limit = 1080 * 1440
                let better: Bool
                if let b = best {
                    better = (area <= limit && b.area > limit) || (area <= limit && area > b.area) || (b.area > limit && area < b.area)
                } else {
                    better = true
                }
                if better { best = (area, u) }
            }
        }
        return best?.url
    }

    static func download(_ playlist: URL, to dest: URL) async throws {
        var mediaURL = playlist
        var text = try await string(from: playlist)
        if text.contains("#EXT-X-STREAM-INF") {
            guard let variant = pickVariant(text, base: playlist) else { throw Failure() }
            mediaURL = variant
            text = try await string(from: variant)
        }

        var parts: [(url: URL, range: (offset: Int, length: Int)?)] = []
        var nextOffset: [String: Int] = [:]
        var pending: String?

        func parseRange(_ spec: String, resource: String) -> (offset: Int, length: Int)? {
            let bits = spec.split(separator: "@")
            guard let length = Int(bits[0]) else { return nil }
            let offset = bits.count > 1 ? (Int(bits[1]) ?? 0) : (nextOffset[resource] ?? 0)
            nextOffset[resource] = offset + length
            return (offset, length)
        }

        for raw in text.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.hasPrefix("#EXT-X-MAP:") {
                guard let uri = attribute("URI", in: line),
                      let u = URL(string: uri, relativeTo: mediaURL)?.absoluteURL else { throw Failure() }
                var r: (offset: Int, length: Int)?
                if let br = attribute("BYTERANGE", in: line) { r = parseRange(br, resource: u.absoluteString) }
                parts.append((u, r))
            } else if line.hasPrefix("#EXT-X-BYTERANGE:") {
                pending = String(line.dropFirst("#EXT-X-BYTERANGE:".count))
            } else if line.isEmpty || line.hasPrefix("#") {
                continue
            } else {
                guard let u = URL(string: line, relativeTo: mediaURL)?.absoluteURL else { throw Failure() }
                if u.path.lowercased().hasSuffix(".ts") { throw Failure() }
                var r: (offset: Int, length: Int)?
                if let p = pending { r = parseRange(p, resource: u.absoluteString); pending = nil }
                parts.append((u, r))
            }
        }
        guard !parts.isEmpty else { throw Failure() }

        FileManager.default.createFile(atPath: dest.path, contents: nil)
        let handle = try FileHandle(forWritingTo: dest)
        defer { try? handle.close() }
        for part in parts {
            var request = URLRequest(url: part.url, timeoutInterval: 30)
            if let r = part.range {
                request.setValue("bytes=\(r.offset)-\(r.offset + r.length - 1)", forHTTPHeaderField: "Range")
            }
            let (data, _) = try await URLSession.shared.data(for: request)
            try handle.write(contentsOf: data)
        }
    }
}
