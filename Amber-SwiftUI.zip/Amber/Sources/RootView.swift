import SwiftUI
import UniformTypeIdentifiers

struct AlbumRoute: Hashable { let key: String }
struct ArtistRoute: Hashable { let name: String }
enum LibrarySection: String, Hashable { case artists, albums, songs, liked }
enum ImportMode { case files, folder }
enum AppTab: Hashable { case home, library, search }

struct AlbumSection: Identifiable {
    let id: String          // the section letter
    var albums: [AlbumGroup]
}

struct LibraryActions {
    let importFiles: () -> Void
    let importFolder: () -> Void
    let customize: () -> Void
    let syncAppleMusic: () -> Void
}

extension Library {
    /// Albums grouped by first letter (A–Z, then #).
    func albumSections() -> [AlbumSection] {
        var out: [AlbumSection] = []
        for album in albums {
            let first: String = String(album.title.prefix(1)).uppercased()
            let letter: String = first.range(of: "[A-Z]", options: .regularExpression) != nil ? first : "#"
            if let last = out.last, last.id == letter {
                out[out.count - 1].albums.append(album)
            } else {
                out.append(AlbumSection(id: letter, albums: [album]))
            }
        }
        return out
    }

    /// The albums that were added last.
    func recentAlbums(limit: Int) -> [AlbumGroup] {
        var seen = Set<String>()
        var keys: [String] = []
        for t in tracks.sorted(by: { $0.id > $1.id }) {
            if seen.insert(t.key).inserted { keys.append(t.key) }
            if keys.count >= limit { break }
        }
        return keys.compactMap { key in albums.first { $0.id == key } }
    }
}

private struct AppDestinations: ViewModifier {
    func body(content: Content) -> some View {
        content
            .navigationDestination(for: AlbumRoute.self) { route in AlbumPage(key: route.key) }
            .navigationDestination(for: ArtistRoute.self) { route in ArtistPage(name: route.name) }
            .navigationDestination(for: LibrarySection.self) { section in LibrarySectionPage(section: section) }
    }
}

// MARK: - Root (Apple Music style tab bar + mini player accessory)

struct RootView: View {
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme
    @EnvironmentObject private var services: Services

    @State private var tab: AppTab = .library
    @State private var homePath = NavigationPath()
    @State private var libraryPath = NavigationPath()
    @State private var searchPath = NavigationPath()
    @State private var showNowPlaying = false
    @State private var showCustomize = false
    @State private var showImporter = false
    @State private var importMode: ImportMode = .files

    private var importTypes: [UTType] {
        if importMode == .folder { return [.folder] }
        var types: [UTType] = [.audio, .image, .movie, .plainText, .xml]
        if let lrc = UTType(filenameExtension: "lrc") { types.append(lrc) }
        if let ttml = UTType(filenameExtension: "ttml") { types.append(ttml) }
        return types
    }

    private var actions: LibraryActions {
        LibraryActions(
            importFiles: { importMode = .files; showImporter = true },
            importFolder: { importMode = .folder; showImporter = true },
            customize: { showCustomize = true },
            syncAppleMusic: { Task { await AppleMusicSync.run(into: library) } }
        )
    }

    var body: some View {
        TabView(selection: $tab) {
            Tab("Home", systemImage: "house.fill", value: AppTab.home) {
                NavigationStack(path: $homePath) {
                    HomeTab(actions: actions).modifier(AppDestinations())
                }
            }
            Tab("Library", systemImage: "music.note.square.stack.fill", value: AppTab.library) {
                NavigationStack(path: $libraryPath) {
                    LibraryTab(actions: actions).modifier(AppDestinations())
                }
            }
            Tab(value: AppTab.search, role: .search) {
                NavigationStack(path: $searchPath) {
                    SearchTab().modifier(AppDestinations())
                }
            }
        }
        .tabBarMinimizeBehavior(.onScrollDown)
        .tabViewBottomAccessory(isEnabled: player.current != nil) {
            MiniPlayer { showNowPlaying = true }
        }
        .tint(theme.ac)
        .preferredColorScheme(theme.scheme)
        .overlay(alignment: .top) {
            if let text = library.status {
                Toast(text: text)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.25), value: library.status)
        .fullScreenCover(isPresented: $showNowPlaying) {
            NowPlayingView(
                close: { showNowPlaying = false },
                openAlbum: { key in
                    showNowPlaying = false
                    tab = .library
                    libraryPath.append(AlbumRoute(key: key))
                },
                openArtist: { name in
                    showNowPlaying = false
                    tab = .library
                    libraryPath.append(ArtistRoute(name: name))
                }
            )
            .environmentObject(library)
            .environmentObject(player)
            .environmentObject(theme)
            .environmentObject(services)
        }
        .sheet(isPresented: $showCustomize) {
            CustomizeSheet()
                .environmentObject(library)
                .environmentObject(player)
                .environmentObject(theme)
                .environmentObject(services)
        }
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: importTypes,
            allowsMultipleSelection: true
        ) { result in
            if case .success(let urls) = result { library.importItems(urls) }
        }
    }
}

// MARK: - Shared toolbar + empty state

private struct LibraryToolbar: ToolbarContent {
    let actions: LibraryActions

    var body: some ToolbarContent {
        ToolbarItemGroup(placement: .topBarTrailing) {
            Menu {
                Button(action: actions.importFiles) { Label("Add files", systemImage: "plus") }
                Button(action: actions.importFolder) { Label("Add folder", systemImage: "folder.badge.plus") }
                Button(action: actions.syncAppleMusic) { Label("Sync from Apple Music", systemImage: "arrow.triangle.2.circlepath") }
            } label: {
                Image(systemName: "plus")
            }
            Button(action: actions.customize) {
                Image(systemName: "slider.horizontal.3")
            }
        }
    }
}

private struct EmptyLibrary: View {
    let actions: LibraryActions
    @EnvironmentObject private var theme: Theme

    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: "music.note.list")
                .font(.system(size: 38))
                .foregroundStyle(theme.mu)
            Text("Nothing here yet")
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(theme.fg)
            Text("Add songs, a whole folder with covers, animations and lyrics, or sync the downloaded songs of your Music app.")
                .font(.system(size: 14))
                .multilineTextAlignment(.center)
                .foregroundStyle(theme.mu)
            HStack(spacing: 10) {
                PillButton(title: "Add files", systemImage: "plus", filled: true, action: actions.importFiles)
                PillButton(title: "Sync Music", systemImage: "arrow.triangle.2.circlepath", action: actions.syncAppleMusic)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 50)
    }
}

// MARK: - Home

struct HomeTab: View {
    let actions: LibraryActions

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                if library.tracks.isEmpty {
                    EmptyLibrary(actions: actions)
                } else {
                    if !library.forYou.isEmpty { forYouSection }
                    if !library.artists.isEmpty { artistsSection }
                    recentSection
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 28)
        }
        .background(theme.bg.ignoresSafeArea())
        .navigationTitle("Home")
        .toolbar { LibraryToolbar(actions: actions) }
    }

    private var forYouSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "For you")
            VStack(spacing: 0) {
                ForEach(library.forYou) { t in
                    TrackRow(track: t, showAlbumArtwork: true) { player.play(t, in: nil) }
                }
            }
        }
    }

    private var artistsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "Artists")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 18) {
                    ForEach(library.artists) { artist in
                        NavigationLink(value: ArtistRoute(name: artist.name)) {
                            ArtistAvatar(artist: artist)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private var recentSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "Recently added")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 16) {
                    ForEach(library.recentAlbums(limit: 10)) { album in
                        NavigationLink(value: AlbumRoute(key: album.id)) {
                            AlbumTile(album: album).frame(width: 156)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

// MARK: - Library

struct LibraryTab: View {
    let actions: LibraryActions

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var theme: Theme

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                VStack(spacing: 0) {
                    row("Artists", "music.mic", .artists)
                    row("Albums", "square.stack", .albums)
                    row("Songs", "music.note", .songs)
                    row("Liked", "heart", .liked)
                }
                if library.tracks.isEmpty {
                    EmptyLibrary(actions: actions)
                } else {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("Recently added")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundStyle(theme.fg)
                        LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 20) {
                            ForEach(library.recentAlbums(limit: 6)) { album in
                                NavigationLink(value: AlbumRoute(key: album.id)) {
                                    AlbumTile(album: album)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 4)
            .padding(.bottom, 28)
        }
        .background(theme.bg.ignoresSafeArea())
        .navigationTitle("Library")
        .toolbar { LibraryToolbar(actions: actions) }
    }

    private func row(_ title: String, _ symbol: String, _ section: LibrarySection) -> some View {
        NavigationLink(value: section) {
            HStack(spacing: 16) {
                Image(systemName: symbol)
                    .font(.system(size: 22))
                    .foregroundStyle(theme.ac)
                    .frame(width: 34)
                VStack(spacing: 0) {
                    HStack {
                        Text(title)
                            .font(.system(size: 22))
                            .foregroundStyle(theme.fg)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(theme.mu)
                    }
                    .padding(.vertical, 14)
                    Divider().overlay(theme.ln)
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

struct LibrarySectionPage: View {
    let section: LibrarySection

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    private var title: String {
        switch section {
        case .artists: return "Artists"
        case .albums: return "Albums"
        case .songs: return "Songs"
        case .liked: return "Liked"
        }
    }

    private var songs: [Track] {
        let sorted: [Track] = library.tracks.sorted {
            $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending
        }
        if section == .liked { return sorted.filter { library.isLiked($0) } }
        return sorted
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                switch section {
                case .artists: artistList
                case .albums: albumGrid
                case .songs, .liked: songList
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 28)
        }
        .background(theme.bg.ignoresSafeArea())
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.large)
    }

    private var artistList: some View {
        LazyVStack(spacing: 0) {
            ForEach(library.artists) { artist in
                NavigationLink(value: ArtistRoute(name: artist.name)) {
                    HStack(spacing: 14) {
                        CoverView(
                            url: library.artistStillURL(artist.name) ?? library.assetURL(artist.tracks[0].key, .cover),
                            letter: artist.name, maxSide: 200
                        )
                        .frame(width: 54, height: 54)
                        .clipShape(Circle())
                        Text(artist.name)
                            .font(.system(size: 18))
                            .foregroundStyle(theme.fg)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(theme.mu)
                    }
                    .padding(.vertical, 8)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var albumGrid: some View {
        ForEach(library.albumSections()) { sectionItem in
            VStack(alignment: .leading, spacing: 12) {
                Text(sectionItem.id)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(theme.ac)
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 20) {
                    ForEach(sectionItem.albums) { album in
                        NavigationLink(value: AlbumRoute(key: album.id)) {
                            AlbumTile(album: album)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    @ViewBuilder
    private var songList: some View {
        if songs.isEmpty {
            Text(section == .liked ? "Songs you like show up here." : "No songs yet.")
                .font(.system(size: 15))
                .foregroundStyle(theme.mu)
                .frame(maxWidth: .infinity)
                .padding(.top, 40)
        } else {
            LazyVStack(spacing: 0) {
                ForEach(songs) { t in
                    TrackRow(track: t, showAlbumArtwork: true) { player.play(t, in: songs) }
                }
            }
        }
    }
}

// MARK: - Search

struct SearchTab: View {
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    @State private var text = ""

    private var query: String { text.trimmingCharacters(in: .whitespaces) }

    private var genres: [String] {
        var counts: [String: Int] = [:]
        for t in library.tracks where !t.genre.isEmpty { counts[t.genre, default: 0] += 1 }
        return counts.keys.sorted()
    }

    private var artistHits: [ArtistGroup] {
        library.artists.filter { $0.name.localizedCaseInsensitiveContains(query) }
    }

    private var albumHits: [AlbumGroup] {
        library.albums.filter {
            $0.title.localizedCaseInsensitiveContains(query) || $0.first.artistName.localizedCaseInsensitiveContains(query)
        }
    }

    private var songHits: [Track] {
        library.tracks.filter {
            $0.title.localizedCaseInsensitiveContains(query)
                || $0.artist.localizedCaseInsensitiveContains(query)
                || $0.genre.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                if query.isEmpty { genreGrid } else { results }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 28)
        }
        .background(theme.bg.ignoresSafeArea())
        .navigationTitle("Search")
        .searchable(text: $text, prompt: "Your library")
    }

    private var genreGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 14) {
            ForEach(genres, id: \.self) { genre in
                let raw: Int = Int(truncatingIfNeeded: stableHash(genre)) & 0x7fffffff
                let hue: Double = Double(raw % 360) / 360
                Button { text = genre } label: {
                    Text(genre)
                        .font(.system(size: 19, weight: .semibold))
                        .foregroundStyle(Color.white)
                        .padding(14)
                        .frame(maxWidth: .infinity, minHeight: 96, alignment: .bottomLeading)
                        .background(Color(hue: hue, saturation: 0.55, brightness: 0.72), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }

    @ViewBuilder
    private var results: some View {
        if artistHits.isEmpty && albumHits.isEmpty && songHits.isEmpty {
            Text("No results for “\(query)”")
                .font(.system(size: 15))
                .foregroundStyle(theme.mu)
                .frame(maxWidth: .infinity)
                .padding(.top, 40)
        }
        if !artistHits.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Artists")
                ForEach(artistHits) { artist in
                    NavigationLink(value: ArtistRoute(name: artist.name)) {
                        HStack(spacing: 14) {
                            CoverView(
                                url: library.artistStillURL(artist.name) ?? library.assetURL(artist.tracks[0].key, .cover),
                                letter: artist.name, maxSide: 200
                            )
                            .frame(width: 48, height: 48)
                            .clipShape(Circle())
                            Text(artist.name).font(.system(size: 17)).foregroundStyle(theme.fg)
                            Spacer()
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        if !albumHits.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Albums")
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 20) {
                    ForEach(albumHits) { album in
                        NavigationLink(value: AlbumRoute(key: album.id)) { AlbumTile(album: album) }
                            .buttonStyle(.plain)
                    }
                }
            }
        }
        if !songHits.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                SectionTitle(text: "Songs")
                ForEach(songHits) { t in
                    TrackRow(track: t, showAlbumArtwork: true) { player.play(t, in: songHits) }
                }
            }
        }
    }
}

// MARK: - Pieces

struct TrackRow: View {
    let track: Track
    var showAlbumArtwork = false
    var showSubtitle = true
    var numbered: Int?
    var onEdit: (() -> Void)?
    let action: () -> Void

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme
    @Environment(\.art) private var art

    private var isCurrent: Bool { player.current?.id == track.id }
    private var ac: Color { art?.accent ?? theme.ac }

    var body: some View {
        let liked: Bool = library.isLiked(track)
        return HStack(spacing: 12) {
            Button(action: action) {
                HStack(spacing: 12) {
                    if showAlbumArtwork {
                        CoverView(url: library.assetURL(track.key, .cover), letter: track.displayAlbum, maxSide: 200)
                            .frame(width: 48, height: 48)
                            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    } else if let numbered {
                        Text(numbered > 0 ? "\(numbered)" : "·")
                            .font(.system(size: 14).monospacedDigit())
                            .foregroundStyle(isCurrent ? ac : theme.mu)
                            .frame(width: 26)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(track.title)
                            .font(.system(size: 16, weight: isCurrent ? .semibold : .regular))
                            .foregroundStyle(isCurrent ? ac : theme.fg)
                            .lineLimit(1)
                        if showSubtitle {
                            Text(track.artist.isEmpty ? track.displayAlbum : track.artist)
                                .font(.system(size: 13))
                                .foregroundStyle(theme.mu)
                                .lineLimit(1)
                        }
                    }
                    Spacer(minLength: 8)
                    if isCurrent {
                        Image(systemName: player.isPlaying ? "waveform" : "pause.fill")
                            .font(.system(size: 13))
                            .foregroundStyle(ac)
                    }
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if liked {
                Button { library.toggleLike(track) } label: {
                    Image(systemName: "checkmark.circle.fill")
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(Color.white, ac)
                        .font(.system(size: 20))
                }
                .buttonStyle(.plain)
            }

            if let onEdit {
                Button(action: onEdit) {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(theme.mu)
                        .frame(width: 34, height: 34)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 7)
        .contextMenu {
            Button { library.toggleLike(track) } label: {
                Label(liked ? "Remove like" : "Like", systemImage: liked ? "checkmark.circle" : "plus.circle")
            }
        }
    }
}

struct AlbumTile: View {
    let album: AlbumGroup
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var theme: Theme

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            CoverView(url: library.assetURL(album.id, .cover), letter: album.title, maxSide: 520)
                .aspectRatio(1, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            Text(album.title)
                .font(theme.serif(17))
                .foregroundStyle(theme.fg)
                .lineLimit(1)
            Text(subtitle)
                .font(.system(size: 13))
                .foregroundStyle(theme.mu)
                .lineLimit(1)
        }
    }

    private var subtitle: String {
        let artist = album.first.artistName
        let year = album.first.year
        return [artist, year].filter { !$0.isEmpty }.joined(separator: " · ")
    }
}

struct ArtistAvatar: View {
    let artist: ArtistGroup
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var theme: Theme

    var body: some View {
        VStack(spacing: 8) {
            CoverView(url: library.artistStillURL(artist.name) ?? library.assetURL(artist.tracks[0].key, .cover), letter: artist.name, maxSide: 300)
                .frame(width: 78, height: 78)
                .clipShape(Circle())
            Text(artist.name)
                .font(.system(size: 13))
                .foregroundStyle(theme.fg)
                .lineLimit(1)
                .frame(width: 84)
        }
    }
}

struct MiniPlayer: View {
    let open: () -> Void

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    var body: some View {
        if let t = player.current {
            ViewThatFits(in: .horizontal) {
                layout(t, showForward: true)
                layout(t, showForward: false)
            }
        }
    }

    private func layout(_ t: Track, showForward: Bool) -> some View {
        HStack(spacing: 12) {
            HStack(spacing: 12) {
                CoverView(url: library.assetURL(t.key, .cover), letter: t.displayAlbum, maxSide: 200)
                    .frame(width: 38, height: 38)
                    .clipShape(RoundedRectangle(cornerRadius: 7, style: .continuous))
                VStack(alignment: .leading, spacing: 1) {
                    Text(t.title)
                        .font(.system(size: 15, weight: .semibold))
                        .lineLimit(1)
                    Text(t.artist)
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 4)
            }
            .contentShape(Rectangle())
            .onTapGesture(perform: open)

            Button { player.togglePlay() } label: {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 19, weight: .bold))
                    .frame(width: 38, height: 38)
            }
            .buttonStyle(.plain)

            if showForward {
                Button { player.skip() } label: {
                    Image(systemName: "forward.fill")
                        .font(.system(size: 19, weight: .bold))
                        .frame(width: 38, height: 38)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 12)
    }
}
