import SwiftUI
import UniformTypeIdentifiers

struct AlbumRoute: Hashable { let key: String }
struct ArtistRoute: Hashable { let name: String }

enum ImportMode { case files, folder }

struct AlbumSection: Identifiable {
    let id: String          // the section letter
    var albums: [AlbumGroup]
}

struct RootView: View {
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    @State private var path = NavigationPath()
    @State private var showNowPlaying = false
    @State private var showCustomize = false
    @State private var showImporter = false
    @State private var importMode: ImportMode = .files

    private var importTypes: [UTType] {
        if importMode == .folder { return [.folder] }
        var types: [UTType] = [.audio, .image, .movie, .plainText, .xml]
        if let lrc = UTType(filenameExtension: "lrc") { types.append(lrc) }
        if let ttml = UTType(filenameExtension: "ttml") { types.append(ttml) }
        return types
    }

    var body: some View {
        NavigationStack(path: $path) {
            HomeView(
                importFiles: { importMode = .files; showImporter = true },
                importFolder: { importMode = .folder; showImporter = true },
                openCustomize: { showCustomize = true }
            )
            .navigationDestination(for: AlbumRoute.self) { route in
                AlbumPage(key: route.key)
            }
            .navigationDestination(for: ArtistRoute.self) { route in
                ArtistPage(name: route.name)
            }
        }
        .tint(theme.ac)
        .preferredColorScheme(theme.scheme)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if player.current != nil {
                MiniPlayer { showNowPlaying = true }
            }
        }
        .overlay(alignment: .top) {
            if let text = library.status {
                Toast(text: text)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.25), value: library.status)
        .fullScreenCover(isPresented: $showNowPlaying) {
            NowPlayingView(
                close: { showNowPlaying = false },
                openAlbum: { key in
                    showNowPlaying = false
                    path.append(AlbumRoute(key: key))
                },
                openArtist: { name in
                    showNowPlaying = false
                    path.append(ArtistRoute(name: name))
                }
            )
            .environmentObject(library)
            .environmentObject(player)
            .environmentObject(theme)
        }
        .sheet(isPresented: $showCustomize) {
            CustomizeSheet()
                .environmentObject(library)
                .environmentObject(player)
                .environmentObject(theme)
        }
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: importTypes,
            allowsMultipleSelection: true
        ) { result in
            if case .success(let urls) = result { library.importItems(urls) }
        }
    }
}

// MARK: - Home

struct HomeView: View {
    let importFiles: () -> Void
    let importFolder: () -> Void
    let openCustomize: () -> Void

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    private var albumSections: [AlbumSection] {
        var out: [AlbumSection] = []
        for album in library.albums {
            let first = String(album.title.prefix(1)).uppercased()
            let letter = first.range(of: "[A-Z]", options: .regularExpression) != nil ? first : "#"
            if let last = out.last, last.id == letter {
                out[out.count - 1].albums.append(album)
            } else {
                out.append(AlbumSection(id: letter, albums: [album]))
            }
        }
        return out
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                header
                HStack(spacing: 10) {
                    PillButton(title: "Add files", systemImage: "plus", filled: true, action: importFiles)
                    PillButton(title: "Add folder", systemImage: "folder.badge.plus", action: importFolder)
                }
                if library.tracks.isEmpty {
                    emptyState
                } else {
                    if !library.forYou.isEmpty { forYouSection }
                    if !library.artists.isEmpty { artistsSection }
                    albumsSection
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 14)
            .padding(.bottom, 28)
        }
        .background(theme.bg.ignoresSafeArea())
        .toolbar(.hidden, for: .navigationBar)
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Library")
                    .font(theme.title(40))
                    .foregroundStyle(theme.fg)
                Text("\(library.tracks.count) songs · \(library.albums.count) albums")
                    .font(.system(size: 14))
                    .foregroundStyle(theme.mu)
            }
            Spacer()
            Button(action: openCustomize) {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(theme.fg)
                    .frame(width: 42, height: 42)
                    .background(theme.sf, in: Circle())
                    .overlay(Circle().stroke(theme.ln, lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "music.note.list")
                .font(.system(size: 38))
                .foregroundStyle(theme.mu)
            Text("Nothing here yet")
                .font(theme.serif(24))
                .foregroundStyle(theme.fg)
            Text("Add songs, or a whole folder with covers, animated covers and lyrics next to the music.")
                .font(.system(size: 14))
                .multilineTextAlignment(.center)
                .foregroundStyle(theme.mu)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 50)
    }

    private var forYouSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "For you")
            VStack(spacing: 0) {
                ForEach(library.forYou) { t in
                    TrackRow(track: t, showAlbumArtwork: true) { player.play(t, in: nil) }
                }
            }
        }
    }

    private var artistsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "Artists")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 18) {
                    ForEach(library.artists) { artist in
                        NavigationLink(value: ArtistRoute(name: artist.name)) {
                            ArtistAvatar(artist: artist)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private var albumsSection: some View {
        VStack(alignment: .leading, spacing: 18) {
            SectionTitle(text: "Albums")
            ForEach(albumSections) { section in
                VStack(alignment: .leading, spacing: 12) {
                    Text(section.id)
                        .font(theme.serif(15, weight: .semibold))
                        .foregroundStyle(theme.ac)
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 20) {
                        ForEach(section.albums) { album in
                            NavigationLink(value: AlbumRoute(key: album.id)) {
                                AlbumTile(album: album)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Pieces

struct TrackRow: View {
    let track: Track
    var showAlbumArtwork = false
    var numbered: Int?
    var onEdit: (() -> Void)?
    let action: () -> Void

    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    private var isCurrent: Bool { player.current?.id == track.id }

    var body: some View {
        HStack(spacing: 12) {
            Button(action: action) {
                HStack(spacing: 12) {
                    if showAlbumArtwork {
                        CoverView(url: library.assetURL(track.key, .cover), letter: track.displayAlbum, maxSide: 200)
                            .frame(width: 48, height: 48)
                            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    } else if let numbered {
                        Text(numbered > 0 ? "\(numbered)" : "·")
                            .font(.system(size: 14).monospacedDigit())
                            .foregroundStyle(isCurrent ? theme.ac : theme.mu)
                            .frame(width: 26)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(track.title)
                            .font(.system(size: 16, weight: isCurrent ? .semibold : .regular))
                            .foregroundStyle(isCurrent ? theme.ac : theme.fg)
                            .lineLimit(1)
                        Text(track.artist.isEmpty ? track.displayAlbum : track.artist)
                            .font(.system(size: 13))
                            .foregroundStyle(theme.mu)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 8)
                    if isCurrent {
                        Image(systemName: player.isPlaying ? "waveform" : "pause.fill")
                            .font(.system(size: 13))
                            .foregroundStyle(theme.ac)
                    }
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if let onEdit {
                Button(action: onEdit) {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(theme.mu)
                        .frame(width: 34, height: 34)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 7)
    }
}

struct AlbumTile: View {
    let album: AlbumGroup
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var theme: Theme

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            CoverView(url: library.assetURL(album.id, .cover), letter: album.title, maxSide: 520)
                .aspectRatio(1, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            Text(album.title)
                .font(theme.serif(17))
                .foregroundStyle(theme.fg)
                .lineLimit(1)
            Text(subtitle)
                .font(.system(size: 13))
                .foregroundStyle(theme.mu)
                .lineLimit(1)
        }
    }

    private var subtitle: String {
        let artist = album.first.artistName
        let year = album.first.year
        return [artist, year].filter { !$0.isEmpty }.joined(separator: " · ")
    }
}

struct ArtistAvatar: View {
    let artist: ArtistGroup
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var theme: Theme

    var body: some View {
        VStack(spacing: 8) {
            CoverView(url: library.assetURL(artist.tracks[0].key, .cover), letter: artist.name, maxSide: 300)
                .frame(width: 78, height: 78)
                .clipShape(Circle())
            Text(artist.name)
                .font(.system(size: 13))
                .foregroundStyle(theme.fg)
                .lineLimit(1)
                .frame(width: 84)
        }
    }
}

struct MiniPlayer: View {
    let open: () -> Void
    @EnvironmentObject private var library: Library
    @EnvironmentObject private var player: Player
    @EnvironmentObject private var theme: Theme

    var body: some View {
        if let t = player.current {
            HStack(spacing: 12) {
                HStack(spacing: 12) {
                    CoverView(url: library.assetURL(t.key, .cover), letter: t.displayAlbum, maxSide: 200)
                        .frame(width: 44, height: 44)
                        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    VStack(alignment: .leading, spacing: 1) {
                        Text(t.title)
                            .font(theme.serif(17))
                            .foregroundStyle(theme.fg)
                            .lineLimit(1)
                        Text(t.artist)
                            .font(.system(size: 12))
                            .foregroundStyle(theme.mu)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
                .onTapGesture(perform: open)

                Button { player.togglePlay() } label: {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(theme.onAccent)
                        .frame(width: 42, height: 42)
                        .background(theme.ac, in: Circle())
                }
                .buttonStyle(.plain)
            }
            .padding(10)
            .background(theme.sf, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(theme.ln, lineWidth: 1))
            .padding(.horizontal, 12)
            .padding(.bottom, 6)
        }
    }
}
