import AVFoundation
import MediaPlayer
import UIKit

/// Copies the downloaded, DRM-free songs of the Music app into Amber.
/// Streaming / protected tracks cannot be exported by iOS, so they are skipped.
enum AppleMusicSync {
    private static let syncedKey = "amber.appleSynced"

    private static func authorize() async -> Bool {
        let current = MPMediaLibrary.authorizationStatus()
        if current == .authorized { return true }
        if current != .notDetermined { return false }
        return await withCheckedContinuation { continuation in
            MPMediaLibrary.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }

    private static func clean(_ s: String) -> String {
        let bad = CharacterSet(charactersIn: "/\\:*?\"<>|")
        let parts = s.components(separatedBy: bad)
        let joined: String = parts.joined(separator: "_").trimmingCharacters(in: .whitespaces)
        return joined.isEmpty ? "Unknown" : joined
    }

    private static func metadataItem(_ id: AVMetadataIdentifier, _ value: Any) -> AVMutableMetadataItem {
        let item = AVMutableMetadataItem()
        item.identifier = id
        item.value = value as? (NSCopying & NSObjectProtocol)
        item.extendedLanguageTag = "und"
        return item
    }

    private static func metadata(for song: MPMediaItem) -> [AVMetadataItem] {
        var list: [AVMetadataItem] = []
        if let t = song.title { list.append(metadataItem(.iTunesMetadataSongName, t)) }
        if let a = song.artist { list.append(metadataItem(.iTunesMetadataArtist, a)) }
        if let a = song.albumTitle { list.append(metadataItem(.iTunesMetadataAlbum, a)) }
        if let a = song.albumArtist { list.append(metadataItem(.iTunesMetadataAlbumArtist, a)) }
        if let g = song.genre { list.append(metadataItem(.iTunesMetadataUserGenre, g)) }
        if let l = song.lyrics, !l.isEmpty { list.append(metadataItem(.iTunesMetadataLyrics, l)) }
        if let date = song.releaseDate {
            let year: Int = Calendar.current.component(.year, from: date)
            list.append(metadataItem(.iTunesMetadataReleaseDate, String(year)))
        }
        if let art = song.artwork?.image(at: CGSize(width: 1000, height: 1000)),
           let jpeg = art.jpegData(compressionQuality: 0.9) {
            list.append(metadataItem(.iTunesMetadataCoverArt, jpeg))
        }
        return list
    }

    private static func export(_ song: MPMediaItem, to url: URL) async -> Bool {
        guard let source = song.assetURL else { return false }
        let asset = AVURLAsset(url: source)
        let made: AVAssetExportSession? = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A)
        guard let session = made else { return false }
        session.metadata = metadata(for: song)
        do {
            try await session.export(to: url, as: .m4a)
            return true
        } catch {
            return false
        }
    }

    /// Runs the sync. Progress is shown through `library.status`.
    static func run(into library: Library) async {
        func post(_ text: String?) async { await MainActor.run { library.status = text } }

        await post("Asking for Music access…")
        guard await authorize() else {
            await post("Music access was denied. Allow it in Settings → Amber.")
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            await post(nil)
            return
        }

        var synced = Set(UserDefaults.standard.stringArray(forKey: syncedKey) ?? [])
        let all: [MPMediaItem] = MPMediaQuery.songs().items ?? []
        let todo: [MPMediaItem] = all.filter { item in
            item.assetURL != nil && !item.isCloudItem && !item.hasProtectedAsset
                && !synced.contains(String(item.persistentID))
        }
        guard !todo.isEmpty else {
            await post(all.isEmpty ? "No songs found in the Music app" : "Music library is already synced")
            try? await Task.sleep(nanoseconds: 2_400_000_000)
            await post(nil)
            return
        }

        let root = FileManager.default.temporaryDirectory.appendingPathComponent("Apple Music", isDirectory: true)
        let batchSize = 20
        var processed = 0
        var start = 0
        while start < todo.count {
            let end: Int = min(start + batchSize, todo.count)
            let batch: [MPMediaItem] = Array(todo[start..<end])
            try? FileManager.default.removeItem(at: root)
            var doneIDs: [String] = []
            for song in batch {
                processed += 1
                await post("Syncing \(processed) / \(todo.count)…")
                let artist: String = clean(song.albumArtist ?? song.artist ?? "Unknown Artist")
                let album: String = clean(song.albumTitle ?? "Unknown Album")
                let number: Int = song.albumTrackNumber
                let prefix: String = number > 0 ? String(format: "%02d ", number) : ""
                let folder = root.appendingPathComponent(artist, isDirectory: true).appendingPathComponent(album, isDirectory: true)
                try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                let file = folder.appendingPathComponent(prefix + clean(song.title ?? "Track") + ".m4a")
                if await export(song, to: file) { doneIDs.append(String(song.persistentID)) }
            }
            if !doneIDs.isEmpty {
                await library.importAndWait([root])
                synced.formUnion(doneIDs)
                UserDefaults.standard.set(Array(synced), forKey: syncedKey)
            }
            try? FileManager.default.removeItem(at: root)
            start = end
        }
        await post("Synced \(synced.count) songs from Apple Music")
        try? await Task.sleep(nanoseconds: 2_400_000_000)
        await post(nil)
    }
}
