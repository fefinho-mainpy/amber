#!/usr/bin/env bash
# Builds an UNSIGNED Amber.ipa (LiveContainer / Sideloadly / AltStore will sign it).
# Needs a Mac (or a GitHub macOS runner) with Xcode 26+ for the iOS 26 SDK.
set -euo pipefail
cd "$(dirname "$0")"

APP=Amber
SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
SDK_VER="$(xcrun --sdk iphoneos --show-sdk-version)"
echo "Using iOS SDK $SDK_VER"
if [ "${SDK_VER%%.*}" -lt 26 ]; then
  echo "ERROR: Xcode 26 or newer is required (MPMediaItemAnimatedArtwork is iOS 26 API)." >&2
  exit 1
fi

rm -rf build
mkdir -p "build/Payload/$APP.app"

xcrun --sdk iphoneos swiftc \
  -sdk "$SDK" \
  -target arm64-apple-ios17.0 \
  -swift-version 5 \
  -parse-as-library \
  -O \
  -module-name "$APP" \
  -Xlinker -rpath -Xlinker /usr/lib/swift \
  -Xlinker -rpath -Xlinker @executable_path/Frameworks \
  Sources/*.swift \
  -o "build/Payload/$APP.app/$APP"

cp Resources/Info.plist "build/Payload/$APP.app/Info.plist"
cp Resources/*.png "build/Payload/$APP.app/"
printf 'APPL????' > "build/Payload/$APP.app/PkgInfo"

( cd build && zip -qry "$APP.ipa" Payload )
echo "Built build/$APP.ipa (unsigned, $(du -h "build/$APP.ipa" | cut -f1))"
