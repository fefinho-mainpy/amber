# Amber — SwiftUI port (with iOS 26 lock-screen animated artwork)

Native SwiftUI port of your "Amber — mp3 player" web app.

## Build the unsigned .ipa

**No Mac (GitHub does the compiling, free):**
1. Create a new GitHub repository and upload this whole folder (keep `.github/` and `Sources/`).
2. Open the **Actions** tab → **Build unsigned IPA** → **Run workflow**.
3. When it finishes, download the **Amber-ipa** artifact (a zip), unzip it, and import `Amber.ipa` into LiveContainer.

**With a Mac (Xcode 26+):** run `./build_ipa.sh` → `build/Amber.ipa`.

Needs the iOS 26 SDK (Xcode 26+) because `MPMediaItemAnimatedArtwork` is iOS 26 API.
The app itself runs on iOS 17+; the animated lock-screen artwork needs iOS 26.

> This code was written without access to a Swift compiler. If the build fails, open the failed
> step in the Actions log and send me the error lines — fixes are usually one-liners.

## What's ported
- Library: add files / add folder (ID3v2 + MP4 tags, embedded covers, USLT/SYLT lyrics)
- Folder extras next to the music: cover/folder/front images, `tall`/`vertical` art, animated
  `cover`/`animated`/`tall` videos, `.lrc` / `.ttml` lyric files
- Home: For you (taste engine), Artists, Albums A–Z
- Album and Artist pages (animated hero, play / shuffle, import cover or animation, remove)
- Now Playing: tall/animated hero, synced + word-by-word lyrics (tap a line to seek),
  flowing or blurred lyrics background, shuffle (taste-weighted), repeat off/all/one, swipe to skip
- Customize: palettes (Ember, Clay, Honey, Sand), accent hue, title font/size, alignment
- Tag editing (stored in the app) incl. lyrics, "apply to whole album"
- Online animated artwork lookup (artwork.m8tec.top), converted to a local MP4

## Lock screen animated artwork (new)
- Uses `MPMediaItemAnimatedArtwork` for both shapes iOS asks for (1:1 and 3:4).
- Your album's own animated cover is used when it has one (square → 1:1, tall → 3:4).
- Otherwise a seamless looping clip is generated from the cover, so it always animates.
- iOS only plays it on the lock screen; Low Power Mode / Reduce Motion show the still frame.

## Not ported (yet)
- Exporting/writing tags back into the audio file (edits live inside the app)
- Film-grain slider and the WebGPU shader (replaced by an animated mesh gradient)
- OGG/Opus/WebM (iOS can't play them natively)
